﻿function CurrencyFieldManager() {
    FieldManager.apply(this, arguments);
    this._limit = null;
    this._decimalSeparator = ".";
    this._minSumNotReachedAlreadyTriggered = false;
    this._fractionalPartLen = 2;
    this._limitPassed = true;
    this._limitCheckingEnabled = true;
};

CurrencyFieldManager.DefaultSumValuePattern = "0{$decimalSeparator}00";

extend(CurrencyFieldManager, FieldManager, {
    getDefaultSumValue: function () {
        return CurrencyFieldManager.DefaultSumValuePattern.replace("{$decimalSeparator}", this._decimalSeparator);
    },

    setFieldValue: function (val) {
        var numStr = val;
        if (!val || isNaN(parseFloat(val))) numStr = this.getDefaultSumValue();
        FieldManager.prototype.setFieldValue.call(this, numStr);
    },

    init: function (args) {
        if (args.hasOwnProperty("limit")) {
            this._limit = args.limit;
            this._maxlength = this._limit.Max.toFixed(2).length;
        }
        if (args.hasOwnProperty("decimalSeparator")) this._decimalSeparator = args.decimalSeparator;
        if (args.hasOwnProperty("fractionalPartLen")) this._fractionalPartLen = args.fractionalPartLen;
        FieldManager.prototype.init.apply(this, arguments);
        if (this.getFieldValue() == 0) {
            this.setFieldDefaultSumValue();
        }
        this._minSumNotReachedAlreadyTriggered = true;
    },
    setFieldDefaultSumValue: function () {
        var switched = false;
        if (this._checkOnSetField) {
            switched = true;
            this._checkOnSetField = false;
        }
        this.setFieldValue(this.getDefaultSumValue());
        if (switched) {
            this._checkOnSetField = true;
        }
    },
    validateMaxSum: function (sum) {
        if (isNaN(sum)) {
            return false;
        }
        return sum <= this._limit.Max;
    },
    validateMinSum: function (sum) {
        if (isNaN(sum)) {
            return false;
        }
        return sum >= this._limit.Min;
    },
    onMaxSumExceeded: null,
    onMinSumNotReached: null,
    triggerMaxSumExceeded: function (sum) {
        if (this.onMaxSumExceeded != null) {
            this.onMaxSumExceeded(this, sum);
        }
    },
    triggerMinSumNotReached: function (sum) {
        if (this.onMinSumNotReached != null) {
            this.onMinSumNotReached(this, sum);
        }
    },
    isComplete: function (currValueParam) {
        var currValue = currValueParam ? currValueParam : this.getViewFieldValue(),
            sum = this.convertViewValueToNumber(currValue),
            sumLimits = this._limit,
            minSumLimit = sumLimits.Min,
            maxSumLimit = sumLimits.Max,
            minSumExceeded = !this.validateMinSum(sum),
            maxSumExceeded = !this.validateMaxSum(sum);
        return this._limitPassed && !isNaN(sum) && !minSumExceeded && !maxSumExceeded;
    },
    checkLimit: function () {
        if (!this._limitCheckingEnabled) {
            return;
        }
        var currValue = this.getViewFieldValue(),
            sum = this.convertViewValueToNumber(currValue),
            sumLimits = this._limit,
            minSumLimit = sumLimits.Min,
            maxSumLimit = sumLimits.Max,
            minSumExceeded = !this.validateMinSum(sum),
            maxSumExceeded = !this.validateMaxSum(sum);
        this._limitPassed = !minSumExceeded && !maxSumExceeded;
        if (minSumExceeded) {
            if (!this._minSumNotReachedAlreadyTriggered) {
                this.triggerMinSumNotReached(sum);
                this._minSumNotReachedAlreadyTriggered = true;
            }
        } else {
            this._minSumNotReachedAlreadyTriggered = false;
        }
        if (maxSumExceeded) {
            this.triggerMaxSumExceeded(sum);
        }
    },
    convertViewValueToNumber: function (viewValue) {
        var viewValue = viewValue ? viewValue : this.getViewFieldValue();
        var num = parseFloat(viewValue.replace(/\s/g, "").replace(/\,/g, "."));
        if (isNaN(num)) return 0;
        return num;
    },
    clear: function () {
        this.setFieldDefaultSumValue();
        if (this.isEditable()) {
            this.focusTextBox();
        }
        this._pos = 0;
        this._limitCheckingEnabled = false;
        this.clearAfter();
        this._limitCheckingEnabled = true;
    },
    updateCaretPos: function () { setCursorPos(this._tb, this.getViewFieldLength()) },
    removeLastLetter: function () {
        var currValue = this.getViewFieldValue();
        if (currValue == this.getDefaultSumValue()) return;
        var newValue = null;
        var currValueWithoutDot = currValue.replace(this._decimalSeparator, "");
        var currValueWithoutLeadingZeros = currValueWithoutDot.replace(this.reLeadingZeros, "$2");
        if (currValueWithoutLeadingZeros.length === 1) {
            newValue = this.getDefaultSumValue();
        } else {
            newValue = currValueWithoutLeadingZeros.split("", currValueWithoutLeadingZeros.length - 1).join("");
            while (newValue.length < this.getDefaultSumValue().length - 1) newValue = "0" + newValue;
            newValue = this.insertDot(newValue);
        }
        this.setFieldValue(newValue);
        if (this.isEditable()) {
            this.updateCaretPos();
        }
        this.checkComplete();
    },
    insertDot: function (resultValue) {
        var length = resultValue.length;
        var cutPos = length - this._fractionalPartLen;
        return resultValue.substr(0, cutPos) + this._decimalSeparator + resultValue.substr(cutPos, this._fractionalPartLen);
    },

    checkComplete: function () {
        this.checkLimit();
        FieldManager.prototype.checkComplete.apply(this, arguments);
    },

    reLeadingZeros: /^(0+)((?!0)\d*)$/,

    appendLetter: function (letter) {
        var fractionalPartLen = this._fractionalPartLen;
        var currValue = this.getViewFieldValue();
        if (this.isMaxLimitExceeded(currValue)) return;
        var newValue = null;
        var fractionalPartLenWithDot = fractionalPartLen + 1;
        var letterNum = parseInt(letter);
        var currNum = parseFloat(currValue);
        var currValueWithoutDot = currValue.replace(this._decimalSeparator, "");
        var leadingZeroREResult = this.reLeadingZeros.exec(currValueWithoutDot);
        var leadingZeros = leadingZeroREResult != null ? leadingZeroREResult[1] : "";
        var leadingZeroLength = leadingZeros.length;

        if (leadingZeroLength == 0) {
            newValue = currValueWithoutDot + letter;
        } else {
            var cutZeroPos = leadingZeroLength - 1;
            newValue = currValueWithoutDot.substr(0, cutZeroPos) + currValueWithoutDot.substr(cutZeroPos + 1) + letter;
        }
        newValue = this.insertDot(newValue);
        //this._pos++;
        this.setFieldValue(newValue);
        if (this.isEditable()) {
            this.updateCaretPos();
        }
        this.checkComplete();
    },

    isMaxLimitExceeded: function (currValue) { return currValue.length >= this._limit.Max.toFixed(this._fractionalPartLen).length; },

    setViewFieldValue: function (newValue) {
        if (newValue.search(".") != -1) newValue = newValue.replace(".", this._decimalSeparator);
        FieldManager.prototype.setViewFieldValue.call(this, newValue);
    },

    setHiddenFieldValue: function (newValue) {
        if (newValue.search(this._decimalSeparator) != -1) newValue = newValue.replace(this._decimalSeparator, ".");
        FieldManager.prototype.setHiddenFieldValue.call(this, newValue);
    },

    getFloatValue: function () {
        return parseFloat(this.getFieldValue());
    }
});