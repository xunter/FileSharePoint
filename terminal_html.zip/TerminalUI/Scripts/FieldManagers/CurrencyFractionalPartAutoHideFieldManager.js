﻿function CurrencyFractionalPartAutoHideFieldManager() {
    CurrencyFieldManager.apply(this, arguments);
    this._limit = null;
    this._decimalSeparator = ".";
    this._minSumNotReachedAlreadyTriggered = false;
};

CurrencyFractionalPartAutoHideFieldManager.DefaultSumValuePattern = "0{$decimalSeparator}00";

extend(CurrencyFractionalPartAutoHideFieldManager, CurrencyFieldManager, {
    getDefaultSumValue: function () {
        return "0";
    },

    init: function (args) {
        CurrencyFieldManager.prototype.init.apply(this, arguments);
    },

    appendLetter: function (letter) {
        var currValue = this.getViewFieldValue();
        if (this.isMaxLimitExceeded(currValue)) return;
        var newValue = currValue;
        var fractionalPartLen = this._fractionalPartLen;
        var fractionalPartLenWithDot = fractionalPartLen + 1;
        var letterNum = parseInt(letter);
        var currNum = parseFloat(currValue);

        var isCurrValueEmpty = currValue.length == 0;
        var isJustZeroStr = currValue == "0";
        var decimalSeparator = this._decimalSeparator;
        var DOT = ".";
        var isDecimalSeparator = letter == DOT || letter == decimalSeparator
        var isDecimalSeparatorMissing = currValue.indexOf(DOT) === -1 && currValue.indexOf(decimalSeparator) === -1;

        if (isDecimalSeparator) {
            if (isDecimalSeparatorMissing) {
                if (isCurrValueEmpty) {
                    newValue += "0" + decimalSeparator;
                } else {
                    newValue += decimalSeparator;
                }
            }
        } else {
            if (!(isJustZeroStr && letter == "0")) {
                if (isJustZeroStr) {
                    newValue = letter;
                } else {
                    if (isDecimalSeparatorMissing) {
                        newValue += letter;
                    } else {
                        var dotIndex = currValue.indexOf(DOT);
                        if (dotIndex == -1) dotIndex = currValue.indexOf(decimalSeparator);
                        var fractionalPartStr = currValue.substr(dotIndex + 1);
                        if (fractionalPartStr.length < this._fractionalPartLen) {
                            newValue += letter;
                        }
                    }
                }
            }
        }
        //this._pos++;
        this.setFieldValue(newValue);
        if (this.isEditable()) {
            this.updateCaretPos();
        }
        this.checkComplete();
    },

    removeLastLetter: function () {
        var decimalSeparator = this._decimalSeparator;
        var currValue = this.getViewFieldValue();
        if (currValue == this.getDefaultSumValue()) return;
        var newValue = currValue.substr(0, currValue.length - 1);
        if (newValue.length == 0) {
            newValue = this.getDefaultSumValue();
        } else {
            var decimalSeparatorIndex = newValue.indexOf(decimalSeparator);
            if (decimalSeparatorIndex == newValue.length - 1) {
                newValue = newValue.substr(0, decimalSeparatorIndex);
            }
        }
        if (newValue == this.getDefaultSumValue()) {
            this.setFieldDefaultSumValue();
        } else {
            this.setFieldValue(newValue);
        }
        if (this.isEditable()) {
            this.updateCaretPos();
        }
        this.checkComplete();
    },

    getZeroFractionalPart: function () {
        var fractionalZeroString = "";
        for (var i = 0; i < this._fractionalPartLen; i++) {
            fractionalZeroString += "0";
        }
        return fractionalZeroString;
    }
});