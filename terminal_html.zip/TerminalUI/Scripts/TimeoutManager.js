var TimeoutManager = (function () {
    function TimeoutManager() {
    }
    return TimeoutManager;
})();
//# sourceMappingURL=TimeoutManager.js.map