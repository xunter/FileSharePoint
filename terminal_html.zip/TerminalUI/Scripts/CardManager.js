﻿(function ($) {

    var TRACK_SEPARATER = "~",
        CARD_NUMBER_SEPARATER = "=",
        CARD_OWNER_SEPARATER = "^",
        CARD_EXPIRATION_DATE_FORMAT = "yyMM";

    var trim = function (s) {
        return s.replace(/^\s\s*/, "").replace(/\s\s*$/, "");
    };

    CardManager = cardManager = {

        _currentTransaction: null,

        setCurrentTransaction: function (cardTransaction) {
            this._currentTransaction = cardTransaction;
        },

        getCurrentTransaction: function () { return this._currentTransaction; },

        parseNumber: function (track2) {
            var index = track2.indexOf(CARD_NUMBER_SEPARATER);
            return (index != -1) ? track2.substring(0, index) : "";
        },

        parseOwner: function (track1) {
            var firstIndex = track1.indexOf(CARD_OWNER_SEPARATER),
                lastIndex = track1.lastIndexOf(CARD_OWNER_SEPARATER),
                lengthOwner = lastIndex - firstIndex - CARD_OWNER_SEPARATER.length,
                result = "";

            if ((firstIndex != -1) && (lastIndex != -1) && (lengthOwner > 0)) {
                result = track1.substr(firstIndex + CARD_OWNER_SEPARATER.length, lengthOwner);
                return trim(result);
            }
            else {
                return result;
            }
        },

        parseExpirationDate: function (track2) {

            var index = track2.indexOf(CARD_NUMBER_SEPARATER),
                year = (new Date()).getFullYear(),
                month = 0,
                result = null;

            if ((track2.length - index - CARD_NUMBER_SEPARATER.length) >= CARD_EXPIRATION_DATE_FORMAT.length) {
                result = track2.substr(index + CARD_NUMBER_SEPARATER.length, CARD_EXPIRATION_DATE_FORMAT.length);
                year = year.toString().substr(0, 2) + result.substr(0, 2);
                year = parseInt(year, 10);
                month = result.substr(2, 2);
                month = parseInt(month, 10);
                result = new Date(year, month, 1);
            }
            return result;
        },

        checkExpirationDateValid: function (cardExpirationDate) {
            var currDate = new Date();
            var valid = cardExpirationDate == null || (currDate < cardExpirationDate);
            return valid;
        },

        getBin: function (cardNumber, listBins) {
            var copiedListBins = listBins.slice();
            copiedListBins.sort(function (a, b) {
                return a.startChars.length - b.startChars.length;
            });
            for (var i = 0, l = copiedListBins.length; i < l; i++) {
                var currBinInfo = copiedListBins[i];
                if (cardNumber.indexOf(currBinInfo.startChars) == 0) {
                    if (currBinInfo.supportedNumLengths != null && currBinInfo.supportedNumLengths.length > 0) {

                    }
                    return currBinInfo;
                }
            }
            return null;
        },

        parseTransactionRequestXml: function (requestXml, callback) {
            var xmlDoc = $.parseXML(requestXml);
            var $xml = $(xmlDoc);
            var map = {};
            var triggerCallback = function (map) {
                if (callback) callback(map);
            };
            $xml.find("root > *").each(function (i, element) {
                var name = element.tagName;
                var val = $(element).text();
                map[name] = val;
            });
            triggerCallback(map);
        },

        getCardData: function (callback) {
            var cardBalanceInputArgs = {
                TERMINAL_ID: CARD_TERMINAL_ID,
                CARD_NUMBER: CARD_NUMBER,
                TRACK2: CARD_TRACK2,
                PIN_BLOCK: CARD_PINBLOCK,
                PIN_KEY_KCV: CARD_PINKEYKCV,
                terminalId: CARD_TERMINAL_ID,
                cardNumber: CARD_NUMBER,
                track2: CARD_TRACK2,
                pinBlock: CARD_PINBLOCK,
                pinKeyKCV: CARD_PINKEYKCV
            };

            if (callback) callback(cardBalanceInputArgs);
        },

        generateStan: function () {
            return formatDate(new Date(), "HHmmss");
        },

        getCardBalanceAsync: function (callback) {
            var self = this;
            var logger = TerminalUI.loggingService;
            var scm = SmartClientManager;
            var stan = this.generateStan();
            var formattedCardNum = "";
            var triggerCallback = function (ctx) {
                if (ctx.error) {
                    var logMsgFailedBalance = TerminalUI.UIMessageMap["LOG_CARD_BALANCE_REQUEST_SUCCESS"].replace("#CARD_NUMBER#", formattedCardNum);
                    if (ctx.msg) {
                        logMsgFailedBalance = logMsgFailedBalance.replace("#ERROR_MSG#", ctx.msg);
                    } else {
                        logMsgFailedBalance = logMsgFailedBalance.replace("#ERROR_MSG#", "Fatal error");
                    }
                    scm.writeStateToLog(logMsgSuccessBalance);
                } else {
                    var logMsgSuccessBalance = TerminalUI.UIMessageMap["LOG_CARD_BALANCE_REQUEST_SUCCESS"].replace("#CARD_NUMBER#", formattedCardNum).replace("#BALANCE_VAL#", ctx.balanceNum);
                    scm.writeStateToLog(logMsgSuccessBalance);
                }

                if (callback) callback(ctx);
            };

            TerminalUI.ajaxService.postJSON(URL_GetCardBalanceOperatorInfoJson, {}, function (res) {

                var cardBalanceOperatorId = window._cardBalanceOperatorId = res.OperatorInstance.ID;
                var balanceValueFieldId = res.BalanceValueFieldID;
                var responseCodeFieldId = res.ResponseCodeFieldID

                self.getCardData(function (cardData) {

                    var cardNumber = cardData.cardNumber;
                    formattedCardNum = maskCardNum(cardNumber);
                    var logMsgGettingBalance = TerminalUI.UIMessageMap["LOG_CARD_BALANCE_REQUEST_OBTAINING"].replace("#CARD_NUMBER#", formattedCardNum);
                    scm.writeStateToLog(logMsgGettingBalance);

                    var cardBalanceInputArgs = $.extend({}, cardData, { stan: stan });

                    var cardBalanceInArgsToFieldsMap = function (inArgs) {
                        var fields = {
                            field100: inArgs.terminalId,
                            field101: inArgs.stan,
                            field102: cardNumber,
                            field103: inArgs.track2,
                            field104: inArgs.pinBlock,
                            field105: inArgs.pinKeyKCV
                        };
                        return fields;
                    };

                    /*
                    field100=[TERMINALID]
                    field101=[STAN]
                    field102=[CARDNUMBER]
                    field102=[TRACK2]
                    field103=[PINBLOCK]
                    field104=[PINKEYKCV]
                    field105=[ACQUIRING_CODE]
                    field106=[FORWARDING_CODE]
                    field107=[AUTH_CODE]
                    field108=[RESPONSE_CODE]
                    field109=[RRN]
                    field110=[BAL_AMOUNT]
                    */

                    var fields = cardBalanceInArgsToFieldsMap(cardBalanceInputArgs);

                    var fakeResponse = "RESULT=0\nERROR=0\nANSWER_DATA=<?xml version=\"1.0\" encoding=\"Windows-1251\"?><root><invoices><invoice><fields><field id=\"106\" order=\"1\" value=\"\" /><field id=\"107\" order=\"1\" value=\"\"/><field id=\"108\" order=\"1\" value=\"    \"/><field id=\"109\" order=\"1\" value=\"00\"/><field id=\"110\" order=\"1\" value=\"\"/><field id=\"111\" order=\"1\" value=\"1234567.89\"/></fields></invoice></invoices></root>";

                    var request = {
                        type: FS.Gateway.RequestTypes.GetCardBalanceRequest,
                        fields: fields,
                        operatorId: cardBalanceOperatorId
                    };

                    if (typeof (EMULATE_BALANCE) != "undefined" && EMULATE_BALANCE === true) {
                        request.emulate = {
                            result: 0,
                            error: 0,
                            responseData: fakeResponse,
                            delay: 2000
                        };
                    }

                    scm.sendOnlineRequestAsync({
                        request: request,
                        callback: function (result) {
                            var resultCode = result.result;
                            if (resultCode == FS.Gateway.ResultCodes.Success) {
                                var responseMap = result.responseMap;
                                var invoiceXml = responseMap["ANSWER_DATA"];
                                logger.trace("Parsing the got xml data...");

                                var urlParseCardBalanceInvoice = URL_PARSE_INVOICE_TEMPLATE.replace("_TARGET_OPERATOR_ID_", cardBalanceOperatorId);

                                OperatorFieldsEditingUtil.parseFoundInvoice(invoiceXml, function (parseInvoiceResultCtx) {
                                    if (parseInvoiceResultCtx.error) {
                                        logger.warn("Failed to parse the got xml data!");
                                        var parseError = parseInvoiceResultCtx.error;
                                        triggerCallback({ error: parseError });
                                    } else {
                                        logger.warn("The got xml data was parsed successfully.");
                                        balanceValue = parseInvoiceResultCtx.extendingFieldsMap["field" + balanceValueFieldId];
                                        var responseCode = parseInvoiceResultCtx.extendingFieldsMap["field" + responseCodeFieldId];
                                        logger.info("Card auth response code is %1", responseCode);
                                        if (responseCode == "00") {
                                            balanceNum = parseFloat(balanceValue.replace("[\\.]", ","));
                                            logger.trace("Card balance is %1", balanceNum);
                                            if (isNaN(balanceNum)) {
                                                triggerCallback({ error: true, fatal: true });
                                            } else {
                                                triggerCallback({ balanceNum: balanceNum });
                                            }
                                        } else {
                                            var cardResponseCodeInfo = FS.TerminalUI.CardAuthResponseCodesMap[responseCode];
                                            var callbackCtx = { error: true, fatal: true };
                                            if (cardResponseCodeInfo != null) {
                                                callbackCtx.msg = TerminalUI.UIMessageMap["CardOperationFailedGeneralMsgTemplate"].replace("{0}", cardResponseCodeInfo.UserMessage);
                                            }
                                            triggerCallback(callbackCtx);
                                        }
                                    }
                                }, urlParseCardBalanceInvoice);
                            } else {
                                triggerCallback({ error: true, fatal: true });
                            }
                        }
                    });
                });
            });

        }
    };

})(jQuery);