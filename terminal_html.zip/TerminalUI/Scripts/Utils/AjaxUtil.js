﻿(function (window, $) {
    var AjaxUtil = window.AjaxUtil = {
        postJSONAsync: function (url, obj, callback, error) {
            $.ajax({
                type: "POST",
                url: url,
                contentType: "application/json",
                data: toJSON(obj),
                success: function (result) {
                    if (typeof (callback) != "undefined") callback(result);
                },
                error: function() {
                    if (typeof(error) != "undefined") error.apply(this, arguments);
                }
            });
        }
    };
})(window, jQuery);