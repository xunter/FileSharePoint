var FireEvent = (function () {
    function FireEvent() {
        this.handlers = [];
    }
    FireEvent.prototype.subscribe = function (handler, thisArg) {
        this.handlers.push(thisArg ? handler.bind(thisArg) : handler);
    };
    FireEvent.prototype.unsubscribe = function (handler) {
        this.handlers = this.handlers.filter(function (h) { return h !== handler; });
    };
    FireEvent.prototype.fire = function (sender, e) {
        if (this.handlers) {
            this.handlers.forEach(function (h) { return h(sender, e); });
        }
    };
    return FireEvent;
})();
//# sourceMappingURL=Events.js.map