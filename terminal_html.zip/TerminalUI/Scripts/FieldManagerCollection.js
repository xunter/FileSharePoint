﻿var FieldManagerCollection = function () {
    this._fieldManagers = [];
};

FieldManagerCollection.prototype = {
    findIndex: function (fieldManager) {
        for (var i = 0; i < this._fieldManagers.length; i++) {
            var curr = this._fieldManagers[i];
            if (curr == fieldManager) return i;
        }
        return -1;
    },
    contains: function (fieldManager) {
        return this.findIndex(fieldManager) != -1;
    },
    add: function (fieldManager) {
        if (!this.contains(fieldManager)) {
            this._fieldManagers.push(fieldManager);
            var self = this;
            fieldManager.oncomplete = function () { self.fieldComplete(this); };
            fieldManager.onincomplete = function () { self.fieldIncomplete(this); };
            fieldManager.onValueChanged = function (newValue) { self._fieldValueChanged(this, newValue); };
        }
    },

    complete: null,
    incomplete: null,
    fieldValueChanged: null,

    triggerComplete: function () {
        if (this.complete != null) this.complete();
    },

    triggerIncomplete: function () {
        if (this.incomplete != null) this.incomplete();
    },

    _fieldValueChanged: function (fieldManager, newValue) {
        this.triggerFieldValueChanged(fieldManager, newValue);
    },

    triggerFieldValueChanged: function (fieldManager, newValue) {
        if (this.fieldValueChanged != null) this.fieldValueChanged(fieldManager, newValue);
    },

    fieldComplete: function (fieldManager) {
        if (this.isComplete()) this.triggerComplete();
    },

    fieldIncomplete: function (fieldManager) {
        this.triggerIncomplete();
    },

    remove: function (fieldManager) {
        var foundIndex = this.findIndex(fieldManager);
        if (foundIndex != -1) this._fieldManagers.splice(foundIndex, 1);
    },
    getByFieldID: function (id) {
        for (var i = 0; i < this._fieldManagers.length; i++) {
            var curr = this._fieldManagers[i];
            if (curr.getFieldID() == id) return curr;
        }
        return null;
    },
    isComplete: function (id) {
        for (var i = 0; i < this._fieldManagers.length; i++) {
            var curr = this._fieldManagers[i];
            if (!curr.isComplete() && curr.isEditable()) {
                return false;
            }
        }
        return true;
    },
    checkComplete: function () {
        for (var i = 0; i < this._fieldManagers.length; i++) {
            var curr = this._fieldManagers[i];
            curr.checkComplete();
        }
    },
    forEach: function (iterator, set) {
        var set = set ? set : this._fieldManagers;
        for (var i = 0; i < set.length; i++) {
            if (iterator(set[i], i) === false) break;
        }
    },
    filterWithBarcode: function () {
        var fieldManagersWithBarcode = [];
        this.forEach(function (fieldManager) {
            if (fieldManager.isWithBarcode()) fieldManagersWithBarcode.push(fieldManager);
        });
        return fieldManagersWithBarcode;
    },
    applyBarcodeValue: function (barcodeTextValue) {
        var subset = this.filterWithBarcode();
        this.forEach(function (fieldManager) {
            fieldManager.applyBarcodeValue(barcodeTextValue);
        }, subset);
    },
    size: function () {
        return this._fieldManagers.length;
    }
};