﻿var CabinetManager = (function (window, $, SmartClientManager) {
    var _cabinetInfo = null;
    var _urlCabinetAddOperator = null;
    var _urlCabinetCheckSameOperatorAccount = null;

    var CabinetManager = {
        setCabinetInfo: function (cabinetInfo) {
            _cabinetInfo = cabinetInfo;
        },

        init: function (settings) {
            if (settings.hasOwnProperty("urlCabinetAddOperator")) _urlCabinetAddOperator = settings.urlCabinetAddOperator;
            if (settings.hasOwnProperty("urlCabinetCheckSameOperatorAccount")) _urlCabinetCheckSameOperatorAccount = settings.urlCabinetCheckSameOperatorAccount;
        },

        isCabinetSession: function () {
            return _cabinetInfo != null;
        },

        sendLoadCabinetRequest: function (passedArgs) {
            var smartClientManager = SmartClientManager;
            var loggingService = TerminalUI.loggingService;
            var defaultArgs = {
                operatorId: 0,
                fieldsMap: {},
                success: function (cabinetXml) { },
                error: function (errorCode) { },
                knownError: function (errorCode, userMsg) { },
                unknownError: function (errorCode) { }
            };
            var args = $.extend({}, defaultArgs, passedArgs);
            var operatorId = args.operatorId;
            var fieldsMap = args.fieldsMap;
            var successCallback = args.success;
            var errorCallback = args.error;
            var knownErrorCallback = args.knownError;
            var unknownErrorCallback = args.unknownError;

            var reqType = window.OPERATOR_ITEM_TARGET && OPERATOR_ITEM_TARGET == TerminalUI.Config.Cabinet.TargetOTP ? FS.Gateway.RequestTypes.LoadOTPCabinetRequest : FS.Gateway.RequestTypes.LoadCabinetRequest;
            smartClientManager.sendOnlineRequestAsync({
                request: {
                    type: reqType,
                    operatorId: operatorId,
                    fields: fieldsMap
                },
                callback: function (args) {
                    var result = args.result;
                    var responseMap = args.responseMap;
                    var responseData = args.responseData;
                    if (result == GatewayResults.SUCCESS) {
                        var answerData = responseMap.ANSWER_DATA;
                        successCallback(answerData);
                    } else {
                        var errorCode = responseMap.ERROR;
                        var keyGatewayErrorMsg = "Gateway_ErrorCode_" + errorCode;
                        var gatewayErrorMsg = TerminalUI.UIMessageMap.hasOwnProperty(keyGatewayErrorMsg) ? TerminalUI.UIMessageMap[keyGatewayErrorMsg] : null;
                        if (gatewayErrorMsg != null) {
                            loggingService.warn("The \"%1\" is for the %2 error code.", gatewayErrorMsg, errorCode);
                            smartClientManager.writeStateErrorToLog(formatMsg("При совершении запроса на вход в Личный/Банковский кабинет был получен ответ от сервера: \"%1\" (%2)", gatewayErrorMsg, errorCode));
                        }
                        loggingService.trace("The error code is %1.", errorCode);
                        loggingService.trace("Triggering the common error callback with error code = %1", errorCode);
                        errorCallback(errorCode);
                        if (gatewayErrorMsg == null) {
                            loggingService.trace("Triggering the unknown error callback with error code = %1", errorCode);
                            unknownErrorCallback(errorCode);
                        } else {
                            knownErrorCallback(errorCode, gatewayErrorMsg);
                            loggingService.trace("Triggering the known error callback with error code = %1 and msg = %2", errorCode, gatewayErrorMsg);
                        }
                    }
                }
            });
        },

        addCabinetOperatorAsync: function (operatorId, fieldsMap, callback) {
            var self = this;
            var triggerCallback = function (ctx) {
                if (callback) callback(ctx);
            };
            if (!this.isCabinetSession()) triggerCallback({ error: true, errorCode: -1, errorMsg: "It is not a cabinet session!" });
            var cabinetInfo = _cabinetInfo.AccountsGroup;

            var fieldsMapForTransfering = FieldsUtil.serializeFieldsMapToTransfer(fieldsMap);
            var addOperatorInfo = { OperatorID: operatorId, UserId: cabinetInfo.UserID, CabinetID: cabinetInfo.ID, FieldsMapFromJSON: fieldsMapForTransfering };

            FS.TerminalUI.ajaxService.postJSON(_urlCabinetCheckSameOperatorAccount, addOperatorInfo, function (exists) {
                if (exists) {
                    triggerCallback({ error: true, errorCode: -4, errorMsg: "The same cabinet account already exists." });
                } else {
                    addCabinetAccountThroughGatewayCallback();
                }
            },
            function () {
                triggerCallback({ error: true, errorCode: -3, errorMsg: "Ajax communication error!" })
            });

            var addCabinetAccountThroughGatewayCallback = function () {
                SmartClientManager.sendOnlineRequestAsync({
                    request: {
                        type: FS.Gateway.RequestTypes.AddCabinetAccountRequest,
                        cabinetId: cabinetInfo.ID,
                        userId: cabinetInfo.UserID,
                        operatorId: operatorId,
                        fields: fieldsMap
                    },
                    callback: function (args) {
                        var result = args.result;
                        var responseMap = args.responseMap;
                        if (result == FS.Gateway.ResultCodes.Success) {
                            var accountID = responseMap.ANSWER_DATA;
                            addOperatorInfo.AccountID = accountID;
                            FS.TerminalUI.ajaxService.postJSON(_urlCabinetAddOperator, addOperatorInfo, function (response) {
                                if (response.success) {
                                    triggerCallback({ success: true });
                                } else {
                                    if (response.code == -1) triggerCallback({ error: true, errorCode: response.code, errorMsg: "An account already exists!" });
                                }
                            },
                        function () {
                            triggerCallback({ error: true, errorCode: -3, errorMsg: "Ajax communication error!" })
                        });
                        } else {
                            triggerCallback({ error: true, errorCode: -2, errorMsg: "Server error!" });
                        }
                    }
                });
            };
        }
    };

    return CabinetManager;
})(window, jQuery, SmartClientManager);