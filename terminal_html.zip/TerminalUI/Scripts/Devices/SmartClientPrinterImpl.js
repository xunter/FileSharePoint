﻿function SmartClientPrinterImpl(smartClientManager) {
    var self = this;
    this._currentState = null;
    this._smartClientManager = smartClientManager;
    this._smartClientManager.addListener({
        printerState: function (state) {
            self._currentState = state;
            self.onStateChanged(state);
        },
        printerCallback: function (paramName, paramValue) {
        }
    });
};
extend(SmartClientPrinterImpl, Printer, {
    getCurrentState: function () { return this._currentState; },
    state: function () { this._smartClientManager.statePrinter() },
    printText: function (text, amountAll, callback) {
        this._smartClientManager.printText(text, amountAll, callback);
    }
});