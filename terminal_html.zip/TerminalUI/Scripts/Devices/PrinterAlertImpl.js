﻿function PrinterAlertImpl() {
    var self = this;
};
extend(PrinterAlertImpl, BillValidator, {
    getCurrentState: function () { return "Operable" },
    state: function () {
        this.onStateChanged("Operable");
    },
    printText: function (text, amountAll, callback) {
        this._smartClientManager.printText(text, amountAll, callback);
    }
});