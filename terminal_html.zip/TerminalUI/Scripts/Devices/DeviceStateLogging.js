﻿(function (smartClientManager) {
    var logDeviceState = function (deviceName, state) {
        FS.TerminalUI.loggingService.info("The state of the %1 device has been changed and it is %2.", deviceName, state);
    };
    smartClientManager.addListener({
        billValidatorState: function (state) { logDeviceState("BillValidator", state) },
        printerState: function (state) { logDeviceState("Printer", state) },
        pinPadState: function (state) { logDeviceState("PinPad", state) },
        barcodeScannerState: function (state) { logDeviceState("BarcodeScanner", state) },
        cardReaderState: function (state) { logDeviceState("CardReader", state) }
    });
})(SmartClientManager);