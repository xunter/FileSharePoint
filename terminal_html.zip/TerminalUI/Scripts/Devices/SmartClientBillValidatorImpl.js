﻿function SmartClientBillValidatorImpl(smartClientManager) {
    var self = this;
    this._currentSum = 0;
    this._currentState = null;
    this._opened = false;
    this._pollDescription = null;
    this._smartClientManager = smartClientManager;
    this._buttonState = null;

    this._smartClientManager.addListener({
        billValidatorSum: function (sumObj) {
            var sum = sumObj.sum;
            self._currentSum = sum;
            self.onSumChanged(sum);
        },
        billValidatorBill: function (billObj) { self.onBillPushed(billObj.bill) },
        billValidatorState: function (state) {
            self._currentState = state;
            self.onStateChanged(state);
        },
        billValidatorInvalidBill: function (arg) {
            if (arg == "True") {
                self.onInvalidBill();
            }
        },
        billValidatorButtonState: function (state) {
            var prevButtonState = this._buttonState;
            this._buttonState = state;
            if (!prevButtonState || prevButtonState == "Enable") {
                if (state == "Disable") {
                    self.onDisabled();
                }
            } else if (prevButtonState == "Disable") {
                if (state == "Enable") {
                    self.onEnabled();
                }
            }
        },
        billValidatorCallback: function (paramName, paramValue) {
            if (paramName == "PollDescription") {
                if (self._pollDescription != paramValue) {
                    self._pollDescription = paramValue;
                    self.onPollDescriptionChanged(paramValue);
                }
            }
        },
        billValidatorExceededBill: function (exceededBill) {
            self.onBillExceeded(exceededBill);
        },
        billValidatorExceededSum: function (exceededSum) {
            self.onSumExceeded(exceededSum);
        }
    });
};
extend(SmartClientBillValidatorImpl, BillValidator, {
    getCurrentState: function () { return this._currentState; },
    getCurrentSum: function () { return this._currentSum; },
    isOpened: function () { return this._opened; },
    isClosed: function () { return !this._opened; },
    state: function () { this._smartClientManager.stateBillValidator() },
    open: function (maxSum) {
        this._smartClientManager.openBillValidator(maxSum);
        this._opened = true;
    },
    close: function (callback) {
        var self = this;
        this._smartClientManager.closeBillValidatorAsync(function () {
            self._opened = false;
            if (callback) callback.apply(this, arguments);
        });
    },
    onPollDescriptionChanged: function (pollDescription) { },

    isEnabled: function () { return this._buttonState != "Disable"; },
    isDisabled: function () { return this._buttonState == "Disable"; }
});