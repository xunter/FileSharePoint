﻿(function (window) {

    var TopWindowStorageManagerWrapper = window.TopWindowStorageManagerWrapper = function () {
    };

    TopWindowStorageManagerWrapper.prototype = {
        get: function (key) {
            return window.StorageManager.get(key);
        },

        set: function (key, value) {
            window.StorageManager.set(key, value);
        }
    };

    var Storage = window.Storage = function () {
        this._map = {};
    };

    Storage.prototype = {
        get: function (key) {
            return this._map[key];
        },

        set: function (key, value) {
            this._map[key] = value;
        }
    };

    var LocalStorageWrapper = window.LocalStorageWrapper = function () { };

    LocalStorageWrapper.isAvailable = function () {
        return typeof (window.localStorage) != "undefined";
    };

    LocalStorageWrapper.prototype = {
        get: function (key) {
            return window.localStorage.getItem(key);
        },

        set: function (key, value) {
            window.localStorage.setItem(key, value);
        }
    };

    var StorageManager = window.StorageManager = {
        _knownKeysMap: {},
        init: function (settings) {
            var settings = settings || {};
            if (settings.hasOwnProperty("storage")) this._storage = settings.storage;
            this.keepStorageInited();
        },
        keepStorageInited: function () {
            if (!this._storage) {
                var localStorageWrapper = new LocalStorageWrapper();
                this._storage = localStorageWrapper;
            }
        },
        getItem: function (key, callback) {
            this.keepStorageInited();
            this._knownKeysMap[key] = true;
            var value = this._storage.get(key);
            if (callback) callback(value, key);
        },
        setItem: function (key, value, callback) {
            this.keepStorageInited();
            this._knownKeysMap[key] = true;
            this._storage.set(key, value);
            if (callback) callback(key, value);
        },
        getStorage: function () {
            return this._storage;
        }
    };
})(window);