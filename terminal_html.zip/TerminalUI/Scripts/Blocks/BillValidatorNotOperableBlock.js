﻿(function ($) {

    var navManager = TerminalUI.navManager;
    var loggingService = TerminalUI.loggingService;

    var smartClientManager = SmartClientManager;

    var blockEnabled = TerminalUI.UISettingsMap["BILL_VALIDATOR_NOT_OPERABLE_BLOCK_ENABLED"] == "1";
    loggingService.trace("Bill validator not operable block is %1.", blockEnabled ? "ENABLED" : "DISABLED");

    if (TerminalUI.UISettingsMap["BILL_VALIDATOR_NOT_OPERABLE_BLOCK_ENABLED"] == "1") {

        navManager.addPageLoadAsyncTask(function () {
            var self = this;
            var $block = $("#blockBillValidatorNotOperable");

            var showBlock = function () {
                if ($block.hasClass("hidden")) {
                    loggingService.trace("Showing the bill validator not operable block...");
                    smartClientManager.writeStateToLog("LOG_MSG_BILL_VALIDATOR_NOT_OPERABLE_BLOCK_SHOWING");

                    $block.removeClass("hidden");
                }
            };

            var hideBlock = function () {
                if (!$block.hasClass("hidden")) {
                    $block.addClass("hidden");
                }
            };

            loggingService.trace("Polling the bill validator to get its state...");
            smartClientManager.stateBillValidatorAsync(function (state) {
                loggingService.trace("Bill validator state is %1.", state);
                if (state == "NotOperable") {
                    showBlock();
                }

                smartClientManager.addHandler("billValidatorState", function (state) {
                    loggingService.trace("Bill validator state is %1.", state);
                    if (state == "NotOperable") {
                        showBlock();
                    } else if (state == "Operable") {
                        hideBlock();
                    }
                });

                self.complete();
            });
            
        });
    }
})(jQuery);