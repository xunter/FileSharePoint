﻿(function (window, $, TerminalUI) {
    var dlgId = getExecutingScriptTagDataProp("dlg_id");
    var idleTimer = null;

    $(function () {
        var dlgInstance = DlgMsgManager.findDlg(dlgId);
        var smartClientManager = SmartClientManager;
        function createIdleTimer()
        {
            var timeoutMilliseconds = parseInt(TerminalUI.UISettingsMap["DLG_IDLE_TIMEOUT_TIMEOUT_MILLISECONDS"]);
            idleTimer = setTimeout(function ()
            {
                TimeoutManager.Instance.OnUITimeout.bind(TimeoutManager.Instance)();
                idleTimer = null;
            },
            timeoutMilliseconds);
        };

        function destroyIdleTimer() {
            if (idleTimer != null) {
                clearTimeout(idleTimer);
                idleTimer = null;
            }
        };

        smartClientManager.addHandler("screenPanelActive", function () {
            if (idleTimer != null) {
                destroyIdleTimer();
                createIdleTimer();
            }
        });

        dlgInstance.onShown(function () {
            createIdleTimer();
        });

        dlgInstance.onHidden(function () {
            destroyIdleTimer();
        });

        dlgInstance.onButtonClick("Cancel", function ()
        {
            destroyIdleTimer();
            TimeoutManager.Instance.OnUITimeoutCancelled();
        });

        dlgInstance.onButtonClick("OK", function () {
            destroyIdleTimer();
            DlgMsg.prototype.defaultHideHandler.apply(this, arguments);
        });
    });
})(window, jQuery, TerminalUI);