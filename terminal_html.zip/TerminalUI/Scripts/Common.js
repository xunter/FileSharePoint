/*
Common.js ver 1.0.3
Date: Fri May 20 2011 09:51:54 GMT+0400 (Russia Daylight Time)
Author: Nazarov P.A.
*/

(function (window, undefined) {

    var _CommonScriptLibrary = window._CommonScriptLibrary = {};
    var URL_GET_PARAM_VALUE_CHARACTERS = window.URL_GET_PARAM_VALUE_CHARACTERS = _CommonScriptLibrary.URL_GET_PARAM_VALUE_CHARACTERS = ["a-z", "A-Z", "0-9", "%", "-", "\\.", "_", "~"];
    var SPACE_CHAR = " ";
    undefined = undefined; // typeof() == "undefined"
    var document = window.document;
    if (!Function.prototype.bind) {
        Function.prototype.bind = function (scope) {
            var _f = this;
            return function () {
                return _f.apply(scope, arguments);
            }
        };
    }

    //Wrap for function document.getElementById
    ge = _CommonScriptLibrary.ge = function (elem) {
        return typeof (elem) === "string" ? document.getElementById(elem) : elem;
    };

    //Get elements by tag name
    geTag = _CommonScriptLibrary.geTag = function (tagName, node) {
        var node = node || window.document;
        return node.getElementsByTagName(tagName);
    };

    //Create element
    ce = _CommonScriptLibrary.ce = function (tagName, document) {
        var document = document || window.document;
        return document.createElement(tagName);
    };

    geByTagName = _CommonScriptLibrary.geByTagName = function (tagName, rootElement, equalFunc) {

        var rootElement = rootElement && rootElement !== null ? rootElement : document;

        if (tagName.toLowerCase() == "body" && document.body) {
            return document.body;
        }

        var _get = function (tagName) {
            var ret = [];
            if (rootElement.all && rootElement.all.tags) {
                ret = rootElement.all.tags(tagName);
            } else {
                ret = rootElement.getElementsByTagName(tagName);
            }

            if (typeof (equalFunc) == "function") {
                var newRet = [];
                each(ret, function (element) {
                    if (equalFunc(element) === true) {
                        newRet.push(element);
                    }
                });
                return newRet;
            }

            return ret;
        };

        var _getArr = function (arr) {
            var ret = [];
            each(arr, function (item) {
                var _temp = _get(item, parentElement, equalFunc);
                each(_temp, function (tempItem) {
                    ret.push(tempItem);
                });
            });
            return ret;
        };

        if (typeof (tagName) == "string") {
            if (typeof (tagName) == "string" && tagName.indexOf(",") !== -1) {
                var arr = tagName.replace(/^\s+$/g, "").split(",");
                return _getArr(arr);
            } else {
                return _get(tagName);
            }
        } else if (tagName instanceof Array || tagName.length) {
            return _getArr(tagName);
        } else {
            throw new Error("Bad tag name!");
        }
    };

    domReady = _CommonScriptLibrary.domReady = function (callback) {
        if (typeof (callback) == "function") {
            addEvent(window, "load", callback);
        }
    };
    //Get param value from url string
    getUriParamValue = _CommonScriptLibrary.getUriParamValue = function (name, preserveRaw) {
        var preserveRaw = typeof (preserveRaw) != "undefined" ? preserveRaw : false;
        if (!name)
            return null;
        var re = new RegExp("(?:[\&]|[\?])" + name + "=([^\\#\\&\\f\\n\\r\\t\\v]+)"),
            matches = re.exec(location.search);
        var val = matches ? RegExp.$1 : null;
        if (val != null && !preserveRaw) {
            val = decodeURIComponent(val);
        }
        return val;
    };

    getElementsByTagNames = _CommonScriptLibrary.getElementsByTagName = function (str) {
        if (typeof (str) != "string") {
            return;
        }
        _s = str.replace(/(\s+)/, "");
        var tags = _s.split(",");
        var elements = [];
        each(tags, function (tag) {
            var tagElements = geByTagName(tag);
            each(tagElements, function (element) {
                elements.push(element);
            });
        });
        return elements;
    };

    addEvent = _CommonScriptLibrary.addEvent = function (el, ev, handler) {
        if (el.addEventListener) {
            return el.addEventListener(ev, handler, false);
        } else if (el.attachEvent) {
            return el.attachEvent("on" + ev, handler);
        }
    };

    removeEvent = _CommonScriptLibrary.removeEvent = function (el, ev, handler) {
        if (el.removeEventListener) {
            return el.removeEventListener(ev, handler, false);
        } else if (el.detachEvent) {
            return el.detachEvent("on" + ev, handler);
        }
    };

    hasClass = _CommonScriptLibrary.hasClass = function (elem, className) {
        var re = new RegExp("\\b(" + className + ")\\b");
        var el = ge(elem);
        return (el) ? re.test(el.className) : false;
    };

    addClass = _CommonScriptLibrary.addClass = function (elem, className) {
        var el = ge(elem);
        if (el) {
            el.className += (/\b(\S+)\b/.test(el.className)) ? "\u0020" + className : className;
        }
    };

    removeClass = _CommonScriptLibrary.removeClass = function (elem, className) {
        var el = ge(elem);
        if (!el) {
            return false;
        }
        var str = el.className;
        var delWS = function (s) {
            var re = /\b(\s\s+)\b/;
            while (re.test(s)) {
                s = s.replace(re, "\u0020");
            }
            s = s.replace(/^\s+/, "").replace(/\s+$/, "");
            return s;
        }
        var re = new RegExp("\\b(" + className + ")\\b");
        str = str.replace(re, "");
        el.className = delWS(str);
    };

    toggleClass = _CommonScriptLibrary.toggleClass = function (elem, className) {
        var el = ge(elem);
        if (hasClass(el, className)) {
            removeClass(el, className);
        } else {
            addClass(el, className);
        }
    };

    getElementsByClass = _CommonScriptLibrary.getElementsByClass = function (className) {
        var elements = geByTagName("*");
        var arr = [];
        each(elements, function (element, i) {
            if (hasClass(element, className)) {
                arr.push(element);
            }
        });
        return arr;
    };

    //Get element text
    getElementText = function (elem) {
        elem = ge(elem);
        if (elem.innerText) {
            return elem.innerText;
        }
        var result = "";
        if (elem != null) {
            var it = function (el) {
                each(el.childNodes, function (child, i) {
                    switch (child.nodeType) {
                        case 1: (function (ch) { it(ch); })(child);
                            break;
                        case 3: result += child.nodeValue;
                            break;
                        default: break;
                    }
                });
            }
            it(elem);
        }
        return result;
    };

    getNodeText = function (node) {
        return getElementText(node);
    };

    //Create new dom element with tagName and options
    newElement = function (tagName, options, doc) {
        var forIn = eachProperty;
        var d = doc || document;

        var el = d.createElement(tagName.toUpperCase());

        forIn(options.style, function (v, k) {
            var _k = k.replace(/(-)(.)/g, "$2");
            el.style[_k] = v;
        });

        forIn(options.attributes, function (v, k) {
            if (el[k]) {
                el[k] = v;
            } else {
                el.setAttribute(k, v);
            }
        });

        if (options.id) {
            el.id = options.id;
        }

        var css = options.cssClass || options.css || options.className;
        if (css) {
            el.className = css;
        }

        forIn(options.handlers, function (handler, evName) {
            addEvent(el, evName.replace(/(^on)(.+)$/, "$2"), handler);
        });
        if (options.text) {
            var txt = d.createTextNode(options.text);
            el.appendChild(txt);
        }

        return el;
    };

    // iterator = function(item, key, counter) { }
    each = function (arr, iterator) {
        for (var i = 0; i < arr.length; i++) {
            if (iterator.call(arr, arr[i], i) === false) {
                break;
            }
        }
    };

    //Iterate properties from object
    eachProperty = function (obj, iterator) {
        for (var key in obj) {
            if (iterator.call(obj, obj[key], key) === false) {
                break;
            }
        }
    };

    //Check that an array contains the specified value
    inArray = function (arr, val, strictComparison) {
        var result = false;
        each(arr, function (el, i) {
            if (el === val || ((strictComparison === false) && (el == val))) {
                result = i;
                return false;
            }
        });
        return result;
    };

    //Check that an array contains the specified value
    var arrayIndexOf = window.arrayIndexOf = function (arr, val, strictComparison) {
        var result = -1;
        each(arr, function (el, i) {
            if (el === val || ((strictComparison === false) && (el == val))) {
                result = i;
                return false;
            }
        });
        return result;
    };

    var arrayContains = window.arrayContains = function (arr, val, strictComparison) {
        return arrayIndexOf(arr, val, strictComparison) !== -1;
    };

    //Clone array
    clone = function (arr) {
        var result = [];
        each(arr, function (el, i) {
            result[i] = el;
        });
        return result;
    };

    odd = function (arr) {
        var r = [];
        each(arr, function (el, i) {
            if (isOdd(i)) {
                r.push(el);
            }
        });
        return r;
    };

    isOdd = function (i) {
        return (i % 2 !== 0);
    };

    //Find max z-index in dom
    maxZIndex = function (elem) {
        var zindex = 0;
        var elem = elem || document;
        var els = elem.getElementsByTagName("*");
        each(els, function (el) {
            var num = (el.style !== undefined) ? parseInt(el.style.zIndex) : NaN;
            if (!isNaN(num) && num > zindex) {
                zindex = num;
            }
        });
        return zindex;
    };

    //Alert all properties in object
    alertObject = function (obj) {
        var s = "";
        eachProperty(obj, function (value, key) {
            s += key + ": " + value + "\r\n";
        });
        alert(s);
    };

    show = function (el, layout) {
        el = ge(el);
        if (!el) {
            return false;
        }
        if (el.style.display === "none") {
            el.style.display = layout ? layout : "block";
        }
        if (el.style.visibility !== "visible") {
            el.style.visibility = "visible";
        }
    };

    hide = function (el) {
        el = ge(el);
        if (!el) {
            return false;
        }
        if (el.style.display !== "none") {
            el.style.display = "none";
        }
    };

    //23.03.2011
    //Check that point exists in element rect
    //point = (x,y)
    isPointInElementRect = function (element, point) {
        var startPoint = {
            "x": element.offsetLeft,
            "y": element.offsetTop
        };
        var endPoint = {
            "x": element.offsetLeft + element.clientWidth,
            "y": element.offsetTop + element.clientHeight
        };

        return (point.x >= startPoint.x && point.x <= endPoint.x) && (point.y >= startPoint.y && point.y <= endPoint.y);
    };

    //Get view port
    //view port = (height,width)
    getViewPort = function () {
        var viewPort = {};
        if (typeof (window.innerHeight) != "undefined") {
            viewPort.height = window.innerHeight;
            viewPort.width = window.innerWidth;
        } else if (typeof (document.documentElement) != "undefined") {
            viewPort.height = document.documentElement.clientHeight;
            viewPort.width = document.documentElement.clientWidth;
        } else {
            var body = geByTagName("body")[0];
            viewPort.height = body.clientHeight;
            viewPort.width = body.clientWidth;
        }
        return viewPort;
    };

    //Remove all nodes from node
    clearNode = function (node) {
        node.innerHTML = "";
        /*for (i = 0; i < node.childNodes.length; i++) {
        node.removeChild(node.childNodes[i]);
        }*/
    };

    //Set text to node
    setNodeText = function (node, text) {
        clearNode(node);
        var textNode = document.createTextNode(text);
        node.appendChild(textNode);
    };

    //Remove text nodes from node
    removeTextFromNode = function (node) {
        each(node.childNodes, function (childNode) {
            if (childNode.nodeType === 3) {
                node.removeChild(childNode);
            }
        });
    };

    //Alert function time span
    alertCodeTime = function (f) {
        var t = new Date().getTime();
        f.call(null);
        alert(new Date().getTime() - t);
    };

    //Fire element click
    fireElementClick = function (element) {
        if (element.fireEvent) {
            element.fireEvent("onclick");
        } else {
            var ev = document.createEvent("MouseEvents");
            ev.initMouseEvent(
                "click",
                true,
                true,
                this,
                0,
                0,
                0,
                0,
                0,
                false,
                false,
                false,
                false,
                0,
                null
            );
            element.dispatchEvent(ev);
        }
    };

    //Prevent default event
    preventDefault = function (ev) {
        if (ev.preventDefault) {
            ev.preventDefault();
        } else {
            ev.returnValue = false;
        }
        return false;
    };

    //Get selected text
    getSelText = function () {
        var text = "";
        if (window.getSelection) {
            text = window.getSelection().toString();
        } else if (document.selection && document.selection.type === "Text") {
            text = document.selection.createRange().text;
        }
        return text;
    };

    //Check that a node contains a selected text
    isSelTextInNode = function (node) {
        var selText = getSelText();
        return selText.length > 0 && getNodeText(node).search(selText) > -1;
    };

    //extend parent class
    extend = _CommonScriptLibrary.extend = function (Child, Parent, extender) {
        var F = new Function();
        F.prototype = Parent.prototype;
        var childPrototype = Child.prototype = new F();
        Child.prototype.constructor = Child;
        Child.superclass = Parent.prototype;

        if (extender) {
            for (propertyName in extender) {
                Child.prototype[propertyName] = extender[propertyName];
            }
        }
    };

    //Get current cursor postition in textbox element
    getCursorPos = function (tb) {
        if (typeof (tb.selectionStart) != "undefined") {
            return tb.selectionStart;
        } else if (tb.createTextRange) {
            var tr = tb.createTextRange();
            try {
                tr.setEndPoint("EndToStart", document.selection.createRange());
            } catch (e) { }
            return tr.text.length;
        }
    };

    var getSelectedTextCtx = window.getSelectedTextCtx = function (tb) {
        var createCtx = function (from, to, text) {
            return { from: from, to: to, text: text, length: text == null ? 0 : text.length };
        };
        if (typeof (tb.selectionStart) != "undefined") {
            var from = tb.selectionStart,
                to = tb.selectionEnd,
                text = tb.value.substr(from, to - from),
                ctx = createCtx(from, to, text);
            return ctx;
        } else if (document.selection || tb.createTextRange) {
            tb.focus();
            var tr = tb.createTextRange();
            var sel = document.selection.createRange();
            var selectedText = sel.text;
            tr.setEndPoint("EndToStart", sel);
            var startPos = tr.text.length;
            tr.setEndPoint("StartToEnd", sel);
            var endPos = tr.text.length + startPos;
            return createCtx(startPos, endPos, sel.text);
        }
        return null;
    };

    var setCursorPos = window.setCursorPos = function (tb, pos) {
        if (tb.createTextRange) {
            var range = tb.createTextRange();
            range.move("character", pos);
            range.select();
        } else {
            if (tb.selectionStart) {
                tb.focus();
                tb.setSelectionRange(pos, pos);
            } else {
                tb.focus();
            }
        }
        /*var tr = document.selection.createRange();
        var sel = window.getSelection();
        tr.selStart(tb, pos);
        tr.collapse(true);
        sel.removeAllRanges();
        sel.addRange(tr);*/
    };

    //Format string
    strformat = function (str, format) {
        var CHAR = "#";

        if (typeof (str) != "string") {
            throw new Error("Bad argument \"str\"!");
        }

        var ret = "";

        var counter = 0;
        for (var i = 0; i < format.length; i++) {
            var currFChar = format.charAt(i);
            if (currFChar == CHAR) {
                ret += str.charAt(counter++);
            } else {
                ret += currFChar;
            }
        }

        return ret;
    };

    removeWhitespaces = function (tb, re) {
        tb.value = re ? tb.value.replace(re, "") : tb.value.replace(/\s+/g, "");
    };

    //get browser name (msie, webkit, firefox, opera)
    getBrowser = function () {
        var IE = "msie";
        var FIREFOX = "firefox";
        var WEBKIT = "webkit";
        var OPERA = "opera";

        var isFound = function (re) {
            return userAgent.search(re) !== -1
        }

        if (window.navigator && window.navigator.userAgent) {
            var userAgent = window.navigator.userAgent.toLowerCase();
            if (isFound(/(msie)\s(\d\.\d)/)) {
                return IE;
            } else if (isFound(/(webkit)/)) {
                return WEBKIT;
            } else if (isFound(/(firefox)/)) {
                return FIREFOX;
            } else if (isFound(/(opera)/)) {
                return OPERA;
            } else {
                return "undefined";
            }
        } else {
            throw new Error("Unable to get userAgent from window object!");
        }
    };

    //format number to static length string (00001, where digits = 5, num = 1)
    formatNumber = function (num, digits) {
        var numText = num.toString();
        if (numText.length >= digits) return numText;

        var 
            shift = digits - numText.length,
            s = "";

        for (var i = 0; i < shift; i++) {
            s += "0";
        }
        return s + numText;
    };

    //format sum number with the docs style
    var formatSum = window.formatSum = _CommonScriptLibrary.formatSum = function (sum, decimalSeparator, groupSeparator) {
        var groupSeparator = groupSeparator ? groupSeparator : "";
        if (!sum) return sum;
        var 
            integralPartStringBuffer = "",
            fsum = Math.floor(sum),
            rsum = sum - fsum,
            rsum2digits = Math.round(rsum * 100),
            decimalSeparator = decimalSeparator || "-";

        if (groupSeparator.length) {
            var arr = [];
            var fsumString = fsum.toString();
            var fsumStringLength = fsumString.length;
            var counter = 1;
            for (var i = fsumStringLength - 1; i >= 0; i--) {
                var currChr = fsumString.charAt(i);
                arr.push(currChr);
                if (counter++ % 3 === 0) {
                    arr.push(groupSeparator);
                }
            }
            arr.reverse();
            integralPartStringBuffer = arr.join("");
        } else {
            integralPartStringBuffer = fsum.toString();
        }
        return integralPartStringBuffer + decimalSeparator + formatNumber(rsum2digits, 2);
    };

    //format timezone offset to s99:99 pattern
    formatTimezoneOffset = function (timezoneOffset) {
        if (typeof (timezoneOffset) == undefined) return "Z";

        var 
            sign = timezoneOffset < 0 ? "-" : "+",
            hours = Math.floor(Math.abs(timezoneOffset) / 60),
            minutes = timezoneOffset % 60;

        return sign + formatNumber(hours, 2) + ":" + formatNumber(minutes, 2);
    }

    //convert date to wcf web service style date parameter
    dateToWCF = function (date) {
        return "\/Date(" + dateToMT(date) + ')\/';
    };

    //convert date to iso 8601 style
    var dateToISO8601 = window.dateToISO8601 = function (date, mode) {
        mode = mode ? mode : "dt";
        var 
            s = "",
            formatNumber = function (num, digits) {
                var numText = num.toString();
                if (numText.length >= digits) return numText;

                var s = "", shift = digits - numText.length;
                for (var i = 0; i < shift; i++) {
                    s += "0";
                }
                return s + numText;
            };

        var includeDate = mode.indexOf("d") !== -1, includeTime = mode.indexOf("t") !== -1;
        if (includeDate) {
            s += formatNumber(date.getFullYear(), 4);
            s += "-";
            s += formatNumber(date.getMonth() + 1, 2);
            s += "-";
            s += formatNumber(date.getDate(), 2);
            if (includeTime) s += "T";
        }

        if (includeTime) {
            s += formatNumber(date.getHours(), 2);
            s += ":";
            s += formatNumber(date.getMinutes(), 2);
            s += ":";
            s += formatNumber(date.getSeconds(), 2);
            s += ".";
            s += formatNumber(date.getMilliseconds(), 3);
            s += formatTimezoneOffset(date.getTimezoneOffset());
        }
        return s;
    };

    //formats date like milliseconds+timezone
    var dateToMT = window.dateToMT = function (date) {
        var milliseconds = date.getTime(),
            timezoneOffset = date.getTimezoneOffset(),
            timezoneOffsetStr = timezoneOffset > 0 ? "+" + timezoneOffset : timezoneOffset;
        return milliseconds.toString().concat(timezoneOffsetStr);
    };

    //parse (deserialize) JSON to object
    parseJSON = function (json) {
        try {
            if (typeof (JSON) != "undefined") {
                return JSON.parse(json);
            }

            eval("var __obj=" + json + ";");
            return __obj;
        } catch (e) {
            return null;
        }
    };


    isArray = function (arr) {
        return typeof (arr) === "object" && (arr instanceof Array || (arr.length && arr.push));
    };

    isObject = function (obj) {
        return typeof (obj) === "object" && !isArray(obj);
    };

    isFunction = function (func) {
        return typeof (func) === "function";
    };

    isDate = function (date) {
        return (date instanceof Date) || ~Object.prototype.toString.call(date).indexOf("Date");
    };

    isRegExp = function (re) {
        return re instanceof RegExp;
    };

    //serialize object to JSON
    toJSON = function (obj, settings) {
        if (typeof (JSON) != "undefined") {
            return JSON.stringify(obj);
        }

        var arrayToJSON = function (arr) {
            var 
                acc = "[",
                counter = 0;

            for (var i = 0; i < arr.length; i++) {
                if (counter++ > 0) acc += ",";
                acc += toJSON(arr[i], settings);
            }
            return acc + "]";
        };

        var dateToJSON = dateToISO8601; //default date style is iso 8601 style						
        if (settings && settings.dateStyle && settings.dateStyle === "wcf") dateToJSON = dateToWCF; // wcf style

        if (typeof (obj) == "function") {
            return "";
        } else if (typeof (obj) == "string") {
            return "\"" + obj + "\"";
        } else if (typeof (obj) == "number" || typeof (obj) == "boolean") {
            return obj.toString();
        } else if (isDate(obj)) {
            return "\"" + dateToJSON(obj) + "\"";
        } else if (isArray(obj)) {
            return arrayToJSON(obj);
        } /* else if (isRegExp(obj)) {
			return toJSON({"pattern":obj.toString().replace(/(^)(\/)/, "$1").replace(/(\/)($)/, "$2").replace(/(\\)/g, "\\\\")});
		}*/

        //is object
        var 
            counter = 0,
            s = "{";

        for (var k in obj) {
            var currVal = obj[k];
            if (typeof (currVal) == "undefined") continue;
            if (typeof (currVal) == "function") continue;
            if (counter++ > 0) s += ",";
            s += "\"" + k + "\"" + ":";
            if (currVal === null) {
                s += "null";
            } else if (typeof (currVal) == "string") {
                s += "\"" + currVal + "\"";
            } else if (typeof (currVal) == "number" || typeof (currVal) == "boolean") {
                s += currVal.toString();
            } else if (isDate(currVal)) {
                s += "\"" + dateToJSON(currVal) + "\"";
            } else if (isArray(currVal)) {
                s += arrayToJSON(currVal);
            } else if (isObject(currVal)) {
                s += toJSON(currVal, settings);
            }
        }
        return s + "}";
    };

    createXHR = function () {
        var xhr = null;
        try {
            xhr = new XMLHttpRequest();
        } catch (e) {
            try {
                xhr = new ActiveXObject("Msxml2.XMLHTTP");
            } catch (e) {
                try {
                    xhr = new ActiveXObject("Microsoft.XMLHTTP");
                } catch (e) {
                    throw new Error("Unable to create XMLHttpRequest!");
                }
            }
        }
        return xhr;
    };

    //send ajax request
    sendRequest = sendRequest = function (args) {
        var 
            xhr = createXHR(),

            DEFAULT_CONTENT_TYPE = "application/x-www-form-urlencoded",

            async = typeof (args.async) != "undefined" ? args.async : true,

            method = args.method ? args.method : "GET";

        try {
            xhr.open(method, args.url, async);
            if (method === "POST" || method === "PUT") {
                var contentType = args.contentType ? args.contentType : DEFAULT_CONTENT_TYPE;
                if (args.charset) contentType += "; charset=" + args.charset;
                xhr.setRequestHeader("Content-Type", contentType);
            }
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4) {
                    if (xhr.status === 200) {
                        var contentType = xhr.getResponseHeader("Content-Type");
                        var result = null;
                        if (contentType.search("xml") !== -1) {
                            result = xhr.responseXML;
                        } else if (contentType.search("application/json") !== -1) {
                            result = parseJSON(result);
                        } else if (contentType === "application/octet-stream") {
                            result = xhr.responseBody;
                        } else {
                            result = xhr.responseText;
                        }
                        if (typeof (args.success) === "function") args.success(result, xhr);
                    } else {
                        if (typeof (args.error) === "function") args.error(xhr);
                    }
                }
            };
            xhr.send(typeof (args.data) != "undefined" ? args.data : "");
        } catch (ex) {
            if (args.error) {
                args.error(xhr, ex);
            }
        }
    };

    //Get resource by URI
    GET = function (uri) {
        var resource = null;
        sendRequest({
            "url": uri,
            "async": false,
            "success": function (data) {
                resource = data;
            },
            "error": function (xhr) {
                throw new Error("Unable to GET resource! HttpStatusCode: " + xhr.status);
            }
        });
        return resource;
    };

    //Check that string s1 equals with string s2
    strequals = function (s1, s2, ignoreCase) {
        var 
            arr1 = [],
            arr2 = [],

            s1 = ignoreCase == true ? s1.toLowerCase() : s1,
            s2 = ignoreCase == true ? s2.toLowerCase() : s2;

        if (s1.length !== s2.length) return false;

        for (var i = 0; i < s1.length; i++) {
            if (s1.charCodeAt(i) !== s2.charCodeAt(i)) {
                return false;
            }
        }

        return true;
    };

    if (String.prototype.equals === undefined) {
        String.prototype.equals = function (s, ignoreCase) {
            return strequals(this, s, ignoreCase);
        }
    }

    //check that string str include string substr
    strcontains = function (str, substr, ignoreCase) {
        var 
            strCodes = "",
            str = ignoreCase ? str.toLowerCase() : str,
            substr = ignoreCase ? substr.toLowerCase() : substr;

        for (var i = 0; i < str.length; i++) strCodes += str.charCodeAt(i);

        var substrCodes = "";
        for (var i = 0; i < substr.length; i++) substrCodes += substr.charCodeAt(i);

        return strCodes.search(substrCodes) !== -1;
    };

    if (String.prototype.contains === undefined) {
        String.prototype.contains = function (substr, ignoreCase) {
            return strcontains(this, substr, ignoreCase);
        };
    }

    addURIParameter = function (uri, name, value) {
        var startChar = uri.search("?") !== -1 ? "&" : "?";
        return uri + startChar + name + "=" + encodeURIComponent(value);
    }

    //navigate to url
    go = function (url) {
        TerminalUI.loggingService.debug("go navigating " + url);
        return;
        commonNavigate(url);
    };

    commonNavigate = function (url) {
        TerminalUI.loggingService.debug("commonNavigate navigating " + url);
        if (typeof (window.navigate) === "function") {
            window.navigate(url);
        } else {
            var url = encodeURI(url);
            window.location.href = url;
        }
    };

    //filter array by cmp function and return new filtered array
    filterArray = function (arr, cmp) {
        var ret = [];
        each(arr, function (item) {
            if (cmp(item) === true) {
                ret.push(item);
            }
        });
        return ret;
    };

    //use script
    useScript = function (scriptPath, func, async) {
        var 
            _notifiers = [],
            isArray = scriptPath.length && typeof (scriptPath) !== "string",
            arr = !isArray ? [scriptPath] : scriptPath,
            scripts = filterArray(document.scripts || geTag("SCRIPT"), function (script) { return !!script.src; }),
            head = document.head || geTag("HEAD")[0],
            browser = getBrowser();

        _notifiers.isReady = function () {
            var ready = true;
            each(_notifiers, function (notifier) {
                if (!notifier.ready) ready = false;
            });
            return ready;
        };

        _notifiers.notify = function () {
            if (_notifiers.isReady()) {
                if (func) func();
            }
        };
        each(arr, function (scriptPath) {
            var 
                isScriptExists = false,
                scriptObj = typeof (scriptPath) === "string" ? { "path": scriptPath} : scriptPath,
                link = ca("", scriptObj.v ? scriptObj.path + "?v=" + scriptObj.v : scriptObj.path);

            each(scripts, function (script) {
                if (script.src === link.href) {
                    isScriptExists = true;
                    _notifiers.push({
                        "element": script,
                        "ready": true
                    });
                }
            });
            if (!isScriptExists) {
                var element = ce("SCRIPT");
                element.type = "text/javascript";
                if (scriptObj.defer) {
                    element.defer = true;
                }
                if (async === false || func === false) {
                    _notifiers.push({ "element": element, "ready": true });
                    element.text = GET(link.href);
                } else {
                    var notifier = {
                        "element": element,
                        "ready": false
                    };
                    _notifiers.push(notifier);
                    !function (notifier) {
                        if (browser === "msie") {
                            addEvent(element, "readystatechange", function () {
                                if (element.readyState === "loaded" || element.readyState === "complete") {
                                    notifier.ready = true;
                                    _notifiers.notify();
                                }
                            });
                        } else {
                            addEvent(element, "load", function () {
                                notifier.ready = true;
                                _notifiers.notify();
                            });
                        }
                    } (notifier);
                    element.src = scriptObj.v ? scriptObj.path + "?v=" + scriptObj.v : scriptObj.path;
                }

                head.appendChild(element);
            }
        });
        _notifiers.notify();
    };

    //parse date like /Date(...)/
    parseDate = function (dateText) {
        var date = new Date(parseInt(dateText.replace(/\/Date\(([0-9+-]+)\)\//, "$1")));
        return date;
    };

    //parse a date in the ISO8601 format
    parseDateISO8601 = function (text) {
        var 
            parseDate = function (matches) {
                var 
                    year = matches[0],
                    month = matches[1] - 1,
                    day = matches[2];

                return new Date(year, month, day);
            },

            DateParser = {
                parseDate: function (text) {
                    var matches = text.split("-");
                },
                parseTime: function (text) { }
            };

        if (text.indexOf("T") != -1) {
            var 
                matches = text.split("T"),
                dateMatches = matches[0].split("-"),
                date = parseDate(dateMatches),
                timeMatches = matches[1].split(":"),
                hours = timeMatches[0],
                minutes = timeMatches[1],
                secondsPart = timeMatches[2];

            date.setHours(hours);
            date.setMinutes(minutes);
            if (secondsPart.indexOf(".") !== -1) {
                var 
                    secondsMatches = secondsPart.split("."),
                    seconds = secondsMatches[0],
                    milliseconds = secondsMatches[1];

                date.setSeconds(seconds);
                date.setMilliseconds(milliseconds);
            } else {
                var seconds = secondsPart;
                date.setSeconds(seconds);
            }
            return date;
        } else {
            if (text.indexOf("-") === -1) {
                throw new Error("Invalid input text!");
            } else {
                var matches = text.split("-");
                return parseDate(matches);
            }
        }
    };

    //Select nodes from node with xpath expression
    xpath = function (node, expression) {
        var docNodes = null;
        if (window.ActiveXObject) {
            docNodes = node.selectNodes(expression);
        } else if (document.implementation && document.implementation.createDocument) {
            var xpathResult = node.evaluate(expression, node, null, XPathResult.ANY_TYPE, null);
            docNodes = [];
            var buf = xpathResult.iterateNext();
            while (buf) {
                docNodes.push(buf);
                buf = xpathResult.iterateNext();
            }
        }
        return docNodes;
    };

    //Check that the element is child of the specified parentElement
    isElementChildOf = function (element, parentElement) {
        if (!parentElement.childNodes) return false;
        var isChildOf = false;
        each(parentElement.childNodes, function (childElement) {
            isChildOf = childElement === element ? true : isElementChildOf(element, childElement);
            if (isChildOf === true) return false;
        });
        return isChildOf;
    };

    //Create anchor element
    ca = function (text, href, target, className) {
        var anchor = ce("A");
        anchor.appendChild(document.createTextNode(text));
        anchor.href = href;
        if (target) {
            anchor.setAttribute("target", target);
        }
        if (className)
            anchor.className = className;
        return anchor;
    };

    //Create the image element
    ci = function (src, width, height) {
        var image = new Image();
        if (width) image.width = width;
        if (height) image.height = height;
        if (src) image.src = src;
        return image;
    };

    //Check that the object is defined
    isDef = function (obj) {
        return typeof (obj) !== "undefined";
    };

    //Open new window
    openWindow = function (name, url, features) {
        if (url && typeof (url) != "string" && typeof (name) == "string" && !features) {
            features = url;
            url = name;
            name = "";
        }
        var _features = "";
        if (typeof (features) == "string") {
            _features = features;
        } else {
            eachProperty(features, function (value, key) {
                var _value = "";
                if (typeof (value) == "boolean") {
                    _value = value ? "yes" : "no";
                }
                _features += key + "=" + _value + ",";
            });
            _features = _features.replace(/(.+),$/, "$1");
        }
        return window.open(url, name, _features);
    };

    var strtrim = window.strtrim = function (text) {
        return typeof (text) === "string" ? text.replace(/^\s*(.*)\s*$/g, "$1") : null;
    };

    var isEmpty = window.isEmpty = _CommonScriptLibrary.isEmpty = function (str) {
        return typeof (str) === "undefined" || str === null || /^\s*$/.test(str);
    };

    var stringIsEmpty = window.stringIsEmpty = _CommonScriptLibrary.stringIsEmpty = isEmpty;

    //format a date using specified format
    var formatDate = window.formatDate = _CommonScriptLibrary.formatDate = function (date, format) {
        var 
            day = date.getDate(),
            dayOfWeek = date.getDay(),
            month = date.getMonth() + 1,
            year = date.getFullYear(),
            hours = date.getHours(),
            minutes = date.getMinutes(),
            seconds = date.getSeconds(),
            milliseconds = date.getMilliseconds(),
            timeZone = date.getTimezoneOffset(),

            fill = function (num, size) {
                var s = "";
                for (var i = 0; i < size - num.toString().length; i++) s += "0";
                return s + num.toString();
            },

            timeZoneSign = timeZone < 0 ? "-" : "+",
            timeZoneHours = Math.floor(Math.abs(timeZone) / 60),
            timeZoneMinutes = Math.abs(timeZone) % 60,

            clearDate = new Date(year, 0, 1),
            dayOfYear = Math.floor((date.getTime() - clearDate.getTime()) / (1000 * 60 * 60 * 24)),
            s = format,
            replace = String.prototype.replace,
            reduceS = function (pattern, fillResult) {
                s = replace.call(s, pattern, fillResult);
                return reduceS;
            };

        timeZone = timeZoneSign + fill(timeZoneHours, 2) + ":" + fill(timeZoneMinutes, 2);
        reduceS
            (/yyyy/g, year)
            (/yy/g, year % 100)
            (/dd/g, fill(day, 2))
            (/d/g, day)
            (/MM/g, fill(month, 2))
            (/HH/g, fill(hours, 2))
            (/H/g, hours)
            (/mm/g, fill(minutes, 2))
            (/m/g, minutes)
            (/ss/g, fill(seconds, 2))
            (/s/g, seconds)
            (/SSS/g, fill(milliseconds, 3))
            (/SS/g, fill(milliseconds, 2))
            (/S/g, milliseconds)
            (/www/g, fill(dayOfWeek, 3))
            (/ww/g, fill(dayOfWeek, 2))
            (/w/g, dayOfWeek)

            (/jjj/g, fill(dayOfYear, 3))
            (/jj/g, fill(dayOfYear, 2))
            (/j/g, dayOfYear)

            (/TZ/g, timeZone);
        /*s = s.replace(/yyyy/g, year);
        s = s.replace(/yy/g, year % 100);
        s = s.replace(/dd/g, fill(day, 2));
        s = s.replace(/d/g, day);
        s = s.replace(/MM/g, fill(month, 2));
        s = s.replace(/HH/g, fill(hours, 2));
        s = s.replace(/H/g, hours);
        s = s.replace(/mm/g, fill(minutes, 2));
        s = s.replace(/m/g, minutes);
        s = s.replace(/ss/g, fill(seconds, 2));
        s = s.replace(/s/g, seconds);
        s = s.replace(/SSS/g, fill(milliseconds, 3));
        s = s.replace(/SS/g, fill(milliseconds, 2));
        s = s.replace(/S/g, milliseconds);
        s = s.replace(/www/g, fill(dayOfWeek, 3));
        s = s.replace(/ww/g, fill(dayOfWeek, 2));
        s = s.replace(/w/g, dayOfWeek);

        s = s.replace(/jjj/g, fill(dayOfYear, 3));
        s = s.replace(/jj/g, fill(dayOfYear, 2));
        s = s.replace(/j/g, dayOfYear);

        s = s.replace(/TZ/g, timeZone);*/
        return s;
    };

    //Transform text from ASomeText to a{delimiter}some{delimiter}text
    breakCamel = function (name, delimiter) {
        var buffer = "";
        for (var i = 0; i < name.length; i++) {
            var 
                chr = name.charAt(i),
                lower = chr.toLowerCase();

            buffer += i > 0 && ~"ABCDEFGHIJKLMNOPQRSTUVWXYZ".indexOf(chr) ? delimiter + lower : lower;
        }
        return buffer;
    };

    // Parse date from ru style
    parseRuDate = function (dateText) {
        var tokens = (dateText.length > 10 ? dateText.substr(0, 10) : dateText).split("."),
            year = parseInt(tokens[2]),
            month = parseInt(tokens[1]) - 1,
            day = parseInt(tokens[0]);

        return new Date(year, month, day);
    };

    // Check that an instance inherits a type with a type name
    isTypeOf = function (instance, typeName) {
        return Object.prototype.toString.call(instance).toLowerCase() === typeName.toLowerCase();
    };

    // Bind the specified value to the specified url parameter in the specified url
    bindUrlParam = function (url, paramName, paramValue) {
        var re = new RegExp("(([?]|&)" + paramName + "=)(({" + paramName + "})|.+)($|(&.*$))", "g");
        return url.replace(re, "$1" + paramValue + "$5");
    };

    // Round a number to certain decimal points
    roundNum = function (num, dec) {
        return Math.round(num * Math.pow(10, dec)) / Math.pow(10, dec);
    };

    // Format file size like "999.9 �."
    var formatFileSize = window.formatFileSize = function (size) {
        var UNITS = [TNG.generalResources["BYTE_UNIT"], TNG.generalResources["KILOBYTE_UNIT"], TNG.generalResources["MEGABYTE_UNIT"], TNG.generalResources["KILOBYTE_UNIT"], TNG.generalResources["GYGABYTE_UNIT"], TNG.generalResources["TERABYTE_UNIT"]],
            BYTE_LENGTH = 1024,
            currUnit = UNITS[0],
            tempSize = size,
            counter = 0,
            decimalSeparator = TNG.format["decimalSeparator"];

        while (tempSize >= BYTE_LENGTH) {
            tempSize /= BYTE_LENGTH
            currUnit = UNITS[++counter];
        }

        return tempSize.toFixed(1).replace(/\./, decimalSeparator).replace(decimalSeparator + "0", "") + "\u00a0" + currUnit;
    };

    // Extend the specified source object by the specified extender object	
    var extendObject = window.extendObject = _CommonScriptLibrary.extendObject = function (original, extenders) {
        var _extendObject = function (extender) {
            for (propertyName in extender) {
                original[propertyName] = extender[propertyName];
            }
            return original;
        },
		i = 1;
        for (; i < arguments.length; i++) {
            var currExtender = arguments[i];
            _extendObject(currExtender);
        }
        return original;
    };

    // Retrieve browser and platform info from the current useragent
    var getBrowserInfo = window.getBrowserInfo = function () {
        var userAgent = window.navigator.userAgent,
            re = {
                "ie": /MSIE (\d\.\d); Windows NT (\d\.\d); Trident\/(\d\.\d)/,
                "ieMobile": /MSIE (\d\.\d); Windows Phone OS (\d\.\d); Trident\/(\d\.\d); IEMobile\/(\d\.\d)/,
                "firefox": /Firefox\/([\d\.]+)/,
                "webkit": /AppleWebKit\/([\d\.]+)/
            },
            tokens = null,
            defaultResult = { "isIE": false, "isIEMobile": false, "isFirefox": false, "isOpera": false, "isWebKit": false };

        if ((tokens = re["ie"].exec(userAgent)) != null) {
            return extendObject(defaultResult, { "isIE": true, "version": tokens[1], "osVersion": tokens[2], "trident": tokens[3] });
        } else if ((tokens = re["ieMobile"].exec(userAgent)) != null) {
            return extendObject(defaultResult, { "isIEMobile": true, "version": tokens[1], "osVersion": tokens[2], "trident": tokens[3], "ieMobileVersion": tokens[4] });
        } else if ((tokens = re["firefox"].exec(userAgent))) {
            return extendObject(defaultResult, { "isFirefox": true, "version": tokens[1] });
        } else if ((tokens = re["webkit"].exec(userAgent))) {
            return extendObject(defaultResult, { "isWebKit": true, "version": tokens[1] });
        }

        return defaultResult;
    };

    var passParametersXSLIE = window.passParametersXSLIE = function (xslProcessor, parameters) {
        eachProperty(parameters, function (value, key) {
            if (typeof (value) != "undefined" && value != null) {
                xslProcessor.addParameter(key, value);
            }
        });
    };

    var transformDocIE = window.transformDocIE = function (xmlDoc, xslDoc, parameters) {
        var template = new ActiveXObject("MSXML2.XSLTemplate");
        template.stylesheet = xslDoc;
        var xslProcessor = template.createProcessor();
        xslProcessor.input = xmlDoc;
        if (parameters)
            passParametersXSLIE(xslProcessor, parameters);
        xslProcessor.transform();
        return xslProcessor.output;
    };

    var passClientDateToHREF = window.passClientDateToHREF = function (linkElement) {
        var rawHref = linkElement.href,
            clientDateIndex = rawHref.indexOf("?clientDate="),
            addition = "?clientDate=" + encodeURIComponent(dateToISO8601(new Date()));

        if (~clientDateIndex) {
            linkElement.href = rawHref.substring(0, clientDateIndex) + addition;
        } else {
            linkElement.href = rawHref + addition;
        }
    };

    //Formats an account num like ##### ### # #### #######
    var formatAccount = window.formatAccount = function (account) {
        return account.substr(0, 5) + SPACE_CHAR + account.substr(5, 3) + SPACE_CHAR + account.substr(8, 1) + SPACE_CHAR + account.substr(9, 4) + SPACE_CHAR + account.substr(13, 7);
    };

    // Converts a date to an encoded GET parameter value
    var toDateGETParam = window.toDateGETParam = function (date, isIncludesTime) {
        return encodeURIComponent(dateToISO8601(date, isIncludesTime ? "dt" : "d"));
    };

    var dateToGETParam = window.dateToGETParam = toDateGETParam;

    // Checks that two dates are equal
    var areDatesEqual = window.areDatesEqual = function (dateLeft, dateRight) {
        var areYearsEqual = dateLeft.getFullYear() === dateRight.getFullYear(),
            areMonthsEqual = dateLeft.getMonth() === dateRight.getMonth(),
            areDaysEqual = dateLeft.getDate() === dateRight.getDate();
        return areYearsEqual && areMonthsEqual && areDaysEqual;
    };

    // Creates a query string
    var createQueryString = window.createQueryString = function (tokens) {
        var str = "";
        eachProperty(tokens, function (value, key) {
            var value = value;
            if (isDate(value)) {
                value = dateToGETParam(value, true);
            }
            str += "&" + key + "=" + encodeURIComponent(value);
        });
        return str.substr(1);
    };

    var isJSONResponse = window.isJSONResponse = function (response) {
        var contentType = response.getResponseHeader("Content-Type");
        return !!contentType && ~contentType.search("application/json");
    };

    var callFunctionAsync = window.callFunctionAsync = function (originalFunction, originalFunctionContext, args, delay) {
        var delay = timeout || 0;
        if (!args.callee) {
            args.callee = originalFunction;

        }
        var timeout = setTimeout(function () {
            originalFunction.apply(originalFunctionContext, args);
        }, timeout);
        return timeout;
    };

    var normalizeJSON = window.normalizeJSON = _CommonScriptLibrary.normalizeJSON = function (jsonText) {
        var jsonText = decodeURIComponent(jsonText),
            jsonText = jsonText.replace(/'/g, "\""),
            jsonText = jsonText.replace(/({?)(\s*)(\b[a-zA-Z_\$][a-zA-Z0-9_\$]*\b)(\s*)(:)(\s*)(}?)/g, "$1\"$3\"$5$7");
        return jsonText;

    };

    // Passes a GET parameter to the specified URL (name must be either string or a map of key/value pairs)
    var passParamToURL = window.passParamToURL = _CommonScriptLibrary.passParamToURL = function (url, name, value) {
        var params = null,
            urlCache = url,
            urlBuilder = url;
        if (typeof (name) == "string") {
            params = {};
            params[name] = value;
        } else {
            params = name;
        }

        var needsToBeEncoded = params.hasOwnProperty("__encode") ? params["__encode"] : true;

        var eraseExisting = function (name) {
            var replaceRE = new RegExp("(\\?|&)(" + name + ")=([" + URL_GET_PARAM_VALUE_CHARACTERS.join("") + "]*)(&|(#.*)|$)");
            urlBuilder = urlBuilder.replace(replaceRE, "$4");
            if (urlBuilder.search(/\?/) == -1) {
                urlBuilder = urlBuilder.replace(/\&/, "?");
            }
        };
        var doesURLcontainGETParams = urlCache.search(/\?/) != -1;
        for (var key in params) {
            if (key == "__encode") continue;
            var currValue = params[key];
            if (isDate(currValue)) {
                currValue = dateToISO8601(currValue, "dt");
            }
            var reCheckExistingParam = new RegExp("(\\?|&)" + key);
            var indexOfExistingParam = urlBuilder.search(reCheckExistingParam);
            var valueForUrl = needsToBeEncoded ? encodeURIComponent(currValue) : currValue;
            if (indexOfExistingParam != -1) {
                var existingMatch = urlBuilder.match(reCheckExistingParam)[0];
                eraseExisting(key);
                var leftPart = urlBuilder.substr(0, indexOfExistingParam);
                var rightPart = urlBuilder.substr(indexOfExistingParam);
                var firstChar = existingMatch.charAt(0) == "?" ? "?" : "&";

                urlBuilder = leftPart + firstChar + key + "=" + valueForUrl;
                if (rightPart.length) {
                    if (rightPart.charAt(0) == "#") {
                        urlBuilder += rightPart;
                    } else {
                        urlBuilder += "&" + rightPart.substr(1);
                    }
                }
            } else {
                urlBuilder += doesURLcontainGETParams ? "&" : "?";
                doesURLcontainGETParams = true;
                urlBuilder += key + "=" + valueForUrl;
            }
        }
        return urlBuilder;
    };

    var getCurrentLocalURL = window.getCurrentLocalURL = _CommonScriptLibrary.getCurrentLocalURL = function () {
        var loc = window.location;
        var relPath = loc.pathname + loc.search + loc.hash;
        return relPath;
    };

    var bindContext = window.bindContext = _CommonScriptLibrary.bindContext = function (func, context) {
        return function () {
            return func.apply(context, arguments);
        };
    };

    //Checks that the specified object is dry ({} is a dry object)
    var isDryObject = window.isDryObject = _CommonScriptLibrary.isDryObject = function (obj) {
        var isDry = true;
        eachProperty(obj, function (v, key) {
            isDry = false;
            return false;
        });
        return isDry;
    };

    var cloneObject = window.cloneObject = _CommonScriptLibrary.cloneObject = function (original) {
        if (original == null) {
            throw "An original object is null!";
        }
        if (typeof (original) == "undefined") {
            throw "An original object is undefined!";
        }
        var newObj = {};
        var cloneObjectRecursive = function (newObjOnLevel, originalObjOnLevel) {
            eachProperty(originalObjOnLevel, function (currValue, currKey) {
                if (isObject(currValue)) {
                    var newObjOnNextLevel = newObjOnLevel[currKey] = {};
                    cloneObjectRecursive(newObjOnNextLevel, currValue);
                } else {
                    newObjOnLevel[currKey] = currValue;
                }
            });
        };
        cloneObjectRecursive(newObj, original);
        return newObj;
    };

    var alertJSON = window.alertJSON = _CommonScriptLibrary.alertJSON = function (obj) {
        alert(toJSON(obj));
    };

    var createTuple = window.createTuple = _CommonScriptLibrary.createTuple = function (/*args*/) {
        return arguments.slice(0);
    };

    var hex2ascii = window.hex2ascii = _CommonScriptLibrary.hex2ascii = function (hexString) {
        var charBuffer = "";
        for (var i = 0; i < hexString.length - 1; i += 2) {
            var hexCouple = hexString.substr(i, 2);
            var charCode = parseInt(hexCouple, 16);
            var charString = String.fromCharCode(charCode);
            charBuffer += charString;
        }
        return charBuffer;
    };

    var createPOSTData = window.createPOSTData = _CommonScriptLibrary.createPOSTData = function (mapOrKey, valueIfKey) {
        return passParamToURL("", mapOrKey, valueIfKey).substr(1);
    };

    //Flats a phone number like +7 (910) 999-33-44 to 9109993344.
    var flatPhoneNumber = window.flatPhoneNumber = function (original) {
        var re = /^(?:(?:\+\7)|[\8])\s?\((\d+)\)\s?(\d+)-(\d+)-(\d+)$/;
        re.exec(original);
        var flattenPhoneNumber = RegExp.$1 + RegExp.$2 + RegExp.$3 + RegExp.$4;
        return flattenPhoneNumber;
    };

    //Checks that a client-side code works from a local file.
    //The method returns true if it is local or false if it works through a web server.
    var isLocalFile = window.isLocalFile = function () {
        switch (window.location.protocol) {
            case "http:":
            case "https:": return false;
            case "file:": return true;
            default: return false;
        }
    };

    var getNextSiblingElement = window.getNextSiblingElement = function (element) {
        var sibling = element.nextSibling;
        while (sibling != null && sibling.nodeType !== 1) sibling = sibling.nextSibling;
        return sibling;
    };

    var whenCondition = window.whenCondition = function (conditionFunc, callback, sleepTime, timeout) {
        sleepTime = sleepTime ? sleepTime : 100;
        timeout = timeout ? timeout : null;
        var waitTime = 0;
        var checkConditionFunc = function () {
            return conditionFunc ? conditionFunc() : false;
        };
        var triggerCallback = function () {
            if (callback) callback();
        };
        var interval = setInterval(function () {
            if (checkConditionFunc()) {
                triggerCallback();
                clearInterval(interval);
            } else {
                if (timeout != null) {
                    waitTime += sleepTime;
                    if (waitTime >= timeout) clearInterval(interval);
                }
            }

        }, sleepTime);
    };

    var copyArray = window.copyArray = function (src, dest, destStartIndex, length) {
        destIndex = typeof (destIndex) != "undefined" ? destIndex : 0;
        length = typeof (length) != "undefined" ? length : src.length;

        for (var i = 0; i < length; i++) {
            var destIndex = destStartIndex + 1;
            var srcItem = src[i];
            if (destIndex >= dest.length) {
                dest.push(srcItem);
            } else {
                dest[destIndex] = srcItem;
            }
        }
    };

    var formatMsg = window.formatMsg = function (format, args) {
        var reFormatParam = new RegExp("%" + (i + 1), "g"),
            preventPercentagesFormatting = function (str) {
                var preventStr = str.replace(/%(\d+)/g, "%PERCENT_CHAR_$1");
                return preventStr;
            },
            undoPreventPercentagesFormatting = function (str) {
                var unpreventStr = str.replace(/%PERCENT_CHAR_(\d+)/g, "%$1");
                return unpreventStr;
            },
            parameters = Array.prototype.slice.call(arguments, 1),
            resultMsg = format;
        for (var i = 0; i < parameters.length; i++) {
            var boundValue = parameters[i],
                    preventBoundValue = preventPercentagesFormatting(boundValue.toString());
            resultMsg = resultMsg.replace(new RegExp("%" + (i + 1), "g"), preventBoundValue);
        }
        resultMsg = undoPreventPercentagesFormatting(resultMsg);
        return resultMsg;
    };

    var getCardNumberToShare = window.getCardNumberToShare = function (cardNumber) {
        var len = cardNumber.length;
        var showLen = Math.ceil(len / 4);
        var showNumber = "";
        for (var i = 0; i < len; i++) showNumber += len - i <= showLen ? cardNumber.charAt(i) : "*";
        return showNumber;
    };

    var getTypeName = window.getTypeName = function (instance) {
        var funcNameRegex = /function (.{1,})\(/;
        var results = (funcNameRegex).exec((instance).constructor.toString());
        return (results && results.length > 1) ? results[1] : "";
    };

    var preventDocumentSelection = window.preventDocumentSelection = function () {
        document.body.onselectstart = function () { return false; };
    };

    // Serializes a map as a string to post data to a server using the application/x-www-form-urlencoded content type.
    serializeMapAsPOST = function (map) {
        var EMPTY_STRING = "",
            arr = [],
            pushArr = function (key, val) {
                var keyValArr = [];
                keyValArr.push(key);
                if (val) {
                    keyValArr.push(encodeURIComponent(val));
                } else {
                    keyValArr.push(EMPTY_STRING);
                }
                var serializedKeyValString = keyValArr.join("=");
                arr.push(serializedKeyValString);
            };
        for (var key in map) {
            var val = map[key];
            pushArr(key, val);
        }
        var serializedString = arr.join("&");
        return serializedString;
    };

    var makeSingleton = window.makeSingleton = function (ClassFunction) {
        ClassFunction._instance = null;
        ClassFunction.getInstance = function () {
            var instance = ClassFunction._instance;
            if (instance == null) {
                instance = ClassFunction._instance = new ClassFunction();
            }
            return instance;
        };
        return ClassFunction;
    };

    var getExecutingScriptTag = window.getExecutingScriptTag = function () {
        var scriptTags = document.getElementsByTagName("script");
        var lastScriptTag = scriptTags[scriptTags.length - 1];
        return lastScriptTag;
    };

    var readExecutingScriptTagDataProps = window.readExecutingScriptTagDataProps = function (element) {
        var executingScriptTag = element ? element : getExecutingScriptTag();
        var attrs = executingScriptTag.attributes;
        var propsMap = {};
        for (var i = 0; i < attrs.length; i++) {
            var attr = attrs[i];
            var matches = /^data-(.+)/.exec(attr.nodeName);
            if (matches != null) {
                var propName = matches[1];
                propsMap[propName] = attr.nodeValue;
            }
        }
        return propsMap;
    };

    var getExecutingScriptTagDataProp = window.getExecutingScriptTagDataProp = function (propName) {
        var tagElement = getExecutingScriptTag();
        if (tagElement._dataProps == null) {
            tagElement._dataProps = readExecutingScriptTagDataProps(tagElement);
        }
        var props = tagElement._dataProps;
        return props[propName];
    };

    //Mask a string with the specified mask char (default is *) excepts characters from the specified exclusions array
    var maskString = window.maskString = function (str, maskChar, exclusionsArr) {
        maskChar = maskChar || "*";
        exclusionsArr = exclusionsArr || [];
        str = str || "";

        var maskedStr = "";
        for (var i = 0; i < str.length; i++) {
            var currChar = str.charAt(i);
            maskedStr += arrayContains(exclusionsArr, currChar, false) ? currChar : maskChar;
        }
        return maskedStr;
    };

    var maskCardNum = window.maskCardNum = function (str, arrPartsShown) {
        var arrPartsShown = arrPartsShown || [false, 0, false, 0, false, 0, true];
        var reCardNum = /(\d{4})(\s?)(\d{4})(\s?)(\d{4})(\s?)(\d{4})/g;
        var strReplacePattern = "$1$2$3$4$5$6$7";
        for (var i = 0; i < arrPartsShown.length; i++) {
            if (arrPartsShown[i] === false)
                strReplacePattern = strReplacePattern.replace("$" + (i + 1), "****");
        }
        var maskedStr = str.replace(reCardNum, strReplacePattern);
        return maskedStr;
    };

    var maskCardHolder = function (str) {
        var reCardHolder = /([A-Z]+)\s([A-Z]+)/g;
        var maskedStr = str;
        var matches = null;
        while ((matches = reCardHolder.exec(str)) != null) {
            var fullMatchStr = matches[0];
            var firstStr = matches[1];
            var secondStr = matches[2];

            var maskedName = maskString(formatNumber(1, firstStr.length));
            maskedName += " ";
            maskedName += maskString(formatNumber(1, secondStr.length));

            maskedStr = maskedStr.replace(fullMatchStr, maskedName);
        }
        return maskedStr;
    };

    var maskCardExpiration = function (str) {
        var reCardExpiration = /(\d{2})\/(\d{4})/g;
        var maskedStr = str.replace(reCardExpiration, "**/****");

        var reCardExpiration = /(\d{2})\/(\d{2})/g;
        maskedStr = maskedStr.replace(reCardExpiration, "**/**");
        return maskedStr;
    };

    var maskBankAccountNum = function (str) {
        var reBankAccountNum = /(\d{5})(\s?)(\d{3})(\s?)(\d{1})(\s?)(\d{4})(\s?)(\d{7})/g;
        return str.replace(reBankAccountNum, "*****$2***$4*$6****$8*******");
    };

    var maskBankCardParams = window.maskBankCardParams = function (paramValue, options) {
        var options = options || {};

        var strMasked = paramValue;

        strMasked = maskBankAccountNum(strMasked);
        strMasked = maskCardNum(strMasked, options.arrCardNumPartsShown);
        strMasked = maskCardHolder(strMasked);
        strMasked = maskCardExpiration(strMasked);

        return strMasked;
    };

    var maskCardParam = window.maskCardParam = function (paramName, paramValue) {
        var maskExclusions = [" ", "^", "/", ",", ".", "\\"];
        var paramValueMasked = maskString(paramValue, "*", maskExclusions);
        return paramValueMasked;
    };

    var mapObjectToDictionaryEntries = window.mapObjectToDictionaryEntries = function (obj) {
        var arr = [];
        eachProperty(obj, function (value, key) {
            arr.push({ Key: key, Value: value });
        });
        return arr;
    };
})(window);