﻿
$(function () {
    WaitMsgManager.init();
    SignInPasswordPage.load();
});

var SignInPasswordPage = {
    loggingService: FS.TerminalUI.loggingService,

    $bBack: null,
    $bMenu: null,
    $bForward: null,
    $dlgError: null,
    $bDlgErrorOk: null,
    $lError: null,

    $dlgPromptPasswordRemind: null,
    $bDlgPromptPasswordRemindOK: null,
    $bDlgPromptPasswordRemindCancel: null,

    fieldManager: null,
    tbField: null,
    smartClientManager: SmartClientManager,
    fieldInstance: field,
    fieldElement: null,

    pinPadListener: {
        pinPadCorrectionPressed: function (args) {
            SignInPasswordPage.fieldManager.removeLastLetter();
        },
        pinPadDigitPressed: function (args) {
            SignInPasswordPage.fieldManager.appendLetter(args.letter);
        },
        pinPadAcceptPressed: function (args) {
            if (SignInPasswordPage.$bForward.hasClass("th-hidden")) return;
            SignInPasswordPage.$bForward.click();
        }
    },

    load: function () {
        var self = this;
        this.$bBack = $("#bBack");
        this.$bMenu = $("#bMenu");
        this.$bForward = $("#bForward");
        this.$bDlgErrorOk = $("#bDlgErrorOk");
        this.$dlgError = $("#dlgError");
        this.$lError = $("#lError");
        this.tbField = document.getElementById("tbField");

        this.$dlgPromptPasswordRemind = $("#dlgPromptPasswordRemind");
        this.$bDlgPromptPasswordRemindOK = $("#bDlgPromptPasswordRemindOK");
        this.$bDlgPromptPasswordRemindCancel = $("#bDlgPromptPasswordRemindCancel");

        this.$bDlgPromptPasswordRemindOK.click(function () { self.bDlgPromptPasswordRemindOKClickHandler() });
        this.$bDlgPromptPasswordRemindCancel.click(function () { self.bDlgPromptPasswordRemindCancelClickHandler() });

        this.fieldElement = document.getElementById("field" + this.fieldInstance.ID);
        this.smartClientManager.addListener(this.pinPadListener);
        this.$bForward.click(function () { self.forwardClickHandler() });
        this.$bDlgErrorOk.click(function () { self.hideErrorDlg() });
        var fieldManager = this.fieldManager = new FieldManager();
        fieldManager.init({
            textBox: this.tbField,
            required: true,
            minlength: this.fieldInstance.MinLength,
            maxlength: this.fieldInstance.MaxLength,
            fieldId: this.fieldInstance.ID,
            fieldElement: this.fieldElement,
            oncomplete: function () {
                self.fieldComplete();
            },
            onincomplete: function () {
                self.fieldIncomplete();
            }
        });
    },
    fieldComplete: function () {
        this.$bForward.removeClass("th-hidden");
    },
    fieldIncomplete: function () {
        this.$bForward.addClass("th-hidden");
    },
    showErrorDlg: function (msg) {
        this.$lError.text(msg);
        DlgManager.showDlg(this.$dlgError);
    },
    hideErrorDlg: function () {
        DlgManager.hideDlg(this.$dlgError);
    },
    showWaitDlg: function () {
        WaitMsgManager.show();
    },
    hideWaitDlg: function () {
        WaitMsgManager.hide();
    },
    bDlgPromptPasswordRemindOKClickHandler: function () {
        var self = this;
        this.hidePromptPasswordRemind();
        this.showWaitDlg();
        var fieldsMap = OperatorFieldsFormManager.getFieldsMap();
        this.fieldManager.clear();
        this.smartClientManager.sendOnlineRequestAsync({
            request: {
                type: FS.Gateway.RequestTypes.SendCabinetPasswordRequest,
                operatorId: operatorId,
                fields: fieldsMap
            },
            callback: function (args) {
                self.hideWaitDlg();
                var result = args.result;
                if (result == FS.GatewayResultCodes.Success) {

                } else {
                    self.showErrorDlg("Ошибка сервера!");
                }
            }
        });
    },
    bDlgPromptPasswordRemindCancelClickHandler: function () {
        this.hidePromptPasswordRemind();
    },
    showPromptPasswordRemind: function () {
        DlgManager.showDlg(this.$dlgPromptPasswordRemind);
    },
    hidePromptPasswordRemind: function () {
        DlgManager.hideDlg(this.$dlgPromptPasswordRemind);
    },
    forwardClickHandler: function () {
        var self = this,
            loggingService = self.loggingService;
        this.showWaitDlg();
        var fieldsMap = OperatorFieldsFormManager.getFieldsMap();
        CabinetManager.sendLoadCabinetRequest({
            operatorId: operatorId,
            fieldsMap: fieldsMap,
            success: function (answerData) {
                window.localStorage.setItem("cabinetInfoXml", answerData);
                OperatorFieldsFormManager.setFieldElement("cabinetInfoXml", answerData);
                OperatorFieldsFormManager.navigate();
            },
            unknownError: function (errorCode) {
                loggingService.trace("Hiding the waiting dlg...");
                self.hideWaitDlg();
                loggingService.trace("The waiting dlg has been hidden.");
                var commonErrorMsg = TerminalUI.UIMessageMap["CABINET_LoadCabinetRequest_CommonError"];
                var errorMsg = commonErrorMsg;
                loggingService.trace("Showing the error dlg with msg=%1...", errorMsg);
                self.showErrorDlg(errorMsg);
                loggingService.trace("The error dlg has been shown.");
            },
            knownError: function (errorCode, userMsg) {
                loggingService.trace("Hiding the waiting dlg...");
                self.hideWaitDlg();
                loggingService.trace("The waiting dlg has been hidden.");
                if (errorCode == TerminalUI.GatewayErrorCodes.UserPasswordInvalid) {
                    loggingService.trace("Showing the prompt password remind dlg...");
                    self.showPromptPasswordRemind();
                    loggingService.trace("The prompt password remind dlg was shown.");
                } else {
                    loggingService.trace("Showing the error dlg with msg=%1...", userMsg);
                    self.showErrorDlg(userMsg);
                    loggingService.trace("The error dlg has been shown.");
                }
            }
        });
    }
};