﻿function SmartClientTCCommunicator(smartClientManager) {
    TCCommunicator.apply(this, arguments);
    var self = this;
    this._smartClientManager = smartClientManager;
    this.initSmartClientEventHandling();
};

extend(SmartClientTCCommunicator, TCCommunicator, {
    initSmartClientEventHandling: function () {
        var self = this;

        this._smartClientManager.addHandler("transportCardSuitableRouteCallback", function (paramName, paramValue) {
            if (paramName == "Data") {
                self.preReceiveResponse();
                self.onResponseReceived(paramValue);
            }
        });
    },

    sendRequest: function (detailXml) {
        this._smartClientManager.sendDataToContactlessCardReader(detailXml);
    }
});