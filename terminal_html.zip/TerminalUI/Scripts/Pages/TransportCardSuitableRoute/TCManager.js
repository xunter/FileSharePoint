﻿function TCManager(communicator, requestBuilder, responseParser) {
    this._communicator = communicator;
    this._requestBuilder = requestBuilder;
    this._responseParser = responseParser;
    this.busy = false;
    this.init();
    TCManager._instance = this;
};

TCManager.getInstance = function () { return TCManager._instance; };

TCManager.prototype = {
    busy: null,
    started: false,
    getCommunicator: function () { return this._communicator; },
    getRequestBuilder: function () { return this._requestBuilder; },
    getResponseParser: function () { return this._responseParser; },
    startSession: function () {
        this.started = true;
        this.triggerBusy();
        var startSessionRequest = this._requestBuilder.createStartSessionRequestXml();
        this._communicator.sendRequest(startSessionRequest);
        this.onSessionBegin();
    },
    init: function () {
        this.initCommunicator();
    },
    initCommunicator: function () {
        var self = this;
        this._communicator.onResponseReceived = function (responseXml) { self.responseReceivedHandler(responseXml) };
    },
    triggerReady: function () {
        this.busy = false;
        this.onReady();
    },
    triggerBusy: function () {
        this.busy = true;
        this.onBusy();
    },
    responseReceivedHandler: function (responseXml) {
        this.triggerReady();
        var responseMap = this._responseParser.parseResponse(responseXml),
                    reqAction = responseMap.reqAction,
                    respAction = responseMap.respAction,
                    respStatus = responseMap.respStatus;
        if (responseMap.respStatus == "Error") {

            // Завершаем обслуживание при явном указании от консоли, либо при ошибке при старте сессии
            var stopCardService = respAction == "Stop_of_card_service" || reqAction == "Start_of_card_service";

            this.onError(responseMap.errorText, stopCardService);
        }
        if (responseMap.displayXml) {
            this.onDisplayUpdated(responseMap.displayXml);
        }
        if (responseMap.printXml) {
            this.onPrintCheque(responseMap.printXml);
        }
        if (responseMap.respAction == "Stop_of_card_service" && responseMap.respStatus != "Error") {
            this.onStopCardService();
        }
        if (responseMap.fields.length) {
            this.onFieldsAvailable(responseMap.fields);
        }
    },
    processUserAction: function (displayFrameId, buttonAction, userAction, availableAmount) {
        this.triggerBusy();
        var userActionRequest = null;
        if (availableAmount) {
            userActionRequest = this._requestBuilder.createUserActionWithAmountRequestXml(displayFrameId, buttonAction, userAction, availableAmount);
        } else {
            userActionRequest = this._requestBuilder.createUserActionRequestXml(displayFrameId, buttonAction, userAction);
        }
        this._communicator.sendRequest(userActionRequest);
    },
    onFieldsAvailable: function (fields) { },
    onSessionBegin: function () { },
    onSessionEnd: function () { },
    onDisplayUpdated: function (displayXml) { },
    onPrintCheque: function (printXml) { },
    onWaiting: function () { },
    onBusy: function () { },
    onReady: function () { },
    onStopCardService: function () { },
    onError: function (errorText, stopCardService) { }
};