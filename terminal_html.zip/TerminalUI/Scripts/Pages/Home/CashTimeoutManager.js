var CashTimeoutManager = (function () {
    function CashTimeoutManager(parent, loggingService) {
        this._parent = parent;
        this._autoPaymentProcessed = false;
        this._loggingService = loggingService;
        this.UITimeout = new FireEvent();
    }
    CashTimeoutManager.prototype.OnUITimeout = function () {
        this._loggingService.trace("Обработка timeout (внос наличными)...");
        if (this._autoPaymentProcessed) {
            return;
        }
        this._autoPaymentProcessed = true;
        this.UITimeout.fire(this, {
            success: this._parent.OnUITimeout.bind(this._parent),
            fail: this._parent.OnUITimeout.bind(this._parent),
            complete: this._parent.OnUITimeout.bind(this._parent)
        });
    };
    CashTimeoutManager.prototype.OnUITimeoutCancelled = function () {
        this._parent.OnUITimeoutCancelled();
    };
    return CashTimeoutManager;
})();
//# sourceMappingURL=CashTimeoutManager.js.map