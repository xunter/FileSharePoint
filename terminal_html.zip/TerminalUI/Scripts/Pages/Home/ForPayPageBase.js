var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
//...
// Эти коды ответов возвращает SmartClientManager.sendOfflineRequestAsync()
// Коды соответствуют: 
//      TerminalServices\OperationService\OnlineService.cs\executeCardPayment()
//      Terminal\Terminal\Terminal.Gateway\GatewayResult.cs\GatewayResult
//
// Помимо этого - может быть вернут код и не из этого перечисления
var SendOfflineResponseCodes;
(function (SendOfflineResponseCodes) {
    SendOfflineResponseCodes[SendOfflineResponseCodes["Success"] = 0] = "Success";
    SendOfflineResponseCodes[SendOfflineResponseCodes["Error"] = 1] = "Error";
    SendOfflineResponseCodes[SendOfflineResponseCodes["ConnectionError"] = -1] = "ConnectionError";
    SendOfflineResponseCodes[SendOfflineResponseCodes["ResponseLost"] = -2] = "ResponseLost"; // Только при оплате картой
})(SendOfflineResponseCodes || (SendOfflineResponseCodes = {}));
var ForPayPageBase = (function (_super) {
    __extends(ForPayPageBase, _super);
    function ForPayPageBase() {
        _super.apply(this, arguments);
        this.currentChequeNum = null;
        this.$lError = null;
        this.$bDlgErrorOk = null;
        this.$dlgError = null;
        this.cabinetInfo = null;
        this.operatorInstance = null;
        this.fieldsMap = null;
        this.urlFetchReceipt = null;
        this.urlCabinetAddOperator = null;
        this.urlSuccessPayment = null;
        this.urlNextChequeNum = null;
        this.isCabinetAddOperator = null;
        this.sumsInfo = null;
        this.paySumInfo = null;
        this.sumToCharge = null;
        this.chequeManager = null;
    }
    ForPayPageBase.prototype.getFieldsMapForTransfering = function () {
        return $.map(this.fieldsMap, function (value, key) {
            return { Key: key, Value: value };
        });
    };
    ForPayPageBase.prototype.init = function (settings) {
        _super.prototype.init.call(this, arguments);
        if (settings.hasOwnProperty("urlCabinetAddOperator"))
            this.urlCabinetAddOperator = settings.urlCabinetAddOperator;
        if (settings.hasOwnProperty("urlFetchReceipt"))
            this.urlFetchReceipt = settings.urlFetchReceipt;
        if (settings.hasOwnProperty("urlSuccessPayment"))
            this.urlSuccessPayment = settings.urlSuccessPayment;
        if (settings.hasOwnProperty("urlNextChequeNum"))
            this.urlNextChequeNum = settings.urlNextChequeNum;
        if (settings.hasOwnProperty("fieldsMap"))
            this.fieldsMap = settings.fieldsMap;
        if (settings.hasOwnProperty("isCabinetAddOperator"))
            this.isCabinetAddOperator = settings.isCabinetAddOperator;
        if (settings.hasOwnProperty("cabinetInfo"))
            this.cabinetInfo = settings.cabinetInfo;
        if (settings.hasOwnProperty("operatorInstance"))
            this.operatorInstance = settings.operatorInstance;
        if (settings.hasOwnProperty("sumsInfo"))
            this.sumsInfo = settings.sumsInfo;
        if (settings.hasOwnProperty("paySumInfo"))
            this.paySumInfo = settings.paySumInfo;
        if (settings.hasOwnProperty("sumToCharge"))
            this.sumToCharge = settings.sumToCharge;
        this.chequeManager = new ChequeManager(this.ajaxService, this.loggingService, {
            urlFetchNextChequeNum: URL_GET_NEXT_RECEIPT_NUM,
            urlFetchReceipt: URL_RENDER_RECEIPT,
            urlFetchReceiptDefault: URL_RENDER_RECEIPT_DEFAULT,
            urlVerifyReceiptTemplateExistsForOperator: URL_VERIFY_RECEIPT_TEMPLATE_EXISTS,
            urlFetchPaymentErrorReceipt: URL_FETCH_PAYMENT_ERROR_RECEIPT,
            urlVerifyPaymentErrorTemplateExists: URL_VERIFY_PAYMENT_ERROR_TEMPLATE_EXISTS,
            urlRenderStatusReceipt: URL_RENDER_STATUS_RECEIPT
        });
    };
    ForPayPageBase.prototype.load = function () {
        _super.prototype.load.call(this);
        var self = this;
        this.$lError = $("#lError");
        this.$bDlgErrorOk = $("#bDlgErrorOk");
        this.$dlgError = $("#dlgError");
        this.$bDlgErrorOk.click(function () {
            self.bDlgErrorOkClickHandler();
        });
        if (this.isCabinetAddOperator) {
            this.addCabinetOperatorAsync();
        }
    };
    ForPayPageBase.prototype.fetchNextChequeNumAsync = function (callback) {
        var self = this;
        this.loggingService.trace("Fetching the next cheque num...");
        this.chequeManager.fetchNextChequeNumAsync(function (nextChequeNum) {
            self.loggingService.trace("The next cheque num has been fatched. It is %1", nextChequeNum);
            this.currentChequeNum = nextChequeNum;
            if (typeof (callback) != "undefined")
                callback(nextChequeNum);
        });
    };
    ForPayPageBase.prototype.addCabinetOperatorAsync = function () {
        CabinetManager.addCabinetOperatorAsync(operatorInstance.ID, this.fieldsMap, function (resultCtx) {
        });
    };
    ForPayPageBase.prototype.fetchReceiptAsync = function (num) {
        this.loggingService.trace("Fetching a receipt async...");
        var self = this, paySumInfo = self.paySumInfo, sumAsText = paySumInfo.Sum.toFixed(2), sumToPayAsText = paySumInfo.SumToPay.toFixed(2), comissionSumAsText = paySumInfo.ComissionSum.toFixed(2), timestamp = new Date();
        this.loggingService.trace("Getting the fields map for the transfering...");
        var fieldsMapToTransfer = this.getFieldsMapForTransfering();
        this.loggingService.trace("The fields map for the transfering was got. It is %1.", toJSON(fieldsMapToTransfer));
        var checkInfo = {
            OperatorId: self.operatorInstance.ID,
            Sum: sumAsText,
            SumToPay: sumToPayAsText,
            ComissionSum: comissionSumAsText,
            Timestamp: timestamp,
            ChequeNum: num,
            FieldsMapFromJSON: fieldsMapToTransfer
        };
        this.loggingService.trace("Posting the check info to the server via AJAX...");
        var operatorId = self.operatorInstance.ID, fieldMap = self.fieldsMap, sum = paySumInfo.Sum, sumToPay = paySumInfo.SumToPay, comissionSum = paySumInfo.ComissionSum, timestampDate = timestamp, chequeNum = num, fetchReceiptLogic = new FetchPaymentReceiptLogic(this.chequeManager);
        fetchReceiptLogic.fetchReceiptAsync(self.operatorInstance, fieldMap, sum, sumToPay, comissionSum, timestampDate, chequeNum, function (resultCtx) {
            if (resultCtx.error === true) {
                self.loggingService.error("Failed to fetch a receipt text!");
                self.failedFetchReceiptHandler();
            }
            else {
                self.loggingService.trace("Invoking the fetchReceiptCallback...");
                self.fetchReceiptCallback(resultCtx.receiptText);
                self.loggingService.trace("The fetchReceiptCallback was invoked.");
            }
        });
    };
    ForPayPageBase.prototype.fetchReceiptCallback = function (receiptText) {
    };
    ForPayPageBase.prototype.failedFetchReceiptHandler = function () {
    };
    ForPayPageBase.prototype.makeRequestForGateway = function (params) {
        var self = this;
        var request = {
            op: this.operatorInstance.Name,
            amount: params.amount,
            amountAll: params.amountAll,
            initDateTime: params.date,
            chequeNum: params.chequeNum,
            operatorId: self.operatorInstance.ID,
            fields: self.fieldsMap
        };
        if (isCabinetSession) {
            request.cabinetId = self.cabinetInfo.ID;
            request.userId = self.cabinetInfo.UserID;
        }
        return request;
    };
    ForPayPageBase.prototype.doPaymentAsync = function (amount, amountAll, date, chequeNum) {
        var _this = this;
        this._currentRequestParams = { amount: amount, amountAll: amountAll, date: date, chequeNum: chequeNum };
        this._amountAll = amountAll;
        var request = this.makeRequestForGateway(this._currentRequestParams);
        this.loggingService.trace("Sending an offline card payment request...");
        SmartClientManager.sendOfflineRequestAsync({
            request: request,
            callback: $.proxy(function (e) {
                _this.loggingService.trace("The offline card payment request was completed with args '%1'", toJSON(e));
                switch (parseInt(e.result)) {
                    case 0 /* Success */:
                        _this.doPaymentSuccessHandler(e.responseMap);
                        return;
                    case -2 /* ResponseLost */:
                        _this.SendCheckPaymentRequestAsync();
                        break;
                    default:
                        _this.doPaymentFailedHandler(e.responseMap);
                }
            }, this)
        });
    };
    ForPayPageBase.prototype.SendCheckPaymentRequestAsync = function () {
        var _this = this;
        this.loggingService.trace("Отправка запроса проверки платежа...");
        SmartClientManager.sendOnlineRequestAsync({
            request: { type: FS.Gateway.RequestTypes.CheckPayRequest },
            callback: $.proxy(function (e) {
                _this.loggingService.trace("Обработка результата запроса проверки платежа. Ответ: '%1'", toJSON(e));
                if (parseInt(e.result) != FS.Gateway.ResultCodes.Success) {
                    _this.doPaymentFailedHandler(e);
                    return;
                }
                var deserializer = new ReqTypeResponseDeserializer();
                var req13Response = deserializer.ToReqType13Response(e);
                _this.loggingService.trace("ReqType13Response: error=%1 result=%2 status=%3", req13Response.Error, req13Response.Result, req13Response.Status);
                if (req13Response.Result != 0) {
                    _this.doPaymentFailedHandler(e);
                    return;
                }
                if (req13Response.Status == 8 /* Fatal */ || req13Response.Status == -1 /* NotFound */) {
                    _this.doPaymentFailedHandler(e);
                    return;
                }
                _this.PrintPaymentStatusCheque(req13Response.Status, $.proxy(function () {
                    _this.navigateToSuccessPayment();
                }, _this));
            }, this)
        });
    };
    ForPayPageBase.prototype.PrintPaymentStatusCheque = function (statusCode, completedCallback) {
        var self = this;
        SmartClientManager.writeStateErrorToLog("Формируем чек-состояние платежа...");
        this.chequeManager.RenderPaymentStatusReceiptAsync(this.operatorInstance.ID, new Date(), this._currentRequestParams.amountAll, ReqType13Helper.ConvertStatus(statusCode), this._currentRequestParams.chequeNum, function (e) {
            if (e.Error) {
                SmartClientManager.writeStateErrorToLog("Не удалось сформировать чек-состояние");
                completedCallback();
                return;
            }
            SmartClientManager.writeStateToLog("Печать чека-состояния...");
            SmartClientManager.printText(e.ReceiptText, self._amountAll, completedCallback);
        });
    };
    ForPayPageBase.prototype.navigateToError = function (msg) {
        throw "Not supported";
    };
    ForPayPageBase.prototype.printPaymentErrorReceiptAsync = function (callback) {
        var self = this;
        var operatorId = this.operatorInstance.ID;
        var timestamp = new Date();
        var amountAll = this._currentRequestParams.amountAll;
        var triggerCallback = function (args) {
            if (callback)
                callback(args);
        };
        this.chequeManager.fetchPaymentErrorReceipt(operatorId, timestamp, amountAll, function (responseArgs) {
            if (responseArgs.error) {
                SmartClientManager.writeStateErrorToLog("Не удалось сформировать чек-уведомление о невыполненном платеже.");
                triggerCallback(responseArgs);
            }
            else {
                SmartClientManager.writeStateToLog("Печать уведомления о невыполненном платеже...");
                SmartClientManager.printText(responseArgs.receiptText, self._amountAll, function () {
                    triggerCallback(responseArgs);
                });
            }
        });
    };
    ForPayPageBase.prototype.doPaymentSuccessHandler = function (responseMap) {
    };
    ForPayPageBase.prototype.doPaymentFailedHandler = function (responseMap) {
    };
    ForPayPageBase.prototype.bDlgErrorOkClickHandler = function () {
        this.hideErrorDlg();
    };
    ForPayPageBase.prototype.showErrorDlg = function (msg) {
        this.$lError.text(msg);
        DlgManager.showDlg(this.$dlgError);
    };
    ForPayPageBase.prototype.hideErrorDlg = function () {
        DlgManager.hideDlg(this.$dlgError);
    };
    ForPayPageBase.prototype.navigateToSuccessPayment = function () {
        this.navigate(this.urlSuccessPayment);
    };
    return ForPayPageBase;
})(ClientSidePage);
//# sourceMappingURL=ForPayPageBase.js.map