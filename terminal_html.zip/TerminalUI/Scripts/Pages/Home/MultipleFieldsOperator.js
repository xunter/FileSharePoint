﻿$(function () {
    WaitMsgManager.init();
    FieldsUIManager.init();
});

var acceptListener = {
    pinPadAcceptPressed: function (args) {
        FieldsUIManager.$bGoToPay.click();
    }
};
var barcodePinPadListener = {
    pinPadCorrectionPressed: function (args) {
        barcodeFieldManager.removeLastLetter();
    },

    pinPadDigitPressed: function (args) {
        barcodeFieldManager.appendLetter(args.letter);
    },

    barcodeScannerOpening: function () { },

    barcodeScannerOpened: function () { },

    barcodeScannerClosing: function () { },

    barcodeScannerClosed: function () { },

    barcodeScannerReadValue: function (readText) {
        barcodeFieldManager.setFieldValue(readText);
    }
};

var MultipleFieldsOperatorPage = (function () {
    var MultipleFieldsOperatorPage = function () {
        ClientSidePage.apply(this, arguments);
    };

    extend(MultipleFieldsOperatorPage, ClientSidePage, {
        
    });

    return MultipleFieldsOperatorPage;
})();

var FieldsUIManager = {
    activeFieldItemElement: null,
    activeFieldManager: null,
    activeEditorPanelElement: null,
    activeFieldItemElement: null,
    activeFieldEditor: null,

    smartClientManager: SmartClientManager,
    loggingService: null,
    ajaxService: null,

    multipleFieldsOperatorPage: null,

    $bPay: null,
    $bNext: null,
    $bCancel: null,
    $bMenu: null,

    $fieldsContainer: null,
    $fieldsContainerOuter: null,

    $dlgPromptPasswordRemind: null,
    $bDlgPromptPasswordRemindOK: null,
    $bDlgPromptPasswordRemindCancel: null,

    dlgManager: DlgManager,

    fieldsManagerCollection: new FieldManagerCollection(),

    triggerFieldCollectionManagerFilled: function () {
        this.setFirstEditableField();
        this.checkFieldsComplete();
    },

    showDlg: function ($dlg) {
        this.dlgManager.showDlg($dlg);
    },
    showDlgError: function (msg) {
        this.$lDlgError.text(msg);
        SmartClientManager.removeListener(fieldPinPadListener);
        SmartClientManager.removeListener(acceptListener);
        this.showDlg(this.$dlgError);
    },

    showMaxSumExceededErrorMsg: function () {
        this.showDlgError(MAX_SUM_EXCEEDED_ERROR_MSG);
    },

    showMinSumNotReachedErrorMsg: function () {
        this.showDlgError(MIN_SUM_NOT_REACHED_ERROR_MSG);
    },

    init: function () {

        var self = this;

        this.loggingService = FS.TerminalUI.loggingService;
        this.ajaxService = FS.TerminalUI.ajaxService;

        this.fieldsManagerCollection.complete = function () { self.fieldsComplete(); };
        this.fieldsManagerCollection.incomplete = function () { self.fieldsIncomplete(); };

        this.$bCancel = $("#bCancel");
        this.$bGoToPay = $("#bGoToPay");
        this.$bNext = $("#bNext");
        this.$bMenu = $("#bMenu");
        this.$bBarcode = $("#bBarcode");

        this.$lock = $("#lock");
        this.$dlgError = $("#dlgError");
        this.$lDlgError = $("#lDlgError");
        this.$bDlgErrorOK = $("#bDlgErrorOk");

        this.$dlgBarcode = $("#dlgBarcode");
        this.$tbBarcode = $("#tbBarcode");
        this.$bDlgBarcodeNext = $("#bDlgBarcodeNext");
        this.$bDlgBarcodeCancel = $("#bDlgBarcodeCancel");
        this.$fieldsContainer = $("#fieldsContainer");
        this.$fieldsContainerOuter = $("#fieldsContainerOuter");

        this.$leftContainer = $("#leftContainer");
        this.$btnScrollUp = $("#btnScrollUp");
        this.$btnScrollDown = $("#btnScrollDown");

        this.$dlgPromptPasswordRemind = $("#dlgPromptPasswordRemind");
        this.$bDlgPromptPasswordRemindOK = $("#bDlgPromptPasswordRemindOK");
        this.$bDlgPromptPasswordRemindCancel = $("#bDlgPromptPasswordRemindCancel");

        this.$bDlgPromptPasswordRemindOK.click(function () { self.bDlgPromptPasswordRemindOKClickHandler() });
        this.$bDlgPromptPasswordRemindCancel.click(function () { self.bDlgPromptPasswordRemindCancelClickHandler() });

        this.setOnAutoAdjustFieldsContainerScrollBtns();

        this.$bDlgErrorOK.click(function () {
            hideDlgError();
        });

        var multipleFieldsOperatorPage = this.multipleFieldsOperatorPage = new MultipleFieldsOperatorPage();
        multipleFieldsOperatorPage.init();
        multipleFieldsOperatorPage.load();

        var $lockScreen = this.$lock;
        var showDlg = function ($dlg) {
            DlgManager.showDlg($dlg);
        };

        var hideDlg = function ($dlg) {
            DlgManager.hideDlg($dlg);
        };

        var showWaitDlg = function () {
            SmartClientManager.removeListener(fieldPinPadListener);
            SmartClientManager.removeListener(acceptListener);
            WaitMsgManager.show();
        };
        var hideWaitDlg = function () {
            SmartClientManager.addListener(fieldPinPadListener);
            SmartClientManager.addListener(acceptListener);
            WaitMsgManager.hide();
        };

        var showDlgError = showErrorDlg = this.showErrorDlg = function (msg) {
            self.$lDlgError.text(msg);
            SmartClientManager.removeListener(fieldPinPadListener);
            SmartClientManager.removeListener(acceptListener);
            showDlg(self.$dlgError);
        };
        var hideDlgError = hideErrorDlg = this.hideErrorDlg = function () {
            hideDlg(self.$dlgError);
            SmartClientManager.addListener(fieldPinPadListener);
            SmartClientManager.addListener(acceptListener);
        };

        this.$bNext.click(function () {
            self.setNextField();
        });

        this.$bGoToPay.click(function () {
            var loggingService = self.loggingService;
            loggingService.info("The button GoToPay was clicked");
            showWaitDlg();
            if (self.activeFieldManager != null) {
                self.logFieldTypedValue(self.activeFieldManager);
            }
            loggingService.trace("isReedit = %1", isReedit);
            if (isReedit) {
                OperatorFieldsFormManager.navigate();
                return;
            }
            function sendLoadCabinetRequest(args) {
                loggingService.info("Sending LoadCabinetRequest...");
                var defaultArgs = {
                    operatorId: 0,
                    fieldsMap: {},
                    success: function (cabinetXml) { },
                    error: function (errorCode, errorUserMsg) { }
                };
            };
            var fieldsMap = {};
            self.fieldsManagerCollection.forEach(function (fieldManager) {
                var fieldId = fieldManager.getFieldID();
                var fieldValue = fieldManager.getHiddenFieldValue();
                fieldsMap["field" + fieldId] = fieldValue;
            });
            if (typeof (IS_CABINET_SIGN_IN_FIELDS_TOGETHER) != "undefined" && IS_CABINET_SIGN_IN_FIELDS_TOGETHER == true) {
                loggingService.trace("IS_CABINET_SIGN_IN_FIELDS_TOGETHER == true");
                self.showWaitDlg();
                var fieldsMap = OperatorFieldsFormManager.getFieldsMap();
                CabinetManager.sendLoadCabinetRequest({
                    operatorId: operatorId,
                    fieldsMap: fieldsMap,
                    success: function (answerData) {
                        loggingService.trace("A result of the request is success");
                        OperatorFieldsFormManager.setFieldElement("cabinetInfoXml", answerData);
                        OperatorFieldsFormManager.setActionUrl(URL_CABINET_XML_SUPPLIER);
                        OperatorFieldsFormManager.navigate();
                    },
                    unknownError: function (errorCode) {
                        loggingService.trace("A result of the request is the unknown error");
                        loggingService.trace("Hiding the waiting dlg...");
                        self.hideWaitDlg();
                        loggingService.trace("The waiting dlg was hidden.");
                        var errorMsg = FS.TerminalUI.UIMessageMap["CABINET_LoadCabinetRequest_CommonError"];
                        loggingService.trace("Showing the error dlg with msg=%1...", errorMsg);
                        self.showErrorDlg(errorMsg);
                        loggingService.trace("The error dlg was shown.");
                    },
                    knownError: function (errorCode, userMsg) {
                        loggingService.trace("A result of the request is the known error");
                        loggingService.trace("Hiding the waiting dlg...");
                        self.hideWaitDlg();
                        loggingService.trace("The waiting dlg has been hidden.");
                        self.showErrorDlg(userMsg);                        
                    }
                });
            } else {
                OperatorFieldsEditingUtil.processFieldsBeforePayAsync({
                    invoiceSearchEnabled: IS_INVOICE_SEARCH_ENABLED,
                    fieldsCheckingEnabled: IS_FIELDS_CHECKING_ENABLED,
                    urlGetFieldsMapByAnswerData: URLGetFieldsMapByAnswerData,
                    operatorId: operatorId,
                    operatorInstance: operatorInstance,
                    fieldsMap: fieldsMap,
                    error: function (msg) {
                        hideWaitDlg();
                        showDlgError(msg);
                    },
                    callback: function (fieldsMap) {
                        OperatorFieldsFormManager.navigate();
                    }
                });
            }
        });

        this.fieldsManagerCollection.fieldValueChanged = function (fieldManager, newValue) { self.fieldValueChanged(fieldManager, newValue); };

        SmartClientManager.addListener(fieldPinPadListener);
        if (isBarcodeAvailable) {

            var barcodeAcceptListener = {
                pinPadAcceptPressed: function (args) {
                    self.$bDlgBarcodeNext.click();
                }
            };

            $(window).bind("unload", function () {
                SmartClientManager.removeListener(barcodePinPadListener);
                SmartClientManager.removeListener(barcodeAcceptListener);
                SmartClientManager.closeBarcodeScanner();
            });

            var showDlgBarcode = function () {
                SmartClientManager.removeListener(fieldPinPadListener);
                SmartClientManager.addListener(barcodePinPadListener);
                showDlg(self.$dlgBarcode);
                barcodeFieldManager.clear();
                SmartClientManager.openBarcodeScanner();
                barcodeFieldManager.focusTextBox();
            };

            var hideDlgBarcode = function () {
                hideDlg(self.$dlgBarcode);
                SmartClientManager.removeListener(barcodePinPadListener);
                SmartClientManager.addListener(fieldPinPadListener);
                barcodeFieldManager.clear();
                SmartClientManager.closeBarcodeScanner();
            };

            this.$bDlgBarcodeCancel.click(function () {
                hideDlgBarcode();
            });

            this.$bDlgBarcodeNext.click(function () {
                var barcodeValue = barcodeFieldManager.getFieldValue();
                hideDlgBarcode();
                var fieldManagersWithBarcode = FieldsUIManager.fieldsManagerCollection.filterWithBarcode();
                for (var i = 0; i < fieldManagersWithBarcode.length; i++) fieldManagersWithBarcode[i].applyBarcodeValue(barcodeValue);
            });

            self.$bBarcode.click(function () { showDlgBarcode(); });
            barcodeFieldManager = new FieldManager();
            barcodeFieldManager.init({
                //minlength: barcodeRequiredLength,
                //maxlength: barcodeRequiredLength,
                textBox: this.$tbBarcode.get(0),
                required: true,
                oncomplete: function () {
                    self.$bDlgBarcodeNext.removeClass("th-hidden");
                    SmartClientManager.addListener(barcodeAcceptListener);
                },
                onincomplete: function () {
                    SmartClientManager.removeListener(barcodeAcceptListener);
                    if (!self.$bDlgBarcodeNext.hasClass("th-hidden")) {
                        self.$bDlgBarcodeNext.addClass("th-hidden");
                    }
                }
            });
            if (!isReedit && FORCE_SHOW_DLG_BARCODE) showDlgBarcode();
        }
    },

    bDlgPromptPasswordRemindOKClickHandler: function () {
        var multipleFieldsOperatorPage = this.multipleFieldsOperatorPage;
        var self = this;
        this.hidePromptPasswordRemind();
        this.showWaitDlg();
        var fieldsMap = OperatorFieldsFormManager.getFieldsMap();
        this.fieldManager.clear();
        this.smartClientManager.sendOnlineRequestAsync({
            request: {
                type: FS.Gateway.RequestTypes.SendCabinetPasswordRequest,
                operatorId: operatorId,
                fields: fieldsMap
            },
            callback: function (args) {
                self.hideWaitDlg();
                var result = args.result;
                if (result == FS.GatewayResultCodes.Success) {

                } else {
                    self.showErrorDlg(FS.TerminalUI.UIMessageMap["CABINET_SendCabinetPasswordRequest_CommonError"]);
                }
            }
        });
    },
    bDlgPromptPasswordRemindCancelClickHandler: function () {
        this.hidePromptPasswordRemind();
    },
    showWaitDlg: function () {
        this.multipleFieldsOperatorPage.showWaitDlg();
    },
    hideWaitDlg: function () {
        this.multipleFieldsOperatorPage.hideWaitDlg();
    },
    showPromptPasswordRemind: function () {
        DlgManager.showDlg(this.$dlgPromptPasswordRemind);
    },
    hidePromptPasswordRemind: function () {
        DlgManager.hideDlg(this.$dlgPromptPasswordRemind);
    },

    findFirstEditableFieldElement: function () {
        var $fieldItems = $(".th-fields-item"),
                    $editableFieldItems = $fieldItems.filter("[data-editable=1]"),
                    $firstEditableFieldItem = $editableFieldItems,
                    firstEditableFieldItem = $editableFieldItems.get(0);
        return firstEditableFieldItem;
    },

    setFirstEditableField: function () {
        var firstEditableFieldItem = this.findFirstEditableFieldElement();
        if (firstEditableFieldItem != null) {
            var fieldId = firstEditableFieldItem.getAttribute("data-field_id");
            this.setCurrentField(fieldId);
        }
    },

    findNextSiblingElement: function (currFieldItemElement) {
        var nextSibling = getNextSiblingElement(currFieldItemElement);
        if (nextSibling == null) {
            nextSibling = currFieldItemElement.parentNode.firstChild;
            if (nextSibling.nodeType != 1) nextSibling = getNextSiblingElement(nextSibling);
        }
        return nextSibling;
    },

    isCurrentFieldEditable: function () {
        return this.isFieldEditable(this.activeFieldItemElement);
    },

    isFieldEditable: function (fieldElement) {
        var editable = fieldElement.getAttribute("data-editable");
        return editable == 1;
    },

    setNextField: function () {
        var self = this;
        var currFieldItemElement = self.activeFieldItemElement;
        var currFieldId = currFieldItemElement.getAttribute("data-field_id");
        this.logFieldTypedValue(this.activeFieldManager);
        var nextSiblingElement = self.findNextSiblingElement(currFieldItemElement);
        var editable = self.isFieldEditable(nextSiblingElement);
        while (!editable) {
            nextSiblingElement = self.findNextSiblingElement(nextSiblingElement);
            editable = self.isFieldEditable(nextSiblingElement);
        }
        var nextFieldId = nextSiblingElement.getAttribute("data-field_id");
        self.setCurrentField(nextFieldId);
    },

    fieldValueChanged: function (fieldManager, newValue) {
        if (!fieldManager.isEditable()) return;
        var fieldId = fieldManager.getFieldID();
        var isComplete = fieldManager.isComplete();
        var fieldItemElement = this.getFieldItemElementByID(fieldId);
        var $fieldValue = $(".th-value", fieldItemElement);
        var fieldValueForView = fieldManager.getViewFieldValue();
        $fieldValue.text(fieldValueForView);
    },

    checkFieldsComplete: function () {
        if (this.fieldsManagerCollection.isComplete()) {
            this.fieldsComplete();
        } else {
            this.fieldsIncomplete();
        }
    },

    fieldsComplete: function () {
        this.$bGoToPay.removeClass("th-hidden");
        this.$bNext.addClass("th-hidden");
        SmartClientManager.addListener(acceptListener);
    },

    fieldsIncomplete: function () {
        this.$bNext.removeClass("th-hidden");
        this.$bGoToPay.addClass("th-hidden");
        SmartClientManager.removeListener(acceptListener);
    },

    getEditorPanelElementByFieldID: function (fieldId) {
        return document.getElementById("editorPanel" + fieldId);
    },

    logFieldTypedValue: function (fieldManager) {
        var prevFieldId = fieldManager.getFieldID(),
            prevPureFieldId = operatorManager.getPureFieldID(prevFieldId),
            prevFieldInstance = operatorManager.findFieldInstanceByID(prevPureFieldId),
            prevFieldName = prevFieldInstance.Title,
            prevFieldLogValue = prevFieldInstance.IsCrypt ? "****SECURE****" : fieldManager.getViewFieldValue();
        SmartClientManager.writeStateToLog("Поле \"" + prevFieldName + "\" заполнено значением: " + prevFieldLogValue);
    },

    logFieldActiveName: function (fieldManager) {
        var prevFieldId = fieldManager.getFieldID(),
            prevPureFieldId = operatorManager.getPureFieldID(prevFieldId),
            prevFieldInstance = operatorManager.findFieldInstanceByID(prevPureFieldId),
            prevFieldName = prevFieldInstance.Title;
        SmartClientManager.writeStateToLog("Ввод поля \"" + prevFieldName + "\".");
    },

    setCurrentField: function (fieldId) {
        var fieldElement = this.getFieldItemElementByID(fieldId);
        var currentFieldManager = this.activeFieldManager;
        var nextEditorPanelElement = this.getEditorPanelElementByFieldID(fieldId);
        // Previous active field existed
        if (this.activeEditorPanelElement != null) {
            $(this.activeEditorPanelElement).addClass("th-hidden");
            if (currentFieldManager != null) {
                this.logFieldTypedValue(currentFieldManager);
            }
        }
        this.activeEditorPanelElement = nextEditorPanelElement;
        $(nextEditorPanelElement).removeClass("th-hidden");
        var fieldManager = this.fieldsManagerCollection.getByFieldID(fieldId);
        this.unsetCurrentField();
        $(fieldElement).addClass("th-active");
        this.activeFieldItemElement = fieldElement;
        this.activeFieldManager = fieldManager;
        if (fieldManager != null) {
            this.logFieldActiveName(fieldManager);
        }

        this.scrollToFieldItemElement(fieldElement);

        this.activeFieldEditor = document.getElementById("tbField" + fieldId);
        this.activeFieldManager.focusTextBox();
        //this.activeFieldEditor.focus();
    },

    getActiveFieldManager: function () {
        return this.activeFieldManager;
    },

    unsetCurrentField: function () {
        if (this.activeFieldItemElement != null) {
            $(this.activeFieldItemElement).removeClass("th-active");
        }
    },

    getFieldItemElementByID: function (fieldId) {
        return document.getElementById("fieldItem" + fieldId);
    },


    scrollStep: 50,
    scrollDown: function () {
        var self = this;
        var offset = this.$fieldsContainer.offset();
        var offsetParent = this.$fieldsContainer.offset();
        var heightOuter = this.$fieldsContainerOuter.height();
        var height = this.$fieldsContainer.height();
        var topDiff = offsetParent.top - offset.top;
        var bottomDiff = (offsetParent.top + heightOuter) - (offset.top + height);
        var currentScrollTop = this.$fieldsContainer.scrollTop();
        self.$fieldsContainer.scrollTop(currentScrollTop + this.scrollStep);
    },
    scrollUp: function () {
        var self = this;
        var offset = this.$fieldsContainer.offset();
        var offsetParent = this.$fieldsContainer.offset();
        var heightOuter = this.$fieldsContainerOuter.height();
        var height = this.$fieldsContainer.height();
        var topDiff = offsetParent.top - offset.top;
        var bottomDiff = (offsetParent.top + heightOuter) - (offset.top + height);
        var currentScrollTop = this.$fieldsContainer.scrollTop();
        self.$fieldsContainer.scrollTop(currentScrollTop - this.scrollStep);
    },
    scrollToFieldItemElement: function (fieldItemElement) {
        var self = this;
        var $fieldItemElement = $(fieldItemElement),
            pos = $fieldItemElement.position(),
            posTop = pos.top,
            height = $fieldItemElement.outerHeight();
        var heightOuter = this.$fieldsContainerOuter.height();
        var scrollTop = this.$fieldsContainer.scrollTop();
        var topEdge = scrollTop;
        var bottomEdge = heightOuter - height;
        var scrollToPos = function (pos) {
            self.$fieldsContainer.scrollTop(pos);
        };
        var newPos = null;
        if (posTop < 0) {
            newPos = scrollTop + posTop - height / 2;
        } else if (posTop > bottomEdge) {
            newPos = scrollTop + (posTop - (heightOuter - height * 1.5));
        }
        if (newPos != null) scrollToPos(newPos);
    },
    isFieldsContainerNeedsScrollBtns: function () {
        var self = this,
        fieldsContainerHeight = this.$fieldsContainer.get(0).scrollHeight,
        fieldsContainerOuterHeight = this.$fieldsContainerOuter.height(),
        leftContainerHeight = this.$leftContainer.height(),
        btnScrollUpHeight = this.$btnScrollUp.height(),
        btnScrollDownHeight = this.$btnScrollDown.height();

        return fieldsContainerHeight != 0 & fieldsContainerHeight > leftContainerHeight;
    },
    applyFieldsContainerScrollBtns: function () {
        this.$leftContainer.removeClass("scrollless");
    },
    removeFieldsContainerScrollBtns: function () {
        this.$leftContainer.addClass("scrollless");
    },
    adjustFieldsContainerScrollBtns: function () {
        if (this.isFieldsContainerNeedsScrollBtns()) {
            this.applyFieldsContainerScrollBtns();
        } else {
            this.removeFieldsContainerScrollBtns();
        }
    },
    autoAdjustFieldsContainerScrollBtns: false,
    autoAdjustFieldsContainerScrollBtnsInterval: null,
    setOnAutoAdjustFieldsContainerScrollBtns: function () {
        var self = this;
        if (!this.autoAdjustFieldsContainerScrollBtns) {
            var interval = this.autoAdjustFieldsContainerScrollBtnsInterval = setInterval(function () {
                self.adjustFieldsContainerScrollBtns();
            }, 200);
            this.autoAdjustFieldsContainerScrollBtns = true;
        }
    },
    setOffAutoAdjustFieldsContainerScrollBtns: function () {
        if (this.autoAdjustFieldsContainerScrollBtns && this.autoAdjustFieldsContainerScrollBtnsInterval != null) {
            clearInterval(this.autoAdjustFieldsContainerScrollBtnsInterval);
        }
    },

    // inits a field manager for the specified field and adds the created field manager to the field manager collection
    registerField: function (isLastIteration, fieldInstance, counter, isFieldEditable, fieldKey, textBoxId, fieldManagerSuffix) {
        var fieldManager = FieldsUtil.createFieldManagerForField({
            field: fieldInstance,
            operator: operatorInstance,
            isFieldEditable: isFieldEditable,
            fieldKey: fieldKey,
            textBoxId: textBoxId,
            fieldManagerSuffix: fieldManagerSuffix,
            onMaxSumExceeded: function () { FieldsUIManager.showMaxSumExceededErrorMsg() },
            onMinSumNotReached: function () { FieldsUIManager.showMinSumNotReachedErrorMsg() },
            urlParseBarcodeText: urlParseBarcodeText
        });

        this.fieldsManagerCollection.add(fieldManager);
        if (isLastIteration) {
            this.triggerFieldCollectionManagerFilled();
        }
        return fieldManager;
    }
};

function navigateBack() {
    var backPath = getUriParamValue("backPath");
    go(backPath);
};

var fieldPinPadListener = new Listener({
    pinPadCorrectionPressed: function (args) {
        var fieldManager = FieldsUIManager.getActiveFieldManager();
        if (fieldManager.getFieldType() != "enum") FieldsUIManager.getActiveFieldManager().removeLastLetter();
    },
    pinPadDigitPressed: function (args) {
        var fieldManager = FieldsUIManager.getActiveFieldManager();
        if (fieldManager.getFieldType() != "enum") fieldManager.appendLetter(args.letter);
    },
    pinPadDotPressed: function (args) {
        this.pinPadDigitPressed(args);
    }
});

$(window).bind("unload", function () {
    SmartClientManager.removeListener(fieldPinPadListener);
    SmartClientManager.removeListener(acceptListener);
});