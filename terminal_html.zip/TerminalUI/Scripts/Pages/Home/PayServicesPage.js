﻿(function ($, window) {
    var navManager = NavManager.getInstance();

    var PayServicesPage = window.PayServicesPage = function () {
        ClientSidePage.apply(this, arguments);

        this.$btnRechargeBankCard = null;
    };

    extend(PayServicesPage, ClientSidePage, {
        load: function () {
            ClientSidePage.prototype.load.apply(this, arguments);
            var self = this;
            var $btnRechargeBankCard = self.$btnRechargeBankCard = $("#btnRechargeCard");
            var loggingService = TerminalUI.loggingService;
            var scm = SmartClientManager;

            self.isCardAvailable(function (isCardAvailable, cardData) {
                if (isCardAvailable) {
                    var cardRechargeCtx = {
                        cardData: cardData
                    };
                    $btnRechargeBankCard.click(function () {
                        scm.writeStateToLog("LOG_BTN_CARD_RECHARGE_CLICK");
                        self.showWaitDlg();

                        CardManager.getCardBalanceAsync(function (balanceCtx) {

                            if (balanceCtx.error) {
                                var defaultErrorMsg = TerminalUI.UIMessageMap["GeneralError"];
                                var msg = balanceCtx.msg ? balanceCtx.msg : defaultErrorMsg;
                                loggingService.trace("Failed to get card balance.");
                                self.hideWaitDlg();
                                self.showDlgError(msg);
                            } else {
                                var balanceAmount = cardRechargeCtx.balanceAmount = balanceCtx.balanceNum;

                                var terminalId = cardData.terminalId;
                                var stan = CardManager.generateStan();
                                var cardNumber = cardData.cardNumber;
                                var track2 = cardData.track2;
                                var pinBlock = cardData.pinBlock;
                                var pinKeyKCV = cardData.pinKeyKCV;

                                var holderName = null;
                                var bankAccountNum = null;

                                var postBalance = function () {
                                    TerminalUI.ajaxService.postJSON(URL_RechargeCardPreJson, { holderName: holderName, bankAccountNum: bankAccountNum, stan: stan, terminalId: terminalId, cardNumber: cardNumber, track2: track2, pinBlock: pinBlock, pinKeyKCV: pinKeyKCV, balanceAmount: balanceAmount }, function (res) {
                                        var operatorId = res.operatorId;

                                        var currUrl = self.getCurrUrlSDPless();
                                        var cardRechargeUrl = URL_CashReceive_CardRecharge_Template.replace("_OPERATOR_CARD_RECHARGE_ID_", operatorId) + "&backPath=" + encodeURIComponent(currUrl);

                                        loggingService.info("Navigating to the %1 due to the bank card recharging...", cardRechargeUrl);

                                        self.navigate(cardRechargeUrl);
                                    });
                                };

                                if (TerminalUI.UISettingsMap["CARD_RECHARGE_PROPER_REQUEST_USED"] == "0") {
                                    TerminalUI.ajaxService.get(URL_GetCardRechargeProviderJson, function (res) {
                                        var provider = res.provider;
                                        var operatorId = provider.ID;
                                        var fields = provider.Fields;

                                        var fieldsMap = { "field100": cardNumber };
                                        var urlParseCardRechargeInvoice = URL_PARSE_INVOICE_TEMPLATE.replace("_TARGET_OPERATOR_ID_", operatorId);
                                        OperatorFieldsEditingUtil.loadInvoiceFieldsAsync(operatorId, fields, fieldsMap, function (resMissingFields) {
                                            if (resMissingFields.isError) {
                                                self.hideWaitDlg();
                                                self.showDlgError(resMissingFields.error);
                                            } else {
                                                var missingFieldsMap = resMissingFields.missingFieldsMap;
                                                for (var key in missingFieldsMap) {
                                                    if (key.indexOf("field") !== -1) {
                                                        var fieldVal = missingFieldsMap[key];
                                                        if (holderName == null) {
                                                            holderName = fieldVal;
                                                        } else if (bankAccountNum == null) {
                                                            bankAccountNum = fieldVal;
                                                        }
                                                    }
                                                }
                                                postBalance();
                                            }
                                        }, urlParseCardRechargeInvoice);
                                    });
                                } else {
                                    postBalance();
                                }

                            }

                        });
                    });
                }
            });
        },

        initBankRecharging: function () {

        }
    });
})(jQuery, window)