﻿/// <reference path="../../OperatorFieldsFormManager.js" />
/// <reference path="../../SmartClientManager.js" />
/// <reference path="../../Utils/OperatorFieldsEditingUtil.js" />

function navigateBack() {
    var backPath = getUriParamValue("backPath");
    go(backPath);
};

var fieldPinPadListener = new Listener({
    pinPadCorrectionPressed: function (args) {
        fieldManager.removeLastLetter();
    },
    pinPadDigitPressed: function (args) {
        fieldManager.appendLetter(args.letter);
    }
});

$(function () {
    WaitMsgManager.init();

    var $bPay = $("#bGoToPay");
    var $bForward = $("#bForward");
    var $bDlgErrorOk = $("#bDlgErrorOk");
    var $lDlgError = $("#lError");
    var $lockScreen = $("#lock");
    var $dlgWait = $("#dlgWait");
    var $dlgError = $("#dlgError");
    var $tbField = $("#tbField");

    $bForward.click(function () {
        var detectedOperatorId = $bForward.data("detectedOperatorId");
        OperatorFieldsFormManager.setOperatorIdToNavigate(detectedOperatorId);
        OperatorFieldsFormManager.navigate();
    });

    var dlgNavigateTelecom = DlgMsgManager.findDlg("dlgNavigateTelecom");
    if (dlgNavigateTelecom != null) {
        dlgNavigateTelecom.onButtonClick("OK", function () {
            go(UrlTelecomGroup);
        });

        dlgNavigateTelecom.onButtonClick("Cancel", function () {
            dlgNavigateTelecom.hide();
        });
    }

    if (isMobileOperatorAutoDetect && OperatorFieldsFormManager.getFieldValue("field100").length) {
        $bForward.data("preventAutoNavigation", 1);
    }

    var showDlg = function ($dlg) {
        DlgManager.showDlg($dlg);
    };

    var hideDlg = function ($dlg) {
        DlgManager.hideDlg($dlg);
    };

    var showDlgWait = function () {
        SmartClientManager.removeListener(fieldPinPadListener);
        SmartClientManager.removeListener(acceptListener);
        WaitMsgManager.show();
    };
    var hideDlgWait = function () {
        SmartClientManager.addListener(fieldPinPadListener);
        SmartClientManager.addListener(acceptListener);
        WaitMsgManager.hide();
    };

    var showDlgError = function (msg) {
        $lDlgError.text(msg);
        SmartClientManager.removeListener(fieldPinPadListener);
        SmartClientManager.removeListener(acceptListener);
        showDlg($dlgError);
    };
    var hideDlgError = function () {
        hideDlg($dlgError);
        SmartClientManager.addListener(fieldPinPadListener);
        SmartClientManager.addListener(acceptListener);
    };

    $bDlgErrorOk.click(function () {
        hideDlgError();
    });

    $bPay.click(function (e) {
        e.preventDefault();
        showDlgWait();
        var fieldValueForStateLogging = fieldInstance.IsCrypt ? "****SECURE****" : fieldManager.getViewFieldValue();
        SmartClientManager.writeStateToLog("Заполнено поле \"" + fieldInstance.Title + "\" значением: " + fieldValueForStateLogging);
        var fieldValue = fieldManager.getHiddenFieldValue();
        fieldsMap["field" + FIELD_ID] = fieldValue;
        OperatorFieldsEditingUtil.processFieldsBeforePayAsync({
            invoiceSearchEnabled: IS_INVOICE_SEARCH_ENABLED,
            fieldsCheckingEnabled: IS_FIELDS_CHECKING_ENABLED,
            urlGetFieldsMapByAnswerData: URLGetFieldsMapByAnswerData,
            operatorId: operatorId,
            fieldsMap: fieldsMap,
            operatorInstance: operatorInstance,
            error: function (msg) {
                hideDlgWait();
                showDlgError(msg);
            },
            callback: function (fieldsMap) {
                OperatorFieldsFormManager.navigate();
            }
        });
    });

    var acceptListener = new Listener({
        pinPadAcceptPressed: function (args) {
            if (isMobileOperatorAutoDetect) $bForward.click();
            else $bPay.click();
        }
    });

    var MobileOperatorAutoDetectUtil = {
        detectMobileOperatorAsync: function (phoneNumber, callback) {
            var fullUrl = passParamToURL(URLDetectMobileOperator, { phoneNumber: phoneNumber, clientDate: new Date() });
            $.getJSON(fullUrl, function (result) {
                callback(result);
            });
        }
    };

    $(window).bind("unload", function () {
        if (FIELD_TYPE != "enum") SmartClientManager.removeListener(fieldPinPadListener);
        SmartClientManager.removeListener(acceptListener);
    });

    var tbField = document.getElementById("tbField");

    fieldManager = FieldsUtil.createFieldManagerForField({
        field: fieldInstance,
        operator: operatorInstance,
        isFieldEditable: true,
        fieldKey: "field" + FIELD_ID,
        textBoxId: "tbField",
        fieldManagerSuffix: FIELD_ID,
        oncomplete: function () {
            var fieldManager = this;
            var fieldValueForStateLogging = fieldInstance.IsCrypt ? "****SECURE****" : fieldManager.getViewFieldValue();
            SmartClientManager.writeStateToLog("Заполнено поле \"" + fieldInstance.Title + "\" значением: " + fieldValueForStateLogging);
            if (isMobileOperatorAutoDetect) {
                var phoneNumber = fieldManager.getHiddenFieldValue();
                if (!phoneNumber.length) return;
                SmartClientManager.writeStateToLog("Автоопределение оператора по номеру телефона " + phoneNumber + "...");
                MobileOperatorAutoDetectUtil.detectMobileOperatorAsync(phoneNumber, function (detectedOperatorId) {
                    var showDlgFailedToDetectMobileOperator = function () {
                        if (dlgNavigateTelecom != null) {
                            dlgNavigateTelecom.show();
                        } else {
                            showDlgError(TerminalUI.UIMessageMap["TELECOM_OPERATOR_DETECTION_FAILED"]);
                        }
                    };
                    var autonavigateToFoundOperator = function () {
                        $bForward.data("detectedOperatorId", detectedOperatorId).removeClass("th-hidden");
                        SmartClientManager.addListener(acceptListener);
                        if (!$bForward.data("preventAutoNavigation")) $bForward.click();
                    };
                    if (detectedOperatorId != -1) {
                        SmartClientManager.writeStateToLog("Оператор по номеру телефона " + phoneNumber + " найден с id=" + detectedOperatorId + ". Проверка существования такого оператора в конфигурации и меню...");
                        FS.TerminalUI.ajaxService.postJSON(URL_CHECK_OPERATOR_EXISTS, { id: detectedOperatorId }, function (resultCtx) {
                            var exists = resultCtx.exists,
                                menuItemExists = resultCtx.menuItemExists;
                            if (exists) {
                                SmartClientManager.writeStateToLog("Оператор с id=" + detectedOperatorId + " найден в текущей конфигурации.");
                                if (menuItemExists) {
                                    SmartClientManager.writeStateToLog("Пункт меню с оператором id=" + detectedOperatorId + " найден в меню.");
                                    SmartClientManager.writeStateToLog("Автопереход на страницу с автоопределенным оператором...");
                                    autonavigateToFoundOperator();
                                } else {
                                    SmartClientManager.writeStateErrorToLog("Пункт меню с оператором id=" + detectedOperatorId + " НЕ найден в меню.");
                                    showDlgFailedToDetectMobileOperator();
                                }
                            } else {
                                SmartClientManager.writeStateErrorToLog("Оператор с id=" + detectedOperatorId + " НЕ найден в текущей конфигурации. Проверьте настройки провайдеров для терминала.");
                                var telecomGroupTarget = TerminalUI.Config.Operators.TelecomGroupTarget;
                                showDlgFailedToDetectMobileOperator();
                            }
                        });
                    } else {
                        SmartClientManager.writeStateErrorToLog("Оператор по номеру телефона " + phoneNumber + " НЕ найден. Проверьте настройки автоопределения оператора по номеру телефона.");
                        showDlgFailedToDetectMobileOperator();
                    }
                });
            } else {
                $bPay.removeClass("th-hidden");
                SmartClientManager.addListener(acceptListener);
            }
        },
        onincomplete: function () {
            if (isMobileOperatorAutoDetect) {
                $bForward.data("preventAutoNavigation", 0);
                if (!$bForward.hasClass("th-hidden")) {
                    $bForward.addClass("th-hidden");
                }
            } else {
                if (!$bPay.hasClass("th-hidden")) {
                    $bPay.addClass("th-hidden");
                }
            }
            SmartClientManager.removeListener(acceptListener);
        }
    });

    if (isMobileOperatorAutoDetect && !fieldManager.isComplete()) $bForward.data("preventAutoNavigation", 0);
    if (FIELD_TYPE != "enum") SmartClientManager.addListener(fieldPinPadListener);

    fieldManager.checkComplete();
});