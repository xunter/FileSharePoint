﻿/// <reference path="../../SmartClientManager.js" />
/// <reference path="../../Payment/ChequeManager.js" />
/// <reference path="../../../Views/Home/CashReceive.cshtml" />
/// <reference path="~/Scripts/Payment/FetchPaymentReceiptLogic.js" />
(function (window, $, NavManager, TerminalUI, DlgManager, SmartClientManager, WaitMsgManager) {
    var payListener = {
        pinPadAcceptPressed: function (args) {
            var $bPay = CashReceivePage.$bPay;
            if (!$bPay.hasClass("th-hidden") && !$bPay.hasClass("hidden") && $bPay.data("billValidatorState") != "Disable") $bPay.click();
        }
    };
    var navManager = NavManager.getInstance();

    function CashReceivePageType() {
        this._billValidator = null;
    };

    CashReceivePageType.prototype = {
        initialChangeSum: null,
        currentChangeSum: null,
        billValidatorOpened: false,
        chequeManager: null,
        currentChequeNum: null,
        $cashInfoContainer: null,
        $bPay: null,
        $bMenu: null,
        $bCancel: null,
        $lError: null,
        $bDlgErrorOk: null,
        $dlgError: null,
        $bPutCashToChange: null,
        $dlgBillValidatorNotOperable: null,
        $bDlgBillValidatorNotOperableOK: null,
        smartClientManager: SmartClientManager,
        urlCabinetAddOperator: urlCabinetAddOperator,
        urlStart: urlStart,
        urlNextChequeNum: URL_GET_NEXT_RECEIPT_NUM,
        fieldsMap: fieldsMap,
        smartClientManager: SmartClientManager,
        loggingService: FS.TerminalUI.loggingService,
        ajaxService: FS.TerminalUI.ajaxService,
        billValidatorState: null,
        preventSaveChangeSumOnPageExit: false,
        operatorInstance: operatorInstance,
        getFieldsMapForTransfering: function () {
            return this.chequeManager.getFieldsMapForTransfering(this.fieldsMap);
        },
        init: function (settings) {
            var self = this;
            this.loggingService.trace("CashReceive initializing...");
            this.registerToTrackBillValidatorState();
            if (settings.hasOwnProperty("hideBackAndMenuBtnsWhenChangeSumIsNotZero")) this._hideBackAndMenuBtnsWhenChangeSumIsNotZero = settings.hideBackAndMenuBtnsWhenChangeSumIsNotZero;

            if (settings.hasOwnProperty("initialChangeSum")) this.initialChangeSum = settings.initialChangeSum;
            this.chequeManager = new ChequeManager(this.ajaxService, this.loggingService, {
                urlFetchNextChequeNum: URL_GET_NEXT_RECEIPT_NUM,
                urlFetchReceipt: URL_RENDER_RECEIPT,
                urlFetchReceiptDefault: URL_RENDER_RECEIPT_DEFAULT,
                urlVerifyReceiptTemplateExistsForOperator: URL_VERIFY_RECEIPT_TEMPLATE_EXISTS,
                urlFetchPaymentErrorReceipt: URL_FETCH_PAYMENT_ERROR_RECEIPT,
                urlVerifyPaymentErrorTemplateExists: URL_VERIFY_PAYMENT_ERROR_TEMPLATE_EXISTS
            });
        },

        initBillValidator: function () {
            var self = this;
            this.loggingService.trace("CashReceive: BillValidator initializing...");
            var scm = self.smartClientManager;
            scm.addHandler("billValidatorExceededBill", function (exceededBill) {
                if (TerminalUI.UISettingsMap["SHOW_DLG_MAX_SUM_EXCEEDED"] == "1") {
                    DlgManager.hideDlgInvalidBill(self.$dlgInvalidBill);
                    CashReceivePage.showDlgMaxSumExceeded();
                }
            });

            scm.addHandler("billValidatorExceededSum", function (exceededSum) {
            });
        },

        hideBackAndMenuBtnsWhenChangeSumIsNotZero: function () {
            if (sumsInfo.ChangeSumInfo.IsAvailable) {
                this.hideBackAndMenuBtns();
            }
        },
        hideBackAndMenuBtns: function () {
            this.$bMenu.addClass("th-hidden");
            this.$bCancel.addClass("th-hidden");
        },
        billValidatorStateTrackHandler: function (state) {
            var prevState = this.billValidatorState;
            this.billValidatorState = state;
        },
        registerToTrackBillValidatorState: function () {
            var self = this;
            this.smartClientManager.addHandler("billValidatorState", function (state) { self.billValidatorStateTrackHandler(state) });
        },
        load: function () {
            var self = this;

            this.$cashInfoContainer = $("#divCashBody");
            var $bPay = this.$bPay = $("#bPay");
            var $bMenu = this.$bMenu = $("#bMenu");
            var $bCancel = this.$bCancel = $("#bCancel");

            this.$lError = $("#lError");
            this.$bDlgErrorOk = $("#bDlgErrorOk");
            this.$dlgError = $("#dlgError");
            this.$bDlgErrorOk.click(function () { self.bDlgErrorOkClickHandler() });
            this.$bPutCashToChange = $("#bPutCashToChange");
            this.$dlgBillValidatorNotOperable = $("#dlgBillValidatorNotOperable");
            this.$bDlgBillValidatorNotOperableOK = $("#bDlgBillValidatorNotOperableOK");
            this.$bDlgBillValidatorNotOperableOK.click(function () { self.bDlgBillValidatorNotOperableOKClickHandler() });

            var $dlgMaxSumExceeded = self.$dlgMaxSumExceeded = $("#dlgMaxSumExceeded");
            var $btnDlgMaxSumExceededOk = self.$btnDlgMaxSumExceededOk = $("#btnDlgMaxSumExceededOk");

            $btnDlgMaxSumExceededOk.click(function () {
                DlgManager.hideDlg($dlgMaxSumExceeded);
            });

            if (this._hideBackAndMenuBtnsWhenChangeSumIsNotZero) {
                this.hideBackAndMenuBtnsWhenChangeSumIsNotZero();
            }
            if (isCabinetAddOperator) {
                CabinetManager.addCabinetOperatorAsync(operatorInstance.ID, self.fieldsMap, function (resultCtx) {
                });
            }

            this.$bPutCashToChange.click(function () { self.bPutCashToChangeClickHandler() });
            WaitMsgManager.init();
        },

        showDlgMaxSumExceeded: function () {
            this.loggingService.trace("Showing DlgMaxSumExceeded...");
            DlgManager.showDlgMaxSumExceeded(this.$dlgMaxSumExceeded);
            this.loggingService.trace("DlgMaxSumExceeded was shown.");
        },

        hideDlgMaxSumExceeded: function () {
            this.loggingService.trace("Hiding DlgMaxSumExceeded...");
            DlgManager.hideDlg(this.$dlgMaxSumExceeded);
            this.loggingService.trace("DlgMaxSumExceeded was hidden.");
        },

        setBillValidatorClosed: function (callback) {
            this.closeBillValidator(callback);
        },

        bPutCashToChangeClickHandler: function () {
            var self = this;
            var loggingService = TerminalUI.loggingService;
            var scm = SmartClientManager;
            loggingService.trace("Starting save all money to the change sum...");
            self.showWaitDlg();
            loggingService.trace("Closing the bill validator...");
            self.setBillValidatorClosed(function () {
                self.preventSaveChangeSumOnPageExit = true;
                scm.writeStateErrorToLog(TerminalUI.UIMessageMap["LOG_MSG_BTN_PUT_CASH_CHANGE_CLICK"]);
                loggingService.trace("Saving money to change sum...");
                self.putCashToChangeSumAsync(function () {
                    loggingService.trace("All money have been saved to the change sum.");
                    scm.writeStateToLog(TerminalUI.UIMessageMap["LOG_STATE_NAVIGATE_START_DUE_BTN_PUT_CHANGE_SUM_CLICK"]);
                    loggingService.trace("Navigating to the start page after successful saving all money to the change sum...");
                    self.navigateStart();
                });
            });
        },

        navigateStart: function () {
            SmartClientManager.writeStateToLog(TerminalUI.UIMessageMap["LOG_STATE_NAVIGATE_START_CASH_RECEIVE_COMMON"]);
            ClientSidePage.layoutPage.navigateToMainMenu();
        },

        getAvailableMoneyAmount: function () {
            this.loggingService.trace("sumFromBillValidator = %1, changeSum = %2", sumFromBillValidator, sumsInfo.ChangeSumInfo.Sum);
            this.loggingService.trace("An available money amount: %1", (sumFromBillValidator + sumsInfo.ChangeSumInfo.Sum));
            return sumFromBillValidator + sumsInfo.ChangeSumInfo.Sum;
        },

        putCashToChangeSumAsync: function (callback) {
            var newChangeSum = this.getAvailableMoneyAmount();
            ChangeSumManager.Instance.pushChangeSumAsync(newChangeSum, function () {
                if (typeof (callback) != "undefined") callback();
            });
        },

        addCabinetOperatorAsync: function () {
            var self = this;
            this.smartClientManager.sendOnlineRequestAsync({
                request: {
                    type: 20,
                    cabinetId: cabinetInfo.ID,
                    userId: cabinetInfo.UserID,
                    operatorId: operatorInstance.ID,
                    fields: fieldsMap
                },
                callback: function (args) {
                    var result = args.result;
                    var responseMap = args.responseMap;
                    if (result == FS.GatewayResultCodes.Success) {
                        var accountID = responseMap.ANSWER_DATA;
                        var fieldsMapForTransfering = self.getFieldsMapForTransfering();
                        var addOperatorInfo = { OperatorID: operatorInstance.ID, UserId: cabinetInfo.UserID, CabinetID: cabinetInfo.ID, AccountID: accountID, FieldsMapFromJSON: fieldsMapForTransfering };
                        FS.TerminalUI.ajaxService.postJSON(self.urlCabinetAddOperator, addOperatorInfo);
                    } else {
                        self.showErrorDlg("Ошибка сервера!");
                    }
                }
            });
        },

        bDlgBillValidatorNotOperableOKClickHandler: function () {
            var self = this;
            var scm = SmartClientManager;
            self.hideDlgBillValidatorNotOperable();

            if (!sumsInfo.ChangeSumInfo.IsAvailable) {
                WaitMsgManager.show();
                scm.writeStateToLog("LOG_STATE_NAVIGATE_START_DUE_BILL_VALIDATOR_NOT_OPERABLE_OK_CLICK_CHANGE_SUM_EMPTY");
                self.navigateStart();
            } else {
                if (sumsInfo.RequiredSumInfo.IsAvailable) {
                    if (sumsInfo.RequiredSumInfo.EntireSum > sumsInfo.ChangeSumInfo.Sum) {
                        WaitMsgManager.show();
                        this.putCashToChangeSumAsync(function () {
                            scm.writeStateToLog("LOG_STATE_NAVIGATE_START_DUE_BILL_VALIDATOR_NOT_OPERABLE_OK_CLICK_CHANGE_SUM_LESS_REQUIRED_SUM");
                            self.navigateStart();
                        });
                    } else {
                        CashReceivePage.showDlgRequiredAmountInfo();
                    }
                }
            }
        },

        fetchNextChequeNumAsync: function (callback) {
            var self = this;
            this.chequeManager.fetchNextChequeNumAsync(function (newChequeNum) {
                self.currentChequeNum = newChequeNum;
                if (typeof (callback) != "undefined") callback(newChequeNum);
            });
        },

        showDlgBillValidatorNotOperable: function () {
            DlgManager.showDlg(this.$dlgBillValidatorNotOperable);
        },

        hideDlgBillValidatorNotOperable: function () {
            DlgManager.hideDlg(this.$dlgBillValidatorNotOperable);
        },

        bDlgErrorOkClickHandler: function () {
            this.hideErrorDlg();
        },
        showWaitDlg: function () {
            WaitMsgManager.show();
        },
        hideWaitDlg: function () {
            WaitMsgManager.hide();
        },
        showErrorDlg: function (msg) {
            this.$lError.text(msg);
            DlgManager.showDlg(this.$dlgError);
        },
        hideErrorDlg: function () {
            DlgManager.hideDlg(this.$dlgError);
        },

        showDlgRequiredAmountInfo: function () {
            var $dlgRequiredAmountInfo = $("#dlgInfoChangeSum");
            DlgManager.showDlg($dlgRequiredAmountInfo);
            $("#dlgInfoChangeSum").removeClass("th-hidden");
            $("#bChangeSumAcceptForward").click(function () {
                DlgManager.hideDlg($dlgRequiredAmountInfo);
            });
        },

        pollBillValidatorStateAsync: function (callback) {
            var self = this,
                smartClientManager = self.smartClientManager,
                loggingService = self.loggingService;
            smartClientManager.stateBillValidatorAsync(function (state) {
                if (callback) callback(state);
            });
        },

        navigateToError: function (userMsg) {
            ClientSidePage.layoutPage.navigateToError(userMsg);
        },

        navigateToPaymentError: function (userMsg) {
            this.navigateToError(userMsg);
        },

        updateCashInfo: function (sum, url) {
            var self = this,
                url = url ? url : URL_PAYMENT_INFO;
            var sumAsText = sum.toFixed(2);
            this.ajaxService.postJSON(url, { sum: sumAsText }, function (htmlChunk) {
                self.$cashInfoContainer.html(htmlChunk);
            });
        },

        updateCashInfoRequired: function (requiredAmount, amount, currentChangeSum) {
            var self = this,
            postData = { amount: amount, requiredAmount: requiredAmount };
            this.ajaxService.postJSON(URL_PAYMENT_INFO_REQUIRED, { amount: amount, requiredAmount: requiredAmount, changeSum: currentChangeSum }, function (htmlChunk) {
                self.$cashInfoContainer.html(htmlChunk);
            });
        },

        updateChangeSumOnStartAsync: function (callback) {
            var newChangeSum = null;
            var currChangeSum = sumsInfo.ChangeSumInfo.Sum;
            if (isRequiredAmountDefined) {
                newChangeSum = currChangeSum - sumsInfo.RequiredSumInfo.EntireSum;
                if (newChangeSum < 0) newChangeSum = 0;
            } else {
                newChangeSum = 0;
                var op = this.operatorInstance;
                var limit = op.RestrictionsInstance;
                var maxLimit = limit.Max;
                if (currChangeSum > maxLimit) {
                    newChangeSum = currChangeSum - maxLimit;
                }
            }
            this.currentChangeSum = newChangeSum;
            ChangeSumManager.Instance.updateChangeSumAsync(newChangeSum, function () {
                if (callback) callback();
            });
        },

        openBillValidator: function (maxAvailableSum) {
            maxAvailableSum = maxAvailableSum || 0;
            SmartClientManager.openBillValidator(maxAvailableSum);
            this.billValidatorOpened = true;
        },

        closeBillValidator: function (callback) {
            var self = this;
            var triggerCallback = function () {
                if (callback) callback();
            };
            if (CashReceivePage.billValidatorOpened) {
                SmartClientManager.closeBillValidatorAsync(function () {
                    self.billValidatorOpened = false;
                    triggerCallback();
                });
            } else {
                triggerCallback();
            }
        },

        activatePayBtn: function () {
            var $bPay = this.$bPay;
            if ($bPay.hasClass("th-hidden")) {
                $bPay.removeClass("th-hidden");
            }
            CashReceivePage.smartClientManager.addListener(payListener);
        },

        isBtnPutCashChangeHidden: function () { return CashReceivePage.$bPutCashToChange.hasClass("th-hidden") },

        isBtnPutCashChangeShown: function () { return !CashReceivePage.isBtnPutCashChangeHidden() },

        showBtnPutCashChange: function () {
            if (CashReceivePage.isBtnPutCashChangeHidden()) {
                CashReceivePage.$bPutCashToChange.removeClass("th-hidden");
            }
        },

        hideBtnPutCashChange: function () {
            if (CashReceivePage.isBtnPutCashChangeShown()) {
                CashReceivePage.$bPutCashToChange.addClass("th-hidden");
            }
        },

        navigateSuccessPayment: function (callback) {
            var path = SUCCESS_PAYMENT_PATH;
            if (ChangeSumManager.Instance.isChangeSumAvailable() && TerminalUI.UISettingsMap["CHANGE_SUM_PAGE_ENABLED"] == "1") {
                path = URL_CHANGE_SUM_INFO;
            }
            var loggingService = TerminalUI.loggingService;
            loggingService.info(TerminalUI.UIMessageMap["LOG_MSG_SUCCESS_PAYMENT_NAVIGATING"]);
            SmartClientManager.writeStateToLog("LOG_MSG_SUCCESS_PAYMENT_NAVIGATING");

            navManager.navigateAsync(path, function () {
                if (callback) callback();
            });
        },

        printReceiptAsync: function (receiptNum, callback) {
            var self = this,
            loggingService = this.loggingService,
            operatorInstance = this.operatorInstance,
            operatorId = operatorInstance.ID,
            smartClientManager = this.smartClientManager,
            receiptManager = this.chequeManager;
            try
            {
                var printDate = new Date();

                var printReceipt = function (receiptText) {
                    try {
                        smartClientManager.printText(receiptText, amountAll, $.proxy(function () {
                            callback(true);
                        }, this));
                    } catch (e) {
                        var msg = "Не удалось напечатать чек " + receiptNum + " на принтере! Ошибка скрипта: " + e.toString() + "line: " + ( e.line ? e.line : "") +"Stack:" + e.stack  + ".";
                        loggingService.error(msg);
                        smartClientManager.writeStateErrorToLog(msg);
                        callback(false);
                    }
                },
                fetchReceiptLogic = new FetchPaymentReceiptLogic(this.chequeManager);

                fetchReceiptLogic.fetchReceiptAsync(operatorInstance, self.fieldsMap, amountAll, amount, amountComission, printDate, receiptNum,
                    $.proxy(
                        function (resultCtx)
                        {
                            if (resultCtx.error === true)
                            {
                                callback(false);
                            }
                            else
                            {
                                printReceipt(resultCtx.receiptText);
                            }
                        }
                    , this));

            }
            catch (e)
            {
                var msg = "Ошибка скрипта формирования данных для печати чека с номером " + receiptNum + ": " + e.toString() + ".";
                loggingService.error(msg);
                smartClientManager.writeStateErrorToLog(msg);
                triggerFail();
            }
        },

        getBillValidator: function () { return this._billValidator; }
    };
    var CashReceivePage = new CashReceivePageType();
    CashReceivePage.init({ hideBackAndMenuBtnsWhenChangeSumIsNotZero: false, initialChangeSum: INITIAL_CHANGE_SUM });

    //Load the current change sum
    navManager.addPageLoadAsyncTask(function () {
        var self = this;
        CashReceivePage.updateChangeSumOnStartAsync(function () {
            self.complete();
        });
    });

    if (isRequiredAmountDefined) {
        if (sumsInfo.CurrentSumInfo.Sum > sumsInfo.RequiredSumInfo.EntireSum) {
            amount = sumsInfo.RequiredSumInfo.EntireSum;
        }
    }

    var isPaymentSuccessful = false;

    var op = CashReceivePage.operatorInstance;
    var limit = op.RestrictionsInstance;
    var maxLimit = FS.TerminalUI.UISettingsMap["PAYMENT_GLOBAL_MAX_SUM_MODE"] == "RestrictByEntireAmount" ? sumsInfo.MaxSumInfo.Sum : sumsInfo.MaxSumInfo.EntireSum;
    if (FS.TerminalUI.UISettingsMap["PAYMENT_GLOBAL_MAX_SUM_ENABLED"] == "1") {
        var globalMaxSumLimit = FS.TerminalUI.UISettingsMap["PAYMENT_GLOBAL_MAX_SUM_MODE"] == "RestrictByEntireAmount" ? sumsInfo.GlobalMaxSumInfo.Sum : sumsInfo.GlobalMaxSumInfo.EntireSum;
        if (globalMaxSumLimit < maxLimit) {
            maxLimit = globalMaxSumLimit;
        }
    }

    var sumFromBillValidator = 0;
    var allowDenyIdleTimeoutHandler = true;
    var allowPay = sumsInfo.IsReadyToPay;
    var billValidatorBtnStateDisabled = false;
    var billValidatorCashProcessing = false;
    var billValidatorTriggerred = false;
    var billSum = sumsInfo.CurrentSumInfo.Sum;
    var currentChangeSum = sumsInfo.ChangeSumInfo.Sum;
    var requiredSum = sumsInfo.RequiredSumInfo.EntireSum;
    var requiredEntireSum = sumsInfo.RequiredSumInfo.EntireSum;
    var requiredPaymentSum = sumsInfo.RequiredSumInfo.Sum;
    var initialSum = currentChangeSum;
    var entireSum = initialSum;
    var payEntireSum = entireSum;
    var neededPaymentSum = maxLimit;
    if (requiredSum > 0) {
        neededPaymentSum = requiredSum;
    }

    var amount = sumsInfo.CurrentSumInfo.Sum;
    var amountAll = sumsInfo.CurrentSumInfo.EntireSum;
    var amountComission = sumsInfo.CurrentSumInfo.ComissionSum;
    var changeSum = currentChangeSum;

    var neededCashAmount = neededPaymentSum - initialSum;
    if (neededCashAmount < 0) neededCashAmount = 0;

    var cashLimit = maxLimit;
    if (requiredSum > 0 && TerminalUI.UISettingsMap["BILL_VALIDATOR_MAX_SUM_BILL_MAX_SUM_MODE"] == "RequiredSum") {
        cashLimit = requiredSum;
    }

    cashLimit = cashLimit - initialSum;
    if (cashLimit < 0) cashLimit = 0;


    if (currentChangeSum > maxLimit) {
        var changeSumInc = 0;
        if (requiredSum > 0) {
            payEntireSum = requiredSum;
            changeSumInc = initialSum - payEntireSum;
        } else {
            payEntireSum = maxLimit;
            changeSumInc = initialSum - payEntireSum;
        }
        NavManager.getInstance().addPageLoadAsyncTask(function () {
            var self = this;
            ChangeSumManager.Instance.updateChangeSumAsync(changeSumInc, function () {
                self.complete();
            });
        });
    }

    var $operatorContainer = null;
    var $transactionInfoContainer = null;
    var $dlgMaxSumExceeded = null;
    var $btnDlgMaxSumExceededOk = null;
    var $dlgInvalidBill = CashReceivePage.$dlgInvalidBill = null;
    var $btnDlgInvalidBill = CashReceivePage.$btnDlgInvalidBill = null;
    var $bMenu = null;
    var $bCancel = null;
    var $bPay = null;
    var $bPutCashToChange = null;
    var billValidatorListener = null;

    var bPayClickHandler = function () {
        SmartClientManager.paid = true;
        var self = this;
        var loggingService = CashReceivePage.loggingService;
        var date = new Date();
        var operatorId = operatorInstance.ID;
        if (!allowPay) {
            loggingService.warn("Unable to execute bPayClickHandler because cash is being processed!");
            return;
        }
        CashReceivePage.showWaitDlg();
        var payHandler = function () {
            loggingService.trace("The payHandler function has executed. Removing a bill validator listener...");
            SmartClientManager.removeListener(billValidatorListener);
            loggingService.trace("The bill validator listener was removed.");
            loggingService.trace("AMOUNT equals %1.", amount);
            loggingService.trace("AMOUNT_ALL equals %1.", amountAll);

            CashReceivePage.loggingService.trace("Fetching the next cheque num...");

            var paymentFailed = function (reasonMsg, userMsg) {
                var continuePayError = function (reasonMsg) {
                    SmartClientManager.writeStateErrorToLog("Переход на страницу ошибки по причине: " + reasonMsg);
                    CashReceivePage.navigateToPaymentError(userMsg);
                };

                CashReceivePage.chequeManager.fetchPaymentErrorReceipt(operatorId, date, amountAll, function (fetchPaymentErrorReceiptArgs) {
                    if (fetchPaymentErrorReceiptArgs.error) {
                        SmartClientManager.writeStateErrorToLog("Не удалось сформировать чек об ошибке платежа!");
                    } else {
                        SmartClientManager.printText(fetchPaymentErrorReceiptArgs.receiptText, amountAll, function () {
                            TerminalUI.events.notify("paymentFailed", { reasonMsg: reasonMsg });
                            continuePayError(reasonMsg);
                        });
                    }
                });
            }

            CashReceivePage.fetchNextChequeNumAsync(function (nextChequeNum) {

                loggingService.trace("cheque num " + nextChequeNum + " notifying...");
                TerminalUI.events.notify("nextChequeNumGiven", nextChequeNum);

                loggingService.trace("cheque num " + nextChequeNum + " notified");

                if (nextChequeNum.error) {
                    loggingService.fatal("Failed to pay due to an error was occured while fetching the next cheque num.");
                    SmartClientManager.writeStateErrorToLog("Произошла ошибка при получении следующего номера чека.");
                    paymentFailed("Ошибка чтения следующего значения номера чека");
                } else {

                    var chequeNum = formatNumber(nextChequeNum, 4);
                    CashReceivePage.loggingService.trace("The next cheque has been fetched. It is %1", chequeNum);

                    var successOffline = function () {
                        isPaymentSuccessful = true;
                        CashReceivePage.printReceiptAsync(chequeNum, function (success) {
                            if (!success) {
                                var errorMsg = "Не удалось напечатать чек с номером " + chequeNum + " для оператора " + CashReceivePage.operatorInstance.ID + "!";
                                loggingService.error(errorMsg);
                                CashReceivePage.smartClientManager.writeStateErrorToLog(errorMsg);
                            }
                            TerminalUI.events.notify("paymentSuccess", { operatorId: operatorId, operatorName: operatorName, operatorInstance: operatorInstance, chequeNum: chequeNum });
                            CashReceivePage.navigateSuccessPayment();
                        });
                    };

                    $bPay.unbind("click", bPayClickHandler);

                    if (FS.TerminalUI.UISettingsMap["AMOUNT_DIFF_REQUEST_ENABLED"] == "1") {

                        SmartClientManager.writeToLog("Change sum: " + sumsInfo.ChangeSumInfo.Sum);
                        SmartClientManager.writeToLog("Cash accepted by billValidator: " + sumFromBillValidator);

                        var cash = sumsInfo.ChangeSumInfo.Sum + sumFromBillValidator;
                        SmartClientManager.writeToLog("'cash != amountAll' is " + (cash != amountAll));

                        if (cash != amountAll) {
                            var request55 = {
                                amount_cash: cash,
                                amount_pay: amountAll,
                                notes: "<notes><notes>"
                            };

                            SmartClientManager.writeToLog("Sending a request of the AmountDiffRequest type ...");
                            SmartClientManager.sendAmountDiffRequestAsync({
                                request: request55,
                                callback: function(result) {
                                    var responseMap = result.responseMap;
                                    var result = result.result;

                                    SmartClientManager.writeToLog("The request of the AmountDiffRequest type has sent. Result is " + result + ". Response data is " + result.responseData + ".");
                                    if (result == 0) {
                                        loggingService.trace("The response code is SUCCESSFULL. Handling the success handler...");
                                    } else {
                                        var errorCode = result.error;
                                        var keyErrorMsg = "Gateway_ErrorCode_" + errorCode;
                                        var gatewayErrorMsg = null;
                                        if (TerminalUI.UIMessageMap.hasOwnProperty(keyErrorMsg)) {
                                            gatewayErrorMsg = TerminalUI.UIMessageMap[keyErrorMsg];
                                        }
                                        if (gatewayErrorMsg != null) {
                                            stateErrorMsg += " Сервер возвратил ошибку: " + gatewayErrorMsg + " (" + errorCode + ")";
                                        }
                                        SmartClientManager.writeStateErrorToLog(stateErrorMsg);
                                        loggingService.fatal("Failed to pay due to an error response code from the Gateway was received.");
                                    }
                                }
                            });
                        }
                    }

                    var request = {
                        op: operatorName,
                        amount: amount,
                        amountAll: amountAll,
                        initDateTime: date,
                        chequeNum: chequeNum,
                        operatorId: operatorId,
                        fields: fieldsMap
                    };
                    if (isCabinetSession && cabinetInfo != null) {
                        request.cabinetId = cabinetInfo.ID;
                        request.userId = cabinetInfo.UserID;
                    }
                    isCardRecharge = ClientSidePage.layoutPage.getCurrUrl().indexOf("cardRecharge=True") !== -1;
                    if (isCardRecharge) {
                        request.isCardRecharge = true;
                        request.stan = CardManager.generateStan();
                    }
                    SmartClientManager.writeToLog("Sending a request of the RegisterPaymentRequest type ...");
                    SmartClientManager.sendOfflineRequestAsync({
                        request: request,
                        callback: function (result) {
                            var responseMap = result.responseMap;
                            
                            SmartClientManager.writeToLog("The request of the RegisterPaymentRequest type has sent. Result is " + JSON.stringify(result));

                            SmartClientManager.writeToLog("Computing new change sum...");
                            var newChangeSum = entireSum + sumFromBillValidator - amountAll;

                            newChangeSum = parseFloat(newChangeSum.toFixed(2));
                            SmartClientManager.writeToLog("The computed change sum is " + newChangeSum + ".");
                            SmartClientManager.writeToLog("Pushing the computed change sum to the server...");
                            ChangeSumManager.Instance.updateChangeSumAsync(newChangeSum, function () {
                                SmartClientManager.writeToLog("The computed change sum has pushed to the server.");

                                if (result.result == 0 && result.responseMap.ERROR == "0")
                                {
                                    var triggerSuccessOnline = function () {
                                        SmartClientManager.writeToLog("Executing the success callback...");
                                        successOffline();
                                        SmartClientManager.writeToLog("The success callback was executed.");
                                    };
                                    
                                    if (isCardRecharge && TerminalUI.UISettingsMap["CARD_RECHARGE_PROPER_REQUEST_USED"] == "1") {
                                        if (responseMap.hasOwnProperty("ANSWER_DATA")) {
                                            loggingService.trace("A card transaction response has an answer data xml. Parsing the xml...");
                                            var invoiceXml = responseMap["ANSWER_DATA"];
                                            CardManager.parseTransactionRequestXml(invoiceXml, function (invoiceMap) {
                                                CardManager.setCurrentTransaction(invoiceMap);
                                                var responseCode = invoiceMap["RESPONSE_CODE"];
                                                loggingService.trace("The xml parsed and responseCode is \"%1\". Handling it...", responseCode);

                                                if (responseCode == "00") {
                                                    loggingService.trace("The response code is SUCCESSFULL. Handling the success handler...");
                                                    triggerSuccessOnline();
                                                } else {
                                                    loggingService.trace("The response code is UNSUCCESSFULL and the card transaction is FAILED. Checking the failed response code...");
                                                    var cardResponseCodeInfo = FS.TerminalUI.CardAuthResponseCodesMap[responseCode];
                                                    loggingService.trace("The info about the given response code is %1.", toJSON(cardResponseCodeInfo));
                                                    var errorMsg = "";
                                                    if (cardResponseCodeInfo != null) {
                                                        errorMsg = TerminalUI.UIMessageMap["CardOperationFailedGeneralMsgTemplate"].replace("{0}", cardResponseCodeInfo.UserMessage);
                                                    }
                                                    loggingService.trace("Handling the failing handler with the error message is \"%1\"...", errorMsg);
                                                    paymentFailed("Шлюз карты прислал ответ: " + responseCode + ". Сообщение: " + errorMsg, errorMsg);
                                                }
                                            });
                                        } else {
                                            loggingService.error("A card transaction response doesn't have an answer data xml! Handling the failed handler...");
                                            paymentFailed("Шлюз НЕ прислал ANSWER_DATA!");
                                        }
                                    } else {
                                        if (isCardRecharge) {
                                            if (TerminalUI.UISettingsMap["CARD_RECHARGE_PROPER_REQUEST_USED"] == "0") {
                                                var offlineCardTx = { CARD_NUMBER: CARD_NUMBER, CARD_TERMINAL_ID: CARD_TERMINAL_ID, AUTH_CODE: "", RRN: "" };
                                                CardManager.setCurrentTransaction(offlineCardTx);
                                            }
                                        }
                                        triggerSuccessOnline();
                                    }

                                } else {
                                    var errorCode = result.responseMap.ERROR;
                                    var keyErrorMsg = "Gateway_ErrorCode_" + errorCode;
                                    var gatewayErrorMsg = null;
                                    if (TerminalUI.UIMessageMap.hasOwnProperty(keyErrorMsg)) {
                                        gatewayErrorMsg = TerminalUI.UIMessageMap[keyErrorMsg];
                                    }
                                    var stateErrorMsg = "Платеж для оператора " + operatorId + " на сумму " + entireSum + " с номером чека " + nextChequeNum + " на дату и время " + formatDate(date, "yyyy-MM-dd HH:mm:ss") + " не выполнен.";
                                    if (gatewayErrorMsg != null) {
                                        stateErrorMsg += " Сервер возвратил ошибку: " + gatewayErrorMsg + " (" + errorCode + ")";
                                    }
                                    SmartClientManager.writeStateErrorToLog(stateErrorMsg);
                                    loggingService.fatal("Failed to pay due to an error response code from the Gateway was received.");

                                    paymentFailed("Шлюз прислал код ошибки");
                                }

                            });
                        }
                    });
                }
            });
        };
        if (CashReceivePage.billValidatorState == "Operable") {
            CashReceivePage.closeBillValidator(payHandler);
        } else {
            payHandler();
        }
    };

    var processPayment = TerminalUI.processPayment = function (callback) {
        var ctx = {};
        TerminalUI.events.singleHandler("paymentSuccess", function (paymentCtx) {
            ctx = $.extend(ctx, paymentCtx, { success: true });
            if (callback) callback(ctx);
        });
        TerminalUI.events.singleHandler("paymentFailed", function (paymentCtx) {
            ctx = $.extend(ctx, paymentCtx, { failed: true });
            if (callback) callback(ctx);
        });

        bPayClickHandler();
    };

    var checkCurrentAmountReadyForPayment = function () {
        var ready = true;
        if (isRequiredAmountDefined) {
            ready = amountAll >= sumsInfo.RequiredSumInfo.EntireSum;
        } else {
            ready = amountAll > 0;
            var limit = operatorInstance.RestrictionsInstance;
            if (limit && limit.Min) ready = amountAll >= limit.Min;
        }
        return ready;
    };

    var initAutoPayment = function () {
        var loggingService = TerminalUI.loggingService;
        if (TerminalUI.UISettingsMap["AUTO_PAYMENT_AFTER_TIMEOUT_ENABLED"] == "1")
        {
            loggingService.info("AUTO_PAYMENT_AFTER_TIMEOUT_ENABLED is ON.");
            loggingService.info("Payment will be processed automatically during the timeout.");
            SmartClientManager.writeStateToLog("AUTO_PAYMENT_AFTER_TIMEOUT_ENABLED_INFO");

            allowDenyIdleTimeoutHandler = false;
            TerminalUI.preserveCabinetSession = true;

            TimeoutManager.Instance = new CashTimeoutManager(TimeoutManager.Instance, TerminalUI.loggingService);
            TimeoutManager.Instance.UITimeout.subscribe(
                    function (sender, asyncCallback) // asyncCallback: IAsyncCallback
                    {
                        loggingService.debug("Handle timeout: will auto payment");
                        SmartClientManager.paid = true;
                        var isCurrentAmountReadyForPayment = checkCurrentAmountReadyForPayment();
                        if (isCurrentAmountReadyForPayment)
                        {
                            loggingService.info("Processing payment automatically before the page will be navigated due to the timeout...");
                            SmartClientManager.writeStateToLog("AUTO_PAYMENT_AFTER_TIMEOUT_PROCESSING");
                            processPayment(
                                function ()
                                {
                                    loggingService.info("Payment has been processed automatically during the timeout.");
                                    SmartClientManager.writeStateToLog("AUTO_PAYMENT_AFTER_TIMEOUT_PROCESSED");
                                    asyncCallback.success();
                                });
                        }
                        else
                        {
                            loggingService.warn("Failed to process payment automatically due to the wrong sum (amount = %1, amountAll=%2)!", amount, amountAll);
                            SmartClientManager.writeStateToLog("AUTO_PAYMENT_AFTER_TIMEOUT_UNABLE_DUE_TO_AMOUNT");
                            asyncCallback.fail();
                        }
                    });
        }
    };

    // 
    // Этот кусок кода не на своем месте. Не может являться основанием закрытия купюроприемника - факт ухода со страницы.
    //
    function initCloseBillValidatorOnPreUnload()
    {
        navManager.addPreNavAsyncTask(function () {
            var self = this;
            var loggingService = TerminalUI.loggingService;
            CashReceivePage.closeBillValidator(function () {
                loggingService.debug("bill validator close nav handler");
                SmartClientManager.removeListener(payListener);
                SmartClientManager.removeListener(billValidatorListener);
                SmartClientManager.allowIdleTimeoutHandler();
                CashReceivePage.isUnloading = true;
                self.complete();
            });
        });
    };

    // 
    // Этот кусок кода не на своем месте. Не может являться основанием сохранить сдачу - факт ухода со страницы.
    //
    function initSaveChangeSumOnPreUnload()
    {
        //Save amount to change sum before page unload
        navManager.addPreNavAsyncTask(function () {
            var self = this;
            var loggingService = TerminalUI.loggingService;
            if (!isPaymentSuccessful && !CashReceivePage.preventSaveChangeSumOnPageExit)
            {
                var allowSaveBrokenMoney = TerminalUI.UISettingsMap["SAVE_MONEY_TO_CHANGESUM_ON_FAILED_PAYMENT"] == "1";
                var newChangeSum = CashReceivePage.initialChangeSum + sumFromBillValidator;
                if (!allowSaveBrokenMoney)
                {
                    if (newChangeSum > 0)
                    {
                        SmartClientManager.writeToLog("Сохранение суммы сдачи запрещено. Сумма=" + newChangeSum);
                    }

                    self.complete();
                    return;
                }

                loggingService.info("Writing the change sum that is %1 during a page is unloading...", newChangeSum);
                ChangeSumManager.Instance.pushChangeSumAsync(
                    newChangeSum,
                    function ()
                    {
                        loggingService.info("The new change sum %1 has been written successfully.", newChangeSum);
                        self.complete();
                    });
            }
            else
            {
                self.complete();
            }
        });
    };


    function initBillValidatorListeners() {
        var loggingService = TerminalUI.loggingService;

        var billValidatorActivityHandler = function () {
            ClientSidePage.layoutPage.hideDlgIdleTimeout();
        };

        var keepBtnHidden = function ($btn) {
            if (!$btn.hasClass("th-hidden")) {
                $btn.addClass("th-hidden").data("billValidatorState", "Disable");
            }
        };

        var keepBtnShown = function ($btn) {
            if ($btn.hasClass("th-hidden") && $btn.data("billValidatorState") == "Disable" && $btn.data("force-keep-hidden") !== true) {
                $btn.removeClass("th-hidden").data("billValidatorState", "Enable");
            }
        };

        var forceKeepButtonHidden = function ($btn) {
            $btn.data("force-keep-hidden", true);
            if (!$btn.hasClass("th-hidden")) {
                $btn.addClass("th-hidden");
            }
        };

        var forceKeepButtonShown = function ($btn) {
            $btn.data("force-keep-hidden", false);
            if ($btn.hasClass("th-hidden")) {
                $btn.removeClass("th-hidden");
            }
        };

        var triggerCashProcessedIfCompleted = function () {
            loggingService.debug("billValidatorBtnStateDisabled=%1 billValidatorCashProcessing=%2", billValidatorBtnStateDisabled, billValidatorCashProcessing);
            if (!billValidatorBtnStateDisabled && !billValidatorCashProcessing) {
                keepBtnShown($bPay);
                keepBtnShown($bMenu);
                keepBtnShown($bCancel);
                keepBtnShown($bPutCashToChange);

                allowPay = true;
            }
        };

        SmartClientManager.addListener({
            billValidatorCallback: function (paramName, paramValue) {
                if (CashReceivePage.billValidatorState == null || CashReceivePage.billValidatorState == "NotOperable") return;
                var $bMenu = CashReceivePage.$bMenu;
                var $bCancel = CashReceivePage.$bCancel;
                var $bPutCashToChange = CashReceivePage.$bPutCashToChange;

                var loggingService = TerminalUI.loggingService;
                loggingService.debug("billValidatorCallback: ParamName is %1 and ParamValue is %2", paramName, paramValue);

                if (paramName == "ButtonState") {
                    var logger = TerminalUI.loggingService;
                    logger.trace("%1 = %2", paramName, paramValue);
                    if (paramValue == "Disable") {
                        loggingService.debug("ButtonState Disable");
                        allowPay = false;
                        billValidatorBtnStateDisabled = true;
                        keepBtnHidden($bPay);
                        keepBtnHidden($bMenu);
                        keepBtnHidden($bCancel);
                        keepBtnHidden($bPutCashToChange);
                    } else if (paramValue == "Enable") {
                        loggingService.debug("ButtonState Enable");
                        billValidatorBtnStateDisabled = false;
                        triggerCashProcessedIfCompleted();
                    }
                }

                if (paramName == "PollDescription") {
                    if (paramValue == "Accepting") {
                        billValidatorActivityHandler();
                    }
                }
            }
        });

        billValidatorListener = new Listener({
            billValidatorValidBill: function (arg) {
                if (arg !== "True") {
                    CashReceivePage.hideDlgMaxSumExceeded();
                    DlgManager.showDlgInvalidBill($dlgInvalidBill);
                }
            },

            billValidatorSum: function (args) {

                billValidatorCashProcessing = true;

                var $bPutCashToChange = CashReceivePage.$bPutCashToChange;
                CashReceivePage.hideDlgMaxSumExceeded();
                DlgManager.hideDlgInvalidBill($dlgInvalidBill);

                if (allowDenyIdleTimeoutHandler) SmartClientManager.denyIdleTimeoutHandler();

                var sum = args.sum;
                sumFromBillValidator = sum;
                if (sum > 0) {
                    if (!billValidatorTriggerred) {
                        billValidatorTriggerred = true;
                        SmartClientManager.preventPinPadCancel();
                    }
                    if (!SmartClientManager.containsListener(payListener)) SmartClientManager.addListener(payListener);
                }

                amountAll = initialSum + sum;

                var maxRequiredSum = sumsInfo.RequiredSumInfo.IsAvailable ? requiredSum : maxLimit;
                if (amountAll >= maxRequiredSum && TerminalUI.UISettingsMap["BILL_VALIDATOR_AUTO_CLOSE_ENABLED"] == "1") {
                    if (amountAll > maxRequiredSum) {
                        if (TerminalUI.UISettingsMap["SHOW_DLG_MAX_SUM_EXCEEDED"] == "1") {
                            CashReceivePage.showDlgMaxSumExceeded();
                        }
                    }
                    CashReceivePage.closeBillValidator();
                }
                if (sumsInfo.RequiredSumInfo.IsAvailable) {
                    var diff = amountAll - requiredSum;
                    changeSum = diff > 0 ? diff : 0;
                    amountAll = diff <= 0 ? amountAll : requiredSum;
                    if (diff > 0) {
                        ChangeSumManager.Instance.updateChangeSumAsync(changeSum);
                    }
                    if (diff >= 0) {
                        CashReceivePage.hideBtnPutCashChange();
                        forceKeepButtonHidden($bPutCashToChange);
                    } else {
                        CashReceivePage.showBtnPutCashChange();
                    }
                } else {
                    if (amountAll > maxLimit) {
                        var diff = amountAll - maxLimit;
                        changeSum = diff > 0 ? diff : 0;
                        amountAll = diff <= 0 ? amountAll : maxLimit;
                        if (diff > 0) {
                            ChangeSumManager.Instance.updateChangeSumAsync(changeSum);
                        }
                        if (diff >= 0) {
                            CashReceivePage.hideBtnPutCashChange();
                            forceKeepButtonHidden($bPutCashToChange);
                        } else {
                            CashReceivePage.showBtnPutCashChange();
                        }
                    }
                }
                forceKeepButtonHidden($bCancel);
                forceKeepButtonHidden($bMenu);

                // В зависимости от суммы скрыть/показать кнопку оплаты/сдача
                var handleActionBtns = function (sumComparer) {
                    if (sumComparer() == true) {
                        CashReceivePage.hideBtnPutCashChange();
                        forceKeepButtonHidden($bPutCashToChange);
                        CashReceivePage.activatePayBtn();
                    } else {
                        CashReceivePage.showBtnPutCashChange();
                    }
                };

                loggingService.trace("Computing payment comission amount for amountAll=%1", amountAll);
                OperatorManager.computeComission(operatorInstance, amountAll, isCabinetSession, function (amountComissionReceived) {
                    loggingService.trace("Comission amount equal %1 for amountAll=%2", amountComissionReceived, amountAll);
                    amountComission = amountComissionReceived
                    if (isRequiredAmountDefined) {
                        CashReceivePage.updateCashInfoRequired(REQUIRED_AMOUNT, amountAll, currentChangeSum);
                        handleActionBtns(function () { return amountAll >= requiredEntireSum });
                        amount = requiredPaymentSum;
                    } else {
                        CashReceivePage.updateCashInfo(amountAll);

                        amount = amountAll - amountComission;
                        if (amount < 0) amount = 0;

                        handleActionBtns(function () {
                            var limit = operatorInstance.RestrictionsInstance;
                            var minLimitOk = true;
                            if (limit && limit.Min) minLimitOk = amount >= limit.Min;
                            return amount > 0 && minLimitOk;
                        });
                    }

                    billValidatorCashProcessing = false;
                    triggerCashProcessedIfCompleted();
                });

            }
        });

        SmartClientManager.addListener(billValidatorListener);
    };

    function startCashReceive(callback) {
        var billValidatorOperableCallback = function () {
            if (CashReceivePage.isUnloading !== true) {
                CashReceivePage.initBillValidator();
                CashReceivePage.openBillValidator(cashLimit);
                if (sumsInfo.RequiredSumInfo.IsAvailable) {
                    CashReceivePage.showDlgRequiredAmountInfo();
                }
            }
            if (callback) callback();
        };

        var handleBillValidatorState = TerminalUI.Config.Devices.DeviceStateHandling.HandleBillValidatorState;
        CashReceivePage.loggingService.trace("The HandleBillValidatorState property is %1.", handleBillValidatorState ? "ON" : "OFF");
        if (handleBillValidatorState) {
            var loggingService = CashReceivePage.loggingService;
            loggingService.trace("Showing the waiting msg...");
            CashReceivePage.showWaitDlg();
            loggingService.trace("The waiting msg has shown.");
            loggingService.trace("Polling the BillValidator to get state...");
            CashReceivePage.pollBillValidatorStateAsync(function (deviceState) {
                loggingService.trace("The BillValidator has polled and its state is %1.", deviceState);
                loggingService.trace("Hiding the waiting msg...");
                CashReceivePage.hideWaitDlg();
                loggingService.trace("The waiting msg has hidden.");
                if (deviceState == "Operable") {
                    loggingService.trace("Trigger the next billValidatorOperableCallback function...");
                    billValidatorOperableCallback();
                    loggingService.trace("The next billValidatorOperableCallback function has triggered...");
                } else {
                    loggingService.trace("Showing the BillValidatorNotOperable dialog...");
                    CashReceivePage.showDlgBillValidatorNotOperable();
                    loggingService.trace("The BillValidatorNotOperable dialog has shown.");
                }
            });
        } else {
            var loggingService = CashReceivePage.loggingService;
            loggingService.trace("Trigger the next billValidatorOperableCallback function...");
            billValidatorOperableCallback();
            loggingService.trace("The next billValidatorOperableCallback function has triggered...");
        }
    };

    function performBoostrapCashReceive() {
        SmartClientManager.cashReceive = CashReceivePage;
        SmartClientManager.paid = false;

        initAutoPayment();
        initCloseBillValidatorOnPreUnload();
        initSaveChangeSumOnPreUnload();
        initBillValidatorListeners();

        startCashReceive();
    };

    navManager.addPageLoadAsyncTask(function () {
        CashReceivePage.load();

        $operatorContainer = $("#divOperatorContainer");
        $transactionInfoContainer = $("#divTransactionInfo");
        $dlgMaxSumExceeded = CashReceivePage.$dlgMaxSumExceeded;
        $btnDlgMaxSumExceededOk = CashReceivePage.$btnDlgMaxSumExceededOk;
        $dlgInvalidBill = CashReceivePage.$dlgInvalidBill = $("#dlgInvalidBill");
        $btnDlgInvalidBill = CashReceivePage.$btnDlgInvalidBill = $("#btnDlgInvalidBillOk");
        $bMenu = $("#bMenu");
        $bCancel = $("#bCancel");
        $bPay = $("#bPay");
        $bPutCashToChange = $("#bPutCashToChange");

        $btnDlgInvalidBill.click(function () {
            DlgManager.hideDlg($dlgInvalidBill);
        });

        $bPay.click(bPayClickHandler);

        if (sumsInfo.IsReadyToPay) SmartClientManager.addListener(payListener);

        performBoostrapCashReceive();

        this.complete();
    });
})(window, jQuery, NavManager, TerminalUI, DlgManager, SmartClientManager, WaitMsgManager)