var ReqType13Response = (function () {
    function ReqType13Response() {
    }
    return ReqType13Response;
})();
var ReqType13StatusCodes;
(function (ReqType13StatusCodes) {
    // отсутствует
    ReqType13StatusCodes[ReqType13StatusCodes["NotFound"] = -1] = "NotFound";
    // ожидает обработки
    ReqType13StatusCodes[ReqType13StatusCodes["Waiting"] = 0] = "Waiting";
    // принят к оплате
    ReqType13StatusCodes[ReqType13StatusCodes["Accepted"] = 5] = "Accepted";
    // оплата производится
    ReqType13StatusCodes[ReqType13StatusCodes["Processing"] = 6] = "Processing";
    // выполнен
    ReqType13StatusCodes[ReqType13StatusCodes["Success"] = 7] = "Success";
    // не неполнен
    ReqType13StatusCodes[ReqType13StatusCodes["Fatal"] = 8] = "Fatal";
    // ожидает обработки
    ReqType13StatusCodes[ReqType13StatusCodes["NeedsSubmit"] = 9] = "NeedsSubmit";
})(ReqType13StatusCodes || (ReqType13StatusCodes = {}));
var ReqType13Helper = (function () {
    function ReqType13Helper() {
    }
    ReqType13Helper.ConvertStatus = function (statusCode) {
        switch (statusCode) {
            case -1 /* NotFound */:
                return "отсутствует";
            case 0 /* Waiting */:
            case 9 /* NeedsSubmit */:
                return "ожидает обработки";
            case 5 /* Accepted */:
                return "принят к оплате";
            case 6 /* Processing */:
                return "оплата производится";
            case 7 /* Success */:
                return "выполнен";
            case 8 /* Fatal */:
                return "не выполнен";
            default:
                return "состояние неизвестно. Код=" + statusCode;
        }
    };
    return ReqType13Helper;
})();
//# sourceMappingURL=ReqType13.js.map