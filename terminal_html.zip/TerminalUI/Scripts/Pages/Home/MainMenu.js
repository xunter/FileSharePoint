﻿$(function () {
    adjustTopBannerAndMainMenuHeight();
});

function adjustTopBannerAndMainMenuHeight() {
    var $pageTable = $("#pageTable"),
        $bannerTopContainer = $("#bannerTopContainer"),
        $bannerTop = $("#bannerTop"),
        $mainMenuContainer = $("#mainMenuContainer"),
        $feedbackStripContainer = $("#feedbackStripContainer"),
        $mainMenuContainerTable = $("#mainMenuContainerTable"),
        bannerTopHeight = $bannerTop.height(),
        feedbackStripHeight = $feedbackStripContainer.height(),
        pageTableHeight = $pageTable.height(),
        mainMenuContainerHeight = pageTableHeight - bannerTopHeight - feedbackStripHeight;
    $bannerTopContainer.height(bannerTopHeight);
    if (!ADJUST_MAIN_MENU_BUTTONS_CENTER) {
        $mainMenuContainer.height(mainMenuContainerHeight);
        $mainMenuContainerTable.height(mainMenuContainerHeight);
    }

    //make main menu cells lay middle
    var $mainMenuCells = $(".th-mm-item");
    $mainMenuCells.attr("valign", "middle");
};

var MainMenuPage = (function (window, $, ClientSidePage, TerminalUI) {
    var MainMenuPage = function () {
        ClientSidePage.apply(this, arguments);
        this._heartBeatInterval = null;
        this._urlHeartBeat = null;
    }

    extend(MainMenuPage, ClientSidePage, {
        init: function (settings) {
            ClientSidePage.prototype.init.apply(this, arguments);

            if (settings.hasOwnProperty("urlHeartBeat")) this._urlHeartBeat = settings.urlHeartBeat;
        },
        load: function () {
            ClientSidePage.prototype.load.apply(this, arguments);
            
            var loggingService = TerminalUI.loggingService;
            var isHeartBeatEnabled = TerminalUI.UISettingsMap["MAIN_MENU_HEARTBEAT_ENABLED"] == 1;
            loggingService.debug("The HeartBeat is %1", isHeartBeatEnabled ? "ENABLED" : "DISABLED");
            if (isHeartBeatEnabled) {
                var intervalMilliseconds = TerminalUI.UISettingsMap["MAIN_MENU_HEARTBEAT_INTERVAL"];
                loggingService.debug("Main Menu heart beat is enabled with an interval that is %1 milliseconds. Starting an interval...", intervalMilliseconds);
                this.startHeartBeatInterval(intervalMilliseconds);
            }

            var isAutoChangeSumFlushEnabled = TerminalUI.UISettingsMap["CHANGE_SUM_AUTO_FLUSH_ENABLED"] == "1";
            var logGuidChangeSum = TerminalUI.UISettingsMap["LOG_GUID_CHANGE_SUM"];
            ChangeSumManager.Instance.fetchChangeSumAsync(function (currChangeSum) {
                loggingService.trace("Current ChangeSum: %1", currChangeSum);
                if (isAutoChangeSumFlushEnabled && currChangeSum > 0) {
                    loggingService.info("Change sum auto flushing is enabled. Starting timeout interval with %1 milliseconds...", autoFlushMills);

                    var autoFlushMills = IMMEDIATELY_FLUSH_CHANGE_SUM ? 0 : TerminalUI.UISettingsMap["CHANGE_SUM_AUTO_FLUSH_TIMEOUT"];
                    setTimeout(function () {
                        if (changeSumOperator == null) {
                            SmartClientManager.writeStateErrorToLog(TerminalUI.UIMessageMap["LOG_MSG_CHANGE_SUM_PROVIDER_MISSING"].replace("#CHANGE_SUM#", currChangeSum).replace("#LOG_GUID#", logGuidChangeSum).replace("#CHANGE_SUM_AUTO_FLUSH_PROVIDER_ID#", TerminalUI.UISettingsMap["CHANGE_SUM_AUTO_FLUSH_PROVIDER_ID"]));
                            DENY_CHANGE_SUM_BANNER = false;
                            ChangeSumManager.Instance.updateChangeSumAsync(0, function () {
                                loggingService.info("The zero change sum was saved. %1", logGuidChangeSum);
                            });
                            return;
                        }

                        WaitMsgManager.show();
                        loggingService.info("Auto flushing the %1 change sum...", currChangeSum);
                        var fieldsMap = { "field100": currChangeSum };
                        var date = new Date();
                        var chequeNum = "0000";
                        var operatorId = changeSumOperator.ID;
                        var operatorName = changeSumOperator.Name;
                        var request = {
                            op: operatorName,
                            amount: currChangeSum,
                            amountAll: currChangeSum,
                            initDateTime: date,
                            chequeNum: chequeNum,
                            operatorId: operatorId,
                            fields: fieldsMap
                        };
                        loggingService.info("Sending a request of the RegisterPaymentRequest type to auto flush the %1 change sum... %2", currChangeSum, logGuidChangeSum);
                        SmartClientManager.sendOfflineRequestAsync({
                            request: request,
                            callback: function (resultCtx) {
                                var result = resultCtx.result;
                                loggingService.info("The request of the RegisterPaymentRequest type has sent. Result is " + result + ". Response data is " + resultCtx.responseData + "." + " " + logGuidChangeSum);
                                if (result == 0) {
                                    loggingService.info("The auto flushing change sum request was success. Writing the zero change sum value to the storage... %1", logGuidChangeSum);
                                    ChangeSumManager.Instance.updateChangeSumAsync(0, function () {
                                        loggingService.info("The zero change sum was saved. %1", logGuidChangeSum);
                                        WaitMsgManager.hide();
                                    });
                                } else {
                                    SmartClientManager.writeStateErrorToLog("Платеж на запись сдачи " + currChangeSum + " для оператора " + operatorId + " на дату и время " + formatDate(date, "yyyy-MM-dd HH:mm:ss") + " не выполнен. " + logGuidChangeSum);
                                    loggingService.fatal("Failed to pay due to an error response code from the Gateway was received. %1", logGuidChangeSum);
                                    WaitMsgManager.hide();
                                }
                            }
                        });
                    }, autoFlushMills);
                }
            });
        },

        startHeartBeatInterval: function (intervalMilliseconds) {
            var self = this,
                logger = TerminalUI.loggingService;
            self._heartBeatInterval = setInterval(function () {
                logger.debug("A timer interval triggerred.");
                if (self.unloading) {
                    logger.debug("The page is in unloading state and the interval will be cleared. Clearing the interval...");
                    self.clearHeartBeatInterval();
                } else {
                    var args = {
                        ClientSideTime: new Date()
                    };
                    logger.debug("Posting a heart beat request to the server with args: %1...", toJSON(args));
                    TerminalUI.ajaxService.postJSON(self._urlHeartBeat, args, function (outArgs) {
                        logger.debug("A response has come from the server with out args: %1", toJSON(outArgs));
                        if (!self.unloading) {
                            logger.debug("Handling the response...");
                            if (outArgs.RequireRefresh) {
                                logger.debug("The server requires refresh. Clearing the interval and refreshing the page...");
                                self.clearHeartBeatInterval();
                                self.refresh();
                            } else {
                                logger.debug("The server doesn't require refersh.");
                            }
                        } else {
                            logger.debug("The page is in the unloading state and the response will not be handled.");
                        }
                    });
                }
            }, intervalMilliseconds);
        },

        clearHeartBeatInterval: function () {
            if (this._heartBeatInterval != null) {
                clearInterval(this._heartBeatInterval);
            }
        }
    });

    return MainMenuPage;
})(window, jQuery, ClientSidePage, TerminalUI);