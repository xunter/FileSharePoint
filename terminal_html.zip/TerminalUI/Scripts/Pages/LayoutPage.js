﻿(function (window, $, ClientSidePage) {
    var PinPadCancelForCardManager = {
        smartClientManager: SmartClientManager,
        pinPadCancelForCardListener: {
            pinPadCancelPressed: function () {
                SmartClientManager.ejectCard();
            }
        },
        cardStateListener: {
            cardEjected: function () {
                SmartClientManager.removeListener(PinPadCancelForCardManager.pinPadCancelForCardListener);
            },
            cardRead: function () {
                this.allowToEjectCardByPressCancel = true;
            }
        },
        init: function () {
            this.smartClientManager.addListener(this.cardStateListener);
        }
    };

    LayoutPage = function () {
        ClientSidePage.apply(this, arguments);
        this._urlMainMenu = null;
        this._urlCabinetSignOut = null;
        this._urlError = null;
        this._urlPrinterError = null;
        this._isPinPadOpened = false;
        this._showWaitDlgOnNavigating = false;
        this._delayBeforeShowWaitDlgOnNavigating = 0;
        this.preventToOpenPinPad = false;
    };

    extend(LayoutPage, ClientSidePage, {
        smartClientManager: SmartClientManager,
        billValidatorAmount: 0,
        init: function (settings) {
            ClientSidePage.prototype.init.apply(this, arguments);
            if (settings.hasOwnProperty("urlMainMenu")) this._urlMainMenu = settings.urlMainMenu;
            if (settings.hasOwnProperty("urlError")) this._urlError = settings.urlError;
            if (settings.hasOwnProperty("urlCabinetSignOut")) this._urlCabinetSignOut = settings.urlCabinetSignOut;
            if (settings.hasOwnProperty("urlPrinterError")) this._urlPrinterError = settings.urlPrinterError;
            if (settings.hasOwnProperty("showShadowOnNavigating")) this._showShadowOnNavigating = settings.showShadowOnNavigating;
            if (settings.hasOwnProperty("showWaitDlgOnNavigating")) this._showWaitDlgOnNavigating = settings.showWaitDlgOnNavigating;
            if (settings.hasOwnProperty("delayBeforeShowWaitDlgOnNavigating")) this._delayBeforeShowWaitDlgOnNavigating = settings.delayBeforeShowWaitDlgOnNavigating;

            TimeoutManager.Instance = new DefaultTimeoutManager(settings.urlCabinetSignOut, TerminalUI.loggingService);
            TimeoutManager.Instance.UITimeout.subscribe(this.OnUITimeout.bind(this));
        },
        navigateToError: function (msg) {
            var urlError = this._urlError;
            if (msg) {
                urlError = passParamToURL(urlError, "msg", msg);
            } else {
                msg = "";
            }

            this.loggingService.info("Переход на страницу ошибки с клиентской части. Сообщение: \"%1\". URL: \"%2\"", msg, urlError);
            this.navigate(urlError);
        },
        navigateToPrinterError: function () {
            var urlPrinterError = this._urlPrinterError;
            this.loggingService.info("Переход на страницу ошибки принтера с клиентской части. URL: \"%1\"", urlPrinterError);
            this.navigate(urlPrinterError);
        },
        navigateToMainMenu: function () {
            var urlMainMenu = this._urlMainMenu;
            this.loggingService.info("Переход на страницу главного меню с клиентской части. URL: \"%1\"", urlMainMenu);
            this.navigate(urlMainMenu);
        },

        isCurrUrlMainMenu: function () {
            return this.getCurrUrl().toLowerCase() == this._urlMainMenu.toLowerCase();
        },

        load: function () {
            ClientSidePage.prototype.load.apply(this, arguments);

            var self = this;
            this.tryOpenPinPadSafely();
            this.tryHandleCardReaderCancel();
        },

        tryHandleCardReaderCancel: function () {
            if (DeviceManager.getInstance().isDeviceTypeSupported("CardReader") && this.isPinPadSupported()) {
                PinPadCancelForCardManager.init();
            }
        },

        isPinPadSupported: function () { return DeviceManager.getInstance().isDeviceTypeSupported("PinPad"); },

        tryOpenPinPadSafely: function () {
            var self = this;
            if (this.preventToOpenPinPad == false && this.isPinPadSupported()) {
                this.openPinPad();
                return true;
            }
            return false;
        },

        openPinPad: function () {
            var self = this;
            setTimeout(function () {
                self._isPinPadOpened = true;
                self.smartClientManager.openClearPad();
            }, 300);
        },

        closePinPad: function () {
            this.smartClientManager.closePad();
            this._isPinPadOpened = false;
        },

        tryClosePinPadSafely: function () {
            if (this._isPinPadOpened) {
                this.closePinPad();
            }
        },

        logDeviceNotSupportedStateError: function (deviceType, pageName, multiple) {
            var msg = "";
            if (multiple) {
                msg = formatMsg("Устройства \"%1\" НЕ поддерживаются!", deviceType.join(","));
            } else {
                msg = formatMsg("Устройство \"%1\" НЕ поддерживается!", deviceType);
            }

            if (pageName) {
                msg = formatMsg("Переход на страницу \"%2\" НЕДОПУСТИМ! %1", msg, deviceType)
            }
            this.smartClientManager.writeStateErrorToLog(msg);
        },

        unload: function () {
            var self = this;
            ClientSidePage.prototype.unload.apply(this, arguments);
            //this.showWaitDlg();
            var delay = FS.TerminalUI.UISettingsMap["NAVIGATING_SHOW_SMTH_DELAY_MILLISECONDS"];
            if (FS.TerminalUI.UISettingsMap["NAVIGATING_SHOW_SHADOW_ENABLED"] == 1) {
                setTimeout(function () {
                    self.showShadow();
                }, delay);
            } else if (FS.TerminalUI.UISettingsMap["NAVIGATING_SHOW_WAIT_DLG_ENABLED"] == 1) {
                setTimeout(function () {
                    self.showWaitDlg();
                }, delay);
            }
            this.tryClosePinPadSafely();
        },
        showShadow: function () {
            $("#lock").removeClass("hidden");
        },

        findDlgIdleTimeout: function () {
            var dlgIdleTimeoutClientId = TerminalUI.UISettingsMap["DLG_IDLE_TIMEOUT_CLIENT_ID"];
            var dlgIdleTimeout = DlgMsgManager.findDlg(dlgIdleTimeoutClientId);
            return dlgIdleTimeout;
        },

        showDlgIdleTimeout: function () {
            var dlgIdleTimeout = this.findDlgIdleTimeout();
            if (!dlgIdleTimeout.isShown()) {
                this.loggingService.info(TerminalUI.UIMessageMap["LOG_MSG_SHOW_DLG_IDLE_TIMEOUT"]);
                SmartClientManager.writeStateToLog("LOG_MSG_SHOW_DLG_IDLE_TIMEOUT");
                dlgIdleTimeout.show();
            }
        },

        hideDlgIdleTimeout: function () {
            var dlgIdleTimeout = this.findDlgIdleTimeout();
            if (dlgIdleTimeout.isShown()) {
                this.loggingService.info(TerminalUI.UIMessageMap["LOG_MSG_HIDE_DLG_IDLE_TIMEOUT"]);
                SmartClientManager.writeStateToLog("LOG_MSG_HIDE_DLG_IDLE_TIMEOUT");
                dlgIdleTimeout.hide();
            }
        },

        OnUITimeout: function()
        {
            SmartClientManager.writeStateToLog("LOG_MSG_START_PAGE_NAVIGATING_SCREEN_PANEL_CALLBACK");
            this.navigateToMainMenu();
        }
    });
})(window, jQuery, ClientSidePage);