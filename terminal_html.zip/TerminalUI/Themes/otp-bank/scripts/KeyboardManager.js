﻿function KeyboardManager() { 
    this._fieldManager = null;
    this._containerElement = null;
    this._case = "lowercase";
    this._special = false;
    this._language = "ru";
};

KeyboardManager.prototype = {
    init: function (settings) {
        this._fieldManager = settings.fieldManager;
        this._containerElement = settings.containerElement;
    },
    appendLetterToField: function(letter) {
        var appendingLetter = this._case == "lowercase" ? letter : letter.toString().toUpperCase();
        this._fieldManager.appendLetter(appendingLetter);
    },
    getKeyboardLettersElement: function() {
        return this._queryContainer(".th-keyboard-letters");
    },
    _queryContainer: function(query) {
        return $(query, this._containerElement);
    },
    switchCase: function () {
        var $keyboardLetters = this.getKeyboardLettersElement();
        var $btnCase = this._queryContainer(".th-keyboard-btn-action-case");
        var caseType = $keyboardLetters.hasClass("th-capital-letters") ? "uppercase" : "lowercase";
        switch (caseType) {
            case "uppercase": 
                {
                    //$btnCase.text("Заглавные");
					$btnCase.text($btnCase.data("title_upc"));
                    $keyboardLetters.removeClass("th-capital-letters");
                    this._case = "lowercase";
                }
                break;
            case "lowercase": 
                {
                    //$btnCase.text("Прописные");
					$btnCase.text($btnCase.data("title_lwc"));
                    $keyboardLetters.addClass("th-capital-letters");
                    this._case = "uppercase";
                }
                break;
            default: throw "An unrecognized case type ("+caseType+") was thrown!";
        }
    },
    switchLanguage: function () {
        var language = this._language == "ru" ? "en" : "ru";
        var $specialKB = this._queryContainer(".th-keyboard-letters-spec");
        $specialKB.addClass("th-hidden");
                            
        var $currKB = this._queryContainer(".th-keyboard-letters-"+this._language);
        $currKB.addClass("th-hidden");                            
        var $nextKB = this._queryContainer(".th-keyboard-letters-"+language);
        $nextKB.removeClass("th-hidden");
        this._language = language;
        var $bLanguage = this._queryContainer(".th-keyboard-btn-action-language");
        var languageForBtn = language == "ru" ? "en" : "ru";
        $bLanguage.text($bLanguage.data("title_"+languageForBtn));
        this._setSpecial(false);
    },

    _setSpecial: function(val) {
        this._special = val;
        var $bSpecial = this._queryContainer(".th-keyboard-btn-action-special");
        var set = val ? "letters" : "special";
        $bSpecial.text($bSpecial.data("title_"+set));
    },
    switchSpecial: function () { 
        var $specialKB = this._queryContainer(".th-keyboard-letters-spec");
        var $currKB = this._queryContainer(".th-keyboard-letters-"+this._language);
        if (!this._special) {
            $specialKB.removeClass("th-hidden");
            $currKB.addClass("th-hidden");
        } else {                            
            $currKB.removeClass("th-hidden");
            $specialKB.addClass("th-hidden");
        }
        this._setSpecial(!this._special);
    },
};