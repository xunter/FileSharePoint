﻿/// <reference path="../Utils/DlgManager.js" />

var DlgMsg = (function ($) {
    var DlgMsg = function (clientId) {
        var self = this;
        this.$dlg = $("#" + clientId);
        this.defaultHideHandler = function () {
            self.hide();
        };
        var $btnsWithDefaultCloseHandlers = this.$dlg.find("[data-use_default_click_handler=1]");
        $btnsWithDefaultCloseHandlers.data("dlg", this);
        $btnsWithDefaultCloseHandlers.click(this.defaultHideHandler);
        this._shownListeners = new Listenable();
        this._hiddenListeners = new Listenable();
    };

    $.extend(DlgMsg.prototype, {
        defaultHideHandler: function () {
            var dlg = $(this).data("dlg");
            if (dlg != null) {
                dlg.hide();
            }
        },
        getMsgText: function () {
            return this.$dlg.find(".dlg-msg-text").html();
        },
        setMsgText: function (msgText) {
            this.$dlg.find(".dlg-msg-text").html(msgText);
        },
        show: function (msg) {
            var $dlg = this.$dlg;
            if (msg) {
                this.setMsgText(msg);
                $dlg.data("show_init", false);
            }
            DlgManager.showDlg($dlg);
            this._shownListeners.notify("shown", this);
                        
            if (TerminalUI.UISettingsMap["DLG_MSG_AUTO_HEIGHT_ENABLED"] == 1 && $dlg.data("show_init") != true) {

                var innerHeight = $dlg.innerHeight();
                $dlg.height(innerHeight);

                var $inner = $dlg.find(".dlg-inner");
                var $msgContainer = $dlg.find(".dlg-msg");
                var $buttons = $dlg.find(".dlg-buttons");

                var msgHeight = $msgContainer.height();
                var buttonsHeight = $buttons.height();
                var padding = $dlg.height() - $inner.height();
                var resultHeight = msgHeight + buttonsHeight + padding;
                $inner.height(msgHeight);
                var dlgHeight = resultHeight;
                $dlg.height(dlgHeight);

                var marginTop = Math.round(dlgHeight / -2);
                $dlg.css("marginTop", marginTop);

                $dlg.data("show_init", true);
            }
        },
        hide: function () {
            DlgManager.hideDlg(this.$dlg);
            this._hiddenListeners.notify("hidden", this);
        },
        isShown: function () {
            return DlgManager.isShown(this.$dlg);
        },
        onShown: function (handler) {
            this._shownListeners.addHandler("shown", handler);
        },
        onHidden: function (handler) {
            this._hiddenListeners.addHandler("hidden", handler);
        },
        findButton: function (btnType) {
            var expr = btnType ? "[data-btn_type=" + btnType + "]" : "[data-btn_type]";
            var btn = this.$dlg.find(expr);
            return btn;
        },
        onButtonClick: function (btnType, clickHandler) {
            var $btn = this.findButton(btnType);
            $btn.data("use_default_click_handler", 0);
            $btn.unbind("click", this.defaultHideHandler);
            $btn.click(clickHandler);
        },
        triggerBtnClick: function (btnType) {
            var $btn = this.findButton(btnType);
            $btn.click();
        }
    });

    return DlgMsg;
})(jQuery);