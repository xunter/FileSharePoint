﻿/// <reference path="DlgMsg.js" />

var DlgMsgManager = (function ($, DlgMsg) {
    var DlgMsgManager = {
        _dlgs: {},
        registerDlg: function (clientId, dlg) {
            this._dlgs[clientId] = dlg;
        },
        findDlg: function (clientId) {
            if (this._dlgs.hasOwnProperty(clientId)) {
                return this._dlgs[clientId];
            } else {
                var dlgElement = document.getElementById(clientId);
                if (dlgElement != null) {
                    var dlg = new DlgMsg(clientId);                    
                    this.registerDlg(clientId, dlg);
                    return dlg;
                }
            }
            return null;
        }
    };
    return DlgMsgManager;
})(jQuery, DlgMsg);