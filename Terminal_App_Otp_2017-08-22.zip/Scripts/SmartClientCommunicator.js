﻿!function () {

    var guid = "{216896B8-0458-4B58-915B-73522B5DB077}",

    deviceAddress = {
        CardReader: "CardReader",
        PinPad: "PinPad",
        Printer: "Printer",
        FiscalPrinter: "FiscalPrinter",
        BillValidator: "BillValidator",
        BarcodeScanner: "Scanner",
        ContactlessCardReader: "ComfortableRoute"
    },

    commandCardReader = {
        Open: "Open",
        Close: "Close",
        Eject: "Eject",
        Capture: "Capture",
        Position: "Position",
        State: "State"
    },

    commandPinPad = {
        OpenCipherPad: "OpenCipherPad",
        OpenClearPad: "OpenClearPad",
        ReadPinBlock: "ReadPinBlock",
        ClosePinPad: "ClosePad",
        State: "State"
    },

    commandPrinter = {
        Print: "Print",
        State: "State"
    },

    commandFiscalPrinter = {
        Print: "Print"
    },

    commandBillValidator = {
        Open: "Open",
        Close: "Close",
        State: "State"
    },

    commandScanner = {
        Open: "Open",
        Close: "Close",
        State: "State"
    },

    commandContactlessCardReader = {
        SendData: "SendData"
    };

    function replaceAll(s, oldValue, newValue) {
        var sStr = typeof (s) != "undefined" && s != null ? s.toString() : "";
        while (sStr.indexOf(oldValue) != -1) {
            sStr = sStr.replace(oldValue, newValue);
        }
        return sStr;
    };

    function encodeData(s) {
        s = replaceAll(s, "=", "%3D");
        s = replaceAll(s, ";", "%3B");
        return s;
    }

    function encodePrintData(s) {
        s = replaceAll(s, "=", "%u003D");
        s = replaceAll(s, ";", "%u003B");
        s = replaceAll(s, "\n", "%u000A");
        s = replaceAll(s, "\r", "%u000D");
        return s;
    }

    function decodeData(s) {
        s = replaceAll(s, "%3D", "=");
        s = replaceAll(s, "%3B", ";");
        return s;
    }

    function decodePrintData(s) {
        s = replaceAll(s, "%u003D", "=");
        s = replaceAll(s, "%u003B", ";");
        s = replaceAll(s, "%u000A", "\n");
        s = replaceAll(s, "%u000D", "\r");
        return s;
    }

    function writeToStatusBar(text) {
        if (typeof terminalExplorer !== 'undefined')
        {
            terminalExplorer.executeCommand(guid + text);
        }
    }

    function sendData(address, command, data) {
        data = data || "";
        data = "CommandType=SendData;Address=" + address + ";Command=" + command + ";Data=" + encodeData(data) + ";";
        writeToStatusBar(data);
    }

    function sendToBuffer(text) {
        text = "CommandType=DataBuffer;" + text;
        writeToStatusBar(text);
    }

    smartClientCommunicator = {

        openCardReader: function () {
            sendData(deviceAddress.CardReader, commandCardReader.Open);
        },

        closeCardReader: function () {
            sendData(deviceAddress.CardReader, commandCardReader.Close);
        },

        cardEject: function () {
            sendData(deviceAddress.CardReader, commandCardReader.Eject);
        },

        cardCapture: function () {
            sendData(deviceAddress.CardReader, commandCardReader.Capture);
        },

        stateCardReader: function () {
            sendData(deviceAddress.CardReader, commandCardReader.State);
        },

        stateCardPosition: function () {
            sendData(deviceAddress.CardReader, commandCardReader.Position);
        },

        openCipherPad: function (processingId, cardNumber, pinLength) {
            var data = "ProcessingId=" + processingId + ";CardNumber=" + cardNumber + ";PinLength=" + pinLength + ";";
            sendData(deviceAddress.PinPad, commandPinPad.OpenCipherPad, data);
        },

        openClearPad: function () {
            sendData(deviceAddress.PinPad, commandPinPad.OpenClearPad);
        },

        readPinBlock: function () {
            sendData(deviceAddress.PinPad, commandPinPad.ReadPinBlock);
        },

        statePinPad: function () {
            sendData(deviceAddress.PinPad, commandPinPad.State);
        },

        closePinPad: function () {
            sendData(deviceAddress.PinPad, commandPinPad.ClosePinPad);
        },

        printToPrinter: function (text) {
            var data = "PrinterText=" + encodePrintData(text) + ";";
            sendData(deviceAddress.Printer, commandPrinter.Print, data);
        },

        statePrinter: function () {
            sendData(deviceAddress.Printer, commandPrinter.State);
        },

        printToFiscalPrinter: function (text, sum, isCash) {
            var data = "PrinterText=" + encodePrintData(text) + ";Sum=" + sum + ";IsCash=" + isCash + ";";
            sendData(deviceAddress.FiscalPrinter, commandPrinter.Print, data);
        },

        openBillValidator: function (session, maxSum) {
            var maxSum = (typeof (maxSum) === "undefined" || isNaN(maxSum)) ? -1 : maxSum;
            sendData(deviceAddress.BillValidator, commandBillValidator.Open, "Session=" + session + ";MaxSum=" + maxSum + ";");
        },

        closeBillValidator: function (session) {
            sendData(deviceAddress.BillValidator, commandBillValidator.Close, "Session=" + session + ";");
        },

        stateBillValidator: function () {
            sendData(deviceAddress.BillValidator, commandBillValidator.State);
        },

        openScanner: function () {
            sendData(deviceAddress.BarcodeScanner, commandScanner.Open);
        },

        closeScanner: function () {
            sendData(deviceAddress.BarcodeScanner, commandScanner.Close);
        },

        stateScanner: function () {
            sendData(deviceAddress.BarcodeScanner, commandScanner.State);
        },

        sendDataToContactlessCardReader: function (data) {
            sendData(deviceAddress.ContactlessCardReader, commandContactlessCardReader.SendData, data);
        },

        clearBuffer: function () {
            var data = "DataBufferFunction=Clear;";
            sendToBuffer(data);
        },

        setFieldBuffer: function (name, value) {
            var data = "DataBufferFunction=SetField;DataBufferFieldName=" + name + ";DataBufferFieldValue=" + encodeData(value) + ";";
            sendToBuffer(data);
        },

        getFieldBuffer: function (name) {
            var data = "DataBufferFunction=GetField;DataBufferFieldName=" + name + ";";
            sendToBuffer(data);
        },

        getBuffer: function () {
            var data = "DataBufferFunction=GetBuffer;";
            sendToBuffer(data);
        },

        sendToStatusBar: function (text) {
            writeToStatusBar(text);
        },

        callGatewayRequest: function () {
            var data = "CommandType=GatewayRequest;";
            writeToStatusBar(data);
        },

        callOperationRequest: function () {
            var data = "CommandType=OperationRequest;";
            writeToStatusBar(data);
        },

        startTerminalManager: function (password) {
            var data = "CommandType=StartTerminalManagerApplication;Password=" + encodeData(password) + ";";
            writeToStatusBar(data);
        },

        readInterfaceStatus: function () {
            var data = "CommandType=ReadInterfaceStatus;";
            writeToStatusBar(data);
        },

        writeToLog: function (text) {
            var data = "CommandType=WriteToLog;LogData=" + encodeData(text) + ";";
            writeToStatusBar(data);
        },

        writeStateToLog: function (text) {
            var data = "CommandType=WriteStateToLog;LogData=" + encodeData(text) + ";";
            writeToStatusBar(data);
        },

        writeErrorToLog: function (text) {
            var data = "CommandType=WriteErrorToLog;LogData=" + encodeData(text) + ";";
            writeToStatusBar(data);
        },

        writeStateErrorToLog: function (text) {
            var data = "CommandType=WriteStateErrorToLog;LogData=" + encodeData(text) + ";";
            writeToStatusBar(data);
        },

        writeSessionToLog: function (session) {
            var data = "CommandType=WriteSessionToLog;LogData=" + encodeData(session) + ";";
            writeToStatusBar(data);
        },

        writeVersionToLog: function (text) {
            var data = "CommandType=WriteVersionToLog;LogData=" + encodeData(text) + ";";
            writeToStatusBar(data);
        }
    }

} ();