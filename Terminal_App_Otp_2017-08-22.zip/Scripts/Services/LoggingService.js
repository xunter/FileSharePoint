﻿(function (window) {
    function populateArrayToAnother(src, dest) {
        for (var i = 0; i < src.length; i++) dest.push(src[i]);
    }

    function formatMsg(format, args) {
        var parameters = Array.prototype.slice.call(arguments, 1),
            resultMsg = format;
        for (var i = 0; i < parameters.length; i++) resultMsg = resultMsg.replace(new RegExp("%" + (i + 1), "g"), parameters[i]);
        return resultMsg;
    };

    var LoggingService = window.LoggingService = function () {
        this._useQueue = false;
        this._queue = [];
        this._listeners = [];
        var self = this;
        if (this._useQueue) {
            var workingIntervalHandler = function () {
                return self._workingIntervalHandler.apply(self, arguments);
            };
            this._workingInterval = window.setInterval(workingIntervalHandler, 100);
        }
    };
    LoggingService.prototype = {

        checkLevelAvailable: function (level) {
            var allStr = TerminalUI.UISettingsMap["CLIENTSIDE_LOGGER_LEVEL"];
            var allArr = allStr.split(";");
            for (var i = 0; i < allArr.length; i++) {
                if (allArr[i] == level) {
                    return true;
                }
            }
            return false;
        },

        _triggerLogMethod: function (log, logEntry) {
            var logFunc = null;
            var level = logEntry.type;
            var levelAvailable = this.checkLevelAvailable(level);
            if (!levelAvailable && level != "log") {
                return false;
            }
            if (typeof (log[logEntry.type]) == "function") {
                logFunc = function () {
                    log[logEntry.type](logEntry);
                };
            } else if (typeof (log["log"]) == "function") {
                logFunc = function () {
                    log.log(logEntry);
                };
            } else {
                logFunc = function () { };
            }
            try {
                logFunc();
            } catch (e) {
            }
        },

        _workingIntervalHandler: function () {
            var self = this;
            var queue = this._queue;
            if (!queue.length) {
                return;
            }

            var listeners = this._listeners.slice();

            while (queue.length) {
                var queueLen = queue.length;
                var entry = queue[0];

                for (var i = 0; i < listeners.length; i++) {
                    var currListener = listeners[i];
                    self._triggerLogMethod(currListener, entry);
                }
                queue.splice(0, 1);
            }
        },

        addListener: function (listener) {
            this._listeners.push(listener);
        },

        _triggerLoggingMethod: function (type, arguments) {
            var newArgs = [type];
            populateArrayToAnother(arguments, newArgs);
            this.logGeneric.apply(this, newArgs);
        },

        fatal: function (msg) {
            this._triggerLoggingMethod("fatal", arguments);
        },

        error: function (msg) {
            this._triggerLoggingMethod("error", arguments);
        },

        warn: function (msg) {
            this._triggerLoggingMethod("warn", arguments);
        },

        info: function (msg) {
            this._triggerLoggingMethod("info", arguments);
        },

        trace: function (msg) {
            this._triggerLoggingMethod("trace", arguments);
        },

        debug: function (msg) {
            this._triggerLoggingMethod("debug", arguments);
        },

        logGeneric: function (type, msg) {
            var timestamp = new Date();
            var formattedMsg = formatMsg.apply(null, Array.prototype.slice.call(arguments, 1));
            var useQueue = this._useQueue;

            var logEntry = { type: type, timestamp: timestamp, t: timestamp.getTime(), msg: formattedMsg };
            if (useQueue) {
                this._queue.push(logEntry);
            } else {
                var listeners = this._listeners.slice();
                for (var i = 0; i < listeners.length; i++) {
                    var listener = listeners[i];
                    this._triggerLogMethod(listener, logEntry);
                }
            }
        },

        log: function (msg) {
            this._triggerLoggingMethod("trace", arguments);
        }
    };
})(window);