﻿function AjaxService() { };
AjaxService.prototype = {
    postJSON: function () { },
    postXML: function(url, xml, callback) {},
    get: function (url, callback) { }
};

function JQueryAjaxService() {
    AjaxService.apply(this, arguments);
};

extend(JQueryAjaxService, AjaxService, {
    getBaseJQAjaxSettings: function () {
        var self = this;
        return {
            timeout: 5 * 60 * 1000,
            error: function (xhr, status, errorThrown) {
                if (status == "timeout") {
                    self.triggerTimeout();
                }
                self.triggerError(xhr, status, errorThrown);
            }
        };
    },

    createJQAjaxSettings: function (overrides) {
        var jqAjaxSettings = $.extend(this.getBaseJQAjaxSettings(), overrides);
        return jqAjaxSettings;
    },

    postJSON: function (url, data, callback, errorHandler) {
        var self = this;
        dataToPost = toJSON(data);
        var jqAjaxSettings = this.createJQAjaxSettings({
            type: "POST",
            url: url,
            contentType: "application/json",
            data: dataToPost,
            error: function (xhr, status, errorThrown) {
                var errorHandlerContext = { handled: false };
                if (typeof (errorHandler) != "undefined") errorHandler(xhr, status, errorThrown, errorHandlerContext);
                if (!errorHandlerContext.handled) {
                    self.triggerError(xhr, status, errorThrown);
                }
            }
        });
        $.ajax(jqAjaxSettings).success(function (result) {
            if (typeof (callback) != "undefined") callback(result);
        });
    },
    postXML: function (url, xml, callback) {
        var self = this;
        var ajaxSettings = this.createJQAjaxSettings({
            type: "POST",
            url: url,
            contentType: "text/xml",
            data: xml
        });
        $.ajax(ajaxSettings).success(function (result) {
            if (typeof (callback) != "undefined") callback(result);
        });
    },
    get: function (url, callback, errorHandler) {
        var self = this;
        var ajaxSettings = this.createJQAjaxSettings({
            type: "GET",
            url: url,
            error: function (xhr, status, errorThrown) {
                var errorHandlerContext = { handled: false };
                if (typeof (errorHandler) != "undefined") errorHandler(xhr, status, errorThrown, errorHandlerContext);
                if (!errorHandlerContext.handled) {
                    self.triggerError(xhr, status, errorThrown);
                }
            }
        });
        var gotResourceSync = null;
        $.ajax(ajaxSettings).success(function (gotResource) {
            if (ajaxSettings.async !== false) {
                callback(gotResource);
            } else {
                gotResourceSync = gotResource;
            }
        });
        if (ajaxSettings.async == false) {
            callback(gotResourceSync);
        }
    },
    triggerError: function (xhr, message, errorThrown) {
        if (this.onerror != null) this.onerror(xhr, msg);
    },
    onerror: null,

    triggerTimeout: function () {
        if (this.ontimeout) this.ontimeout();
    },

    ontimeout: null
});

function JQAjaxSynchronousServiceWrapper(jqAjaxService) {
    this.originalJQAjaxService = jqAjaxService;
};

extend(JQAjaxSynchronousServiceWrapper, JQueryAjaxService, {
    getBaseJQAjaxSettings: function () {
        return { async: false };
    },
    postJSON: function (url, data, callback, errorHandler) {
        dataToPost = toJSON(data);
        var jqAjaxSettings = this.createJQAjaxSettings({
            type: "POST",
            url: url,
            contentType: "application/json",
            data: dataToPost
        });
        var ajaxResult = null;
        $.ajax(jqAjaxSettings).success(function (result) {
            ajaxResult = result;
        });
        if (typeof (callback) != "undefined") callback(ajaxResult);
    },
    postXML: function (url, xml, callback) {
        var self = this;
        var ajaxSettings = this.createJQAjaxSettings({
            type: "POST",
            url: url,
            contentType: "text/xml",
            data: xml
        });
        var ajaxResult = null;
        $.ajax(ajaxSettings).success(function (result) {
            ajaxResult = result;
        }).error(function (xhr, status) {
            self.triggerError(xhr, status);
        });
        if (typeof (callback) != "undefined") callback(ajaxResult);
    },
    get: function (url, callback, error) {
        var self = this;
        var ajaxSettings = this.createJQAjaxSettings({
            type: "GET",
            url: url
        });
        var ajaxResult = null;
        $.ajax(ajaxSettings).success(function (gotResource) {
            ajaxResult = gotResource;
        }).error(function (xhr, status) {
            self.triggerError(xhr, status);
        });
        callback(ajaxResult);
    },
    triggerError: function () {
        this.originalJQAjaxService.triggerError.apply(this.originalJQAjaxService, arguments);
    }
});