﻿/// <reference path="Utils/DlgManager.js" />

var WaitMsgManager = {
    initialized: false,
    init: function (settings) {
        if (this.initialized) {
            return;
        } else {
            this.initialized = true;
        }
        var settings = settings || {};
        this.lock = true;
        if (settings.lock) {
            this.lock = settings.lock;
        }

        if (this.lock) {
            this.$lockScreen = $("#lock");
        }
        this.$dlgWait = $("#dlgWait");
    },
    $tbFocusedArr: null,
    showLock: function () {
        DlgManager.showLock();
    },
    hideLock: function () {
        DlgManager.hideLock();
    },
    show: function () {
        /*if (this.lock) {
        this.showLock();
        }*/
        var currPage = ClientSidePage.getCurrent();
        if (currPage != null) {
            currPage.setBusy();
        }
        var $tbFocusedArr = this.$tbFocusedArr = $("input[type=text]").filter(":focus");
        $tbFocusedArr.blur();
        DlgManager.showDlg(this.$dlgWait);
    },
    hide: function () {
        /*if (this.lock) {
        this.hideLock();
        }*/
        var currPage = ClientSidePage.getCurrent();
        if (currPage != null) {
            currPage.unsetBusy();
        }
        if (this.$tbFocusedArr != null) {
            this.$tbFocusedArr.focus();
            this.$tbFocusedArr = null;
        }
        DlgManager.hideDlg(this.$dlgWait);
    }
};