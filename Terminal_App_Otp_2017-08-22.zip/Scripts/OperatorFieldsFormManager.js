﻿var OperatorFieldsFormManager = {
    actionNameToPost: null,
    formElementId: null,
    operatorId: null,
    getFormElement: function () { return document.getElementById(this.formElementId); },
    getFieldElementByFieldId: function (fieldId) { return this.getFieldElement("field" + fieldId) },
    getFieldElement: function (fieldElementId) { return document.getElementById(fieldElementId); },
    getFieldValue: function (fieldElementId) {
        var el = this.getFieldElement(fieldElementId);
        if (el) return el.value;
        return null;
    },
    navigate: function () {
        var self = this;
        var navManager = NavManager.getInstance();
        if (navManager._navigating === true) {
            TerminalUI.loggingService.debug("Deny OperatorFieldsFormManager.navigate navigating when page is already navigating.");
            return;
        }
        
        if (navManager._pageLoaded !== true) {
            TerminalUI.loggingService.debug("Deny OperatorFieldsFormManager.navigate navigating before page is loaded.");
            return;
        }
        navManager._navigating = true;
        navManager.triggerNavigationHandlersAsync(function () {
            navManager._navigating = false;
            try {
                self.getFormElement().submit();
            } catch (e) {
            }
        });
    },
    setFieldValue: function (id, value) {
        var fieldElementId = "field" + id;
        var fieldValue = value;
        this.setFieldElement(fieldElementId, fieldValue);
    },
    setFieldElement: function (fieldElementId, fieldValue) {
        var fieldElement = this.getFieldElement(fieldElementId);
        if (fieldElement === null) fieldElement = this.createNewFieldElement(fieldElementId, fieldValue);
        fieldElement.value = fieldValue;
    },
    createNewFieldElement: function (fieldId, initialValue) {
        var newFieldElement = document.createElement("input");
        newFieldElement.setAttribute("type", "hidden");
        newFieldElement.setAttribute("name", fieldId);
        newFieldElement.setAttribute("id", fieldId);
        var formElement = this.getFormElement();
        formElement.appendChild(newFieldElement);
        return newFieldElement;
    },
    getActionUrl: function () {
        var formElement = this.getFormElement();
        return formElement.getAttribute("action");
    },
    setActionUrl: function (url) {
        var formElement = this.getFormElement();
        formElement.setAttribute("action", url);
    },
    setOperatorIdToNavigate: function (operatorId) {
        var formElement = this.getFormElement();
        var formUrl = formElement.getAttribute("action");
        var re = new RegExp("(.+\/)(\\d+)(.*$)");
        var urlMatchesOperator = formUrl.replace(re, "$1" + operatorId + "$3");
        formElement.setAttribute("action", urlMatchesOperator);
    },
    getFieldsMap: function () {
        var formElement = this.getFormElement(),
            fieldsMap = {},
            formElements = formElement.elements,
            i = 0;
        for (; i < formElements.length; i++) {
            var fieldElement = formElements[i];
            fieldsMap[fieldElement.id] = fieldElement.value;
        }
        return fieldsMap;
    }
};