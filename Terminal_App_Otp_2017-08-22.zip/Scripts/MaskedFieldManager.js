﻿function MaskedFieldManager() {
    FieldManager.apply(this, arguments);
    this._mask = null;
    this._placeHolder = MaskedFieldManager.placeholder;
};

MaskedFieldManager.placeholder = "*";

extend(MaskedFieldManager, FieldManager, {

    //getREPlaceholder: function () { return new RegExp("[\\" + this._placeHolder + "]", "g"); },

    _appendMask: function () {
        var self = this;
        var mask = this.getMask();
        var placeHolder = this._placeHolder;
        //var maskForJQ = mask.replace(this.reSearchPlaceholder, "9");
        //this.$tb.mask(maskForJQ, { placeholder: placeHolder, clearEmpty: false, completed: function () { self.triggerComplete(); } });
        this._pos = getCursorPos(this._tb);
    },

    formatValueForView: function (val) {
        var mask = this.getMask();
        var placeHolder = this._placeHolder;
        var str = "",
            i = 0,
            chrCounter = 0;
        for (; i < mask.length; i++) {
            var currMaskChar = mask.charAt(i);
            if (currMaskChar == placeHolder) {
                var currChr = val.charAt(chrCounter++);
                if (!currChr) currChr = placeHolder;
                str += currChr;
                //if (chrCounter === val.length) break;
            } else {
                str += currMaskChar;
            }
        }
        return str;
    },

    reSearchPlaceholder: new RegExp("[" + MaskedFieldManager.placeholder + "]{1}"),
    reExceptPlaceholder: new RegExp("[^" + MaskedFieldManager.placeholder + "]", "g"),

    getFieldLengthWithoutMask: function () {
        return this.getMask().replace(this.reExceptPlaceholder, "").length;
    },

    appendLetter: function (letter) {
        var requiredLength = this.getFieldLengthWithoutMask();
        var currValue = this.getFieldValue();
        if (currValue.length >= requiredLength) return;
        var newValue = currValue.toString() + letter.toString();
        this.setFieldValue(newValue);
        if (this._pos < this.getMask().length) {
            this.updateCaretPos();
        }
    },

    getMask: function () {
        return this._mask;
    },

    clear: function () {
        var newVieldValue = "";
        this.setFieldValue(newVieldValue);
        this.clearAfter();
        this.fieldChanged(newVieldValue);
    },

    removeLastLetter: function () {
        var currValue = this.getFieldValue();
        if (!currValue.length) return;
        var newValue = currValue.substr(0, currValue.length - 1);
        this.setFieldValue(newValue);
        this.updateCaretPos();
    },

    isComplete: function (currValueParam) {
        var currValue = currValueParam ? currValueParam : this.getFieldValue();
        return currValue.length === this.getFieldLengthWithoutMask();
    },

    setViewFieldValue: function (newValue) {
        var valueForView = this.formatValueForView(newValue);
        FieldManager.prototype.setViewFieldValue.call(this, valueForView);
    },

    getMasklessValue: function (val) {
        val = typeof (val) != "undefined" ? val : this.getFieldValue();
        var mask = this.getMask(),
            placeHolder = this._placeHolder,
            maskLessValue = "",
            i = 0;

        for (; i < val.length; i++) {
            var currChar = val.charAt(i),
                    maskChar = mask.charAt(i);
            if (maskChar == placeHolder && currChar != placeHolder) maskLessValue += currChar;
        }
        return maskLessValue;
    },

    fieldChanged: function (newValue) {
        //if (this._fieldElement == null) return;
        var maskLessValue = this.getMasklessValue(newValue);

        //this.setHiddenFieldValue(maskLessValue);
        this.triggerValueChanged(maskLessValue);
    },

    updateCaretPos: function () {
        this._pos = this.getCursorPosForMask();
        FieldManager.prototype.updateCaretPos.call(this);
    },

    getCursorPosForMask: function () {
        var fieldViewValue = this.getViewFieldValue();
        var newCursorPos = fieldViewValue.search(this.reSearchPlaceholder);
        return newCursorPos == -1 ? fieldViewValue.length : newCursorPos;
    },

    init: function (settings) {
        var settings = typeof (settings) == "undefined" ? {} : settings;
        this.initBase(settings);
        this.initMask(settings);
        this.processFieldElement();
        this.focusTextBox();
    },

    initMask: function (settings) {
        if (settings.hasOwnProperty("mask")) this._mask = settings.mask;
        this._appendMask();
    },

    preProcessFieldValue: function (fieldValue) {
        var preProcessedValueByBaseClass = FieldManager.prototype.preProcessFieldValue.apply(this, arguments);
        var processedValue = preProcessedValueByBaseClass;
        var maxLengthForMask = this.getFieldLengthWithoutMask();
        if (processedValue.length > maxLengthForMask) {
            processedValue = substr(processedValue, 0, maxLengthForMask);
        }
        return processedValue;
    }
});