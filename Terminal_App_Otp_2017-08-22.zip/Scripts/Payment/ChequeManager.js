﻿/// <reference path="../Services/AjaxService.js" />
/// <reference path="../underscore-1.4.4.js" />
/// <reference path="../jquery-1.9.0.min.js" />
/// <reference path="../FieldsUtil.js" />

function ChequeManager(ajaxService, loggingService, urls) {    
    this._urlFetchNextChequeNum = urls.urlFetchNextChequeNum;
    this._urlFetchReceipt = urls.urlFetchReceipt;
    this._urlFetchReceiptDefault = urls.urlFetchReceiptDefault;
    this._urlVerifyReceiptTemplateExistsForOperator = urls.urlVerifyReceiptTemplateExistsForOperator;
    this._urlFetchPaymentErrorReceipt = urls.urlFetchPaymentErrorReceipt;
    this._urlVerifyPaymentErrorTemplateExists = urls.urlVerifyPaymentErrorTemplateExists;
    this._urlRenderStatusReceipt = urls.hasOwnProperty("urlRenderStatusReceipt") ? urls.urlRenderStatusReceipt : null;
    this._ajaxService = ajaxService;
    this._loggingService = loggingService;
};

ChequeManager.prototype = {
    currentChequeNum: null,
    getFieldsMapForTransfering: function (fieldMap) {
        return FieldsUtil.serializeFieldsMapToTransfer(fieldMap);
    },

    fetchNextChequeNumAsync: function (callback)
    {
        var self = this;
        self._loggingService.trace('Запрос номера чека c сервера. Url=' + this._urlFetchNextChequeNum);
        var triggerCallback = function (formattedChequeNum)
        {
            if (callback)
            {
                callback(formattedChequeNum);
            }
        };
        this._ajaxService.postJSON(
            this._urlFetchNextChequeNum,
            {},
            function (nextChequeNum)
            {
                self._loggingService.trace('Запрос номера чека успешен. Номер=' + nextChequeNum);
                var formattedChequeNum = formatNumber(nextChequeNum, 4);
                self.currentChequeNum = formattedChequeNum;
                triggerCallback(formattedChequeNum);
            },
            function ()
            {
                self._loggingService.fatal("Failed to read the next cheque num!");
                triggerCallback({
                    error: true,
                    error_msg: "Failed to read the next cheque num!"
                });
            });
    },
    verifyReceiptTemplateExistsForOperatorAsync: function (callback) {
        var triggerCallback = function (ctx) {
            if (callback) {
                callback(ctx);
            }
        },

        triggerSuccess = function (exists) {
            triggerCallback({
                error: null,
                errorType: null,
                exists: exists
            });
        },
        triggerFail = function (error, errorType) {
            triggerCallback({
                error: error,
                errorType: errorType
            });
        };
        $.ajax({
            type: "GET",
            url: this._urlVerifyReceiptTemplateExistsForOperator,
            cache: false,
            success: function (exists) {
                triggerSuccess(exists);
            },
            error: function (jqXhr) {
                triggerFail(jqXhr, "ajax");
            }
        });
    },
    fetchReceiptForUrlAsync: function (url, receiptContext) {
        var self = this,
            sum = receiptContext.sum,
            sumToPay = receiptContext.sumToPay,
            comissionSum = receiptContext.comissionSum,
            operatorId = receiptContext.operatorId,
            fieldMap = receiptContext.fieldMap,
            chequeNum = receiptContext.chequeNum,
            timestampDate = receiptContext.timestampDate,
            callback = receiptContext.callback,
            errorHandler = receiptContext.errorHandler;
        var sumAsText = sum.toFixed(2);
        var sumToPayAsText = sumToPay.toFixed(2);
        var comissionSumAsText = comissionSum.toFixed(2);

        var checkInfo = {
            OperatorId: operatorId,
            Sum: sumAsText,
            SumToPay: sumToPayAsText,
            ComissionSum: comissionSumAsText,
            Timestamp: timestampDate,
            ChequeNum: chequeNum
        };

        var fieldsMapToTransfer = this.getFieldsMapForTransfering(fieldMap);
        checkInfo.FieldsMapFromJSON = fieldsMapToTransfer;

        var postObj = {
            dataContext: checkInfo
        };

        if (typeof (CARD_AVAILABLE) != "undefined" && CARD_AVAILABLE == true) {
            var currCardTx = CardManager.getCurrentTransaction();
            var currCardTxDictionaryEntries = mapObjectToDictionaryEntries(currCardTx);
            postObj.cardTransaction = currCardTxDictionaryEntries;
        }

        this._ajaxService.postJSON(url, postObj, function (receipt) {
            self._currentReceipt = receipt;
            if (callback) callback(receipt);
        }, errorHandler);
    },

    // если в метод передан не объект аргументов, а аргументы как параметры, то этот метод обернет аргементы в объект аргументов (для поддержки)
    wrapAgruments: function (args, receiptContext) {
        var argNames = ["operatorId", "fieldMap", "sum", "sumToPay", "comissionSum", "timestampDate", "chequeNum", "callback", "errorHandler"];
        if (args.length > 1) {
            receiptContext = _.object(argNames, args);
        }
        return receiptContext;
    },
    fetchReceiptAsync: function (receiptContext) {
        receiptContext = this.wrapAgruments(arguments, receiptContext);
        this.fetchReceiptForUrlAsync(this._urlFetchReceipt, receiptContext);
    },
    fetchReceiptDefaultAsync: function (receiptContext /*operatorId, fieldMap, sum, sumToPay, comissionSum, timestampDate, chequeNum, callback, errorHandler*/) {
        receiptContext = this.wrapAgruments(arguments, receiptContext);
        this.fetchReceiptForUrlAsync(this._urlFetchReceiptDefault, receiptContext);
    },
    verifyPaymentErrorTemplateExists: function (callback) {
        var triggerCallback = function (args) {
            if (callback) callback(args);
        };
        this._ajaxService.postJSON(this._urlVerifyPaymentErrorTemplateExists, {}, function (exists) {
            triggerCallback({ error: false, exists: exists });
        },
        function (errorCtx) {
            errorCtx.errorHandled = true;
            triggerCallback({ error: true });
        });
    },
    fetchPaymentErrorReceiptForReceiptNum: function (operatorId, receiptNum, timestamp, amountAll, callback) {
        var triggerCallback = function (args) {
            if (callback) callback(args);
        };

        var postObj = {
            id: operatorId, chequeNum: receiptNum, amountAll: amountAll, timestamp: timestamp
        };

        if (typeof (CARD_AVAILABLE) != "undefined" && CARD_AVAILABLE == true) {
            postObj.cardTransaction = mapObjectToDictionaryEntries(CardManager.getCurrentTransaction());
        }

        this._ajaxService.postJSON(this._urlFetchPaymentErrorReceipt, postObj, function (receiptText) {
            triggerCallback({ error: false, receiptText: receiptText });
        },
        function (errorCtx) {
            errorCtx.errorHandled = true;
            triggerCallback({ error: true });
        });
    },

    fetchPaymentErrorReceipt: function (operatorId, timestamp, amountAll, callback) {
        var self = this;
        var triggerCallback = function (args) {
            if (callback) callback(args);
        };
        this.verifyPaymentErrorTemplateExists(function (verifyArgs) {
            if (verifyArgs.error) {
                triggerCallback(verifyArgs);
                return;
            }

            self.fetchNextChequeNumAsync(function (nextReceiptNum) {
                if (!nextReceiptNum) {
                    triggerCallback({ error: true });
                    return;
                }

                self.fetchPaymentErrorReceiptForReceiptNum(operatorId, nextReceiptNum, timestamp, amountAll, function (fetchReceiptArgs) {
                    if (fetchReceiptArgs.error) {
                        triggerCallback(fetchReceiptArgs);
                        return;
                    }

                    triggerCallback(fetchReceiptArgs);
                });
            });
        });
    },

    // Возвращает чек по шаблону "card-payment-status.chq"
    // Используется при оплате картой, в случае потери ответа процессинга
    RenderPaymentStatusReceiptAsync: function (operatorId, timestamp, amountAll, statusText, receiptNum, callback)
    {
        if (this._urlRenderStatusReceipt == null)
        {
            throw "Invalid class initialization. urlRenderStatusReceipt is not assigned any value";
        }

        $.ajax(this._urlRenderStatusReceipt,
            {
                type: 'POST',
                data: JSON.stringify({
                    OperatorId: operatorId,
                    ChequeNum: receiptNum,
                    AmountAll: amountAll,
                    Timestamp: timestamp,
                    Status: statusText
                }),
                contentType: 'application/json',
                context: this
            })
        .then(function(e)
            {
                callback({
                    Error: false,
                    ReceiptText: e
            });
        });
    }
};