﻿var FetchPaymentReceiptLogic = function (chequeManager) {
    this.chequeManager = chequeManager;
};

FetchPaymentReceiptLogic.prototype.fetchReceiptAsync = function (operatorInstance, fieldsMap, sum, sumToPay, comissionSum, printDate, receiptNum, callback) {
    var operatorId = operatorInstance.ID,
                    loggingService = TerminalUI.loggingService,
                    smartClientManager = SmartClientManager,
                    receiptManager = this.chequeManager,
                    triggerSuccess = function (receiptText) {
                        callback({ error: false, receiptText: receiptText })
                    },
                    triggerFail = function () {
                        callback({ error: true })
                    };
    var customTemplate = operatorInstance.ChequeInstance != null ? operatorInstance.ChequeInstance.TemplateName : null,
                isCustomTemplate = customTemplate != null,
                renderReceiptAsync = function () {
                    receiptManager.fetchReceiptAsync(operatorId, fieldsMap, sum, sumToPay, comissionSum, printDate, receiptNum, function (receiptText) {
                        triggerSuccess(receiptText);
                    },
                    function (xhr, status, errorThrown, ctx) {
                        triggerFail();
                        loggingService.error("Не удалось сформировать чек " + receiptNum + " на веб-сервере для оператора " + operatorId + "!");
                        ctx.handled = true;
                    });
                },
                renderReceiptDefaultAsync = function () {
                    receiptManager.fetchReceiptDefaultAsync(operatorId, fieldsMap, sum, sumToPay, comissionSum, printDate, receiptNum, function (receiptText) {
                        triggerSuccess(receiptText);
                    },
                    function (xhr, status, errorThrown, ctx) {
                        triggerFail();
                        loggingService.error("Не удалось сформировать чек " + receiptNum + " со стандартным шаблоном на веб-сервере для оператора " + operatorId + "!");
                        ctx.handled = true;
                    });
                };

    if (isCustomTemplate) {
        receiptManager.verifyReceiptTemplateExistsForOperatorAsync(function (resultCtx) {
            if (resultCtx.error != null) {
                loggingService.error("Не удалось проверить существование файла шаблона чека " + customTemplate + " для оператора " + operatorId + ". Печатаем чек со стандартным шаблоном.");
                renderReceiptDefaultAsync();
            } else {
                var templateExists = resultCtx.exists;
                if (templateExists) {
                    //render receipt using custom template
                    renderReceiptAsync();
                } else {
                    var msg = "Для оператора " + operatorId + " отсутствует указанный шаблон чека " + customTemplate + ".";
                    loggingService.warn(msg);
                    smartClientManager.writeStateErrorToLog(msg);
                    //render receipt using default template
                    renderReceiptDefaultAsync();
                }
            }
        });
    } else {
        renderReceiptAsync();
    }
};