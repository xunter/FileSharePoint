﻿(function (window, jQuery) {

    var OperatorManager = window.OperatorManager = function (operatorInstance, operatorFieldMap) {
        this._operatorInstance = operatorInstance;
        this._operatorFieldMap = operatorFieldMap;
    };

    OperatorManager.prototype = {
        getFieldMap: function () { return this._operatorFieldMap; },
        getOperatorInstance: function () { return this._operatorInstance; },
        getOperatorFieldInstancies: function () { return this._operatorInstance.Fields; },
        findFieldInstanceByCondition: function (condition) {
            var fields = this.getOperatorFieldInstancies();
            for (var i = 0; i < fields.length; i++) {
                var currFieldInstance = fields[i];
                if (condition(currFieldInstance) === true) {
                    return currFieldInstance;
                }
            }
            return null;
        },
        findFieldInstanceByComment: function (comment) {
            return this.findFieldInstanceByCondition(function (currFieldInstance) { return currFieldInstance.Description == comment });
        },
        findFieldInstanceByID: function (id) {
            return this.findFieldInstanceByCondition(function (currFieldInstance) { return currFieldInstance.ID == id });
        },
        setFieldByComment: function (comment, value) {
            var fieldForComment = this.findFieldInstanceByComment(comment);
            if (fieldForComment == null) return;
            var fieldId = fieldForComment.ID;
            var fieldKey = comment;
            this._operatorFieldMap["field" + fieldId] = value;
        },
        //return pure fieldid (if it is composite key then the method retrieves a pure part and returns it)
        getPureFieldID: function (fieldId) {
            var underlineIndex = fieldId.indexOf("_");
            if (~underlineIndex) {
                var pureFieldId = fieldId.substr(0, underlineIndex);
                return pureFieldId;
            } else {
                return fieldId;
            }
        }
    };

    function computeComissionClientSideSync(op, sum, isCabinetSession) {
        var computedComission = 0;
        var comissions = isCabinetSession && (op.ComissionsCabinet != null) ? op.ComissionsCabinet : op.Comissions;
        if (comissions && comissions.length) {
            comissions = _.sortBy(comissions, function (c) { return c.Min });
            var currMin = 0;
            var appropriatedComission = null;
            _.each(comissions, function (comission) {
                var tempMin = comission.Min;
                if (tempMin >= currMin) {
                    if (sum >= tempMin) {
                        currMin = tempMin;
                        appropriatedComission = comission;
                    }
                }
            });

            if (appropriatedComission != null) {
                var comissionVal = appropriatedComission.RawValue;
                if (comissionVal) {
                    if (comissionVal.indexOf("%") != -1) {
                        var percentages = parseFloat(comissionVal.substr(0, comissionVal.length - 1));
                        computedComission = sum * percentages / 100;
                    } else {
                        computedComission = parseFloat(comissionVal);
                    }
                }
            }
        }
        var computedComissionStr = computedComission.toFixed(2);
        computedComission = parseFloat(computedComissionStr);
        return computedComission;
    };

    function computeComissionClientSideAsync(op, sum, isCabinetSession, callback) {
        var triggerCallback = function (amountComission) {
            if (callback) callback(amountComission);
        };
        var comissions = isCabinetSession && (op.ComissionsCabinet != null) ? op.ComissionsCabinet : op.Comissions;
        if (comissions && comissions.length) {
            comissions = _.sortBy(comissions, function (c) { return c.Min });
            var currMin = 0;
            var appropriatedComission = null;
            _.each(comissions, function (comission) {
                var tempMin = comission.Min;
                if (tempMin >= currMin) {
                    if (sum >= tempMin) {
                        currMin = tempMin;
                        appropriatedComission = comission;
                    }
                }
            });

            if (appropriatedComission != null) {
                var comissionVal = appropriatedComission.RawValue;
                if (comissionVal) {
                    if (comissionVal.indexOf("%") != -1) {
                        var percentages = parseFloat(comissionVal.substr(0, comissionVal.length - 1));
                        if (percentages && !isNaN(percentages)) {
                            var computedComission = sum * percentages / 100;
                            triggerCallback(computedComission);
                        }
                    } else {
                        var computedComission = parseFloat(comissionVal);
                        if (computedComission && !isNaN(computedComission)) {
                            triggerCallback(computedComission);
                        }
                    }
                }
            }
        }
        triggerCallback(0);
    };

    function computeComissionServerSideAsync(op, sum, isCabinetSession, callback) {
        TerminalUI.ajaxService.postJSON(URL_COMPUTE_OPERATOR_COMISSION, { id: op.ID, amount: sum, isCabinetSession: isCabinetSession }, function (res) {
            if (callback) callback(res.amountComission);
        });
    };

    OperatorManager.computeComission = function (op, sum, isCabinetSession, callback) {
        var amountComission = computeComissionClientSideSync(op, sum, isCabinetSession);
        if (callback) callback(amountComission);
        return amountComission;
    };

    OperatorManager.computeAmountAll = function (op, sum, isCabinetSession) {
        var comission = OperatorManager.computeComission(op, sum, isCabinetSession);
        return sum + comission;
    };
})(window, jQuery)