﻿function PayGatewayOfflineRequestBuilder() {
    this._request = {};
};
PayGatewayOfflineRequestBuilder.prototype = {
    getRequest: function () { return this._request; },
    setOperatorInfo: function (id, name) {
        this._request["op"] = name;
        this._request["operatorId"] = id;
    },
    setAmounts: function (amount, payAmount) {
        this._request["amount"] = payAmount;
        this._request["amountAll"] = amount;
    },
    setChequeNum: function (chequeNum) { this._request["chequeNum"] = chequeNum; },
    setDate: function (date) { this._request["initDateTime"] = date },
    setFields: function (fieldMap) { this._request["fields"] = fieldMap },
    setCabinetInfo: function (cabinetId, userId) {
        this._request["cabinetId"] = cabinetId;
        this._request["userId"] = userId;
    },
    setParams: function (params) {
        for (var key in params) { 
            this._request[key] = params[key];
        }
    }
};