﻿(function (window) {
    var Bootstrapper = window.Bootstrapper = {
        init: function () { },
        load: function () {
            var navManager = NavManager.getInstance();
            navManager.triggerEventAsync({
                name: "pageLoad",
                args: {},
                callback: function () {

                }
            });
        },
        navManagerReady: function (asyncHandler) { 
            
        }
    };
})(window);