﻿!function (window, Listenable) {
    ListenableSubjectFactory = {
        "createSubject": function () {
            return new Listenable();
        }
    };
} (window, Listenable);