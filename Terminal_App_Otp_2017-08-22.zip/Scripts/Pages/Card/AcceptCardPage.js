﻿(function ($, globalCtx) {
    var bins = globalCtx.bins = $.map(cardInfos, function (cardInfo) { return { startChars: cardInfo.Bin, description: cardInfo.Description, processingId: cardInfo.ProcessingID, balanceMode: cardInfo.BalanceMode, supportedNumLengths: cardInfo.SupportedNumLengths} });

    var AcceptCardPage = globalCtx.AcceptCardPage = {
        $lock: null,
        $bMainMenu: null,
        $bBack: null,
        $bCancel: null,
        $lError: null,
        $dlgError: null,
        $bDlgErrorCancel: null,
        _unloadTriggered: false,
        loggingService: FS.TerminalUI.loggingService,

        dlgManager: DlgManager,
        smartClientManager: SmartClientManager,
        cardReaderListener: {
            cardReaderCallback: function (paramName, paramValue) {
                AcceptCardPage.cardReaderCallbackHandler(paramName, paramValue);
            },

            cardEjected: function () {
                AcceptCardPage.$bCancel.addClass("th-hidden");
            }
        },

        load: function () {
            var self = this;
            this.$bBack = $("#bBack");
            this.$bCancel = $("#bCancel");
            this.$lock = this.dlgManager.$lock = $("#lock");
            this.$bMainMenu = $("#bMainMenu");
            this.$lError = $("#lError");
            this.$dlgError = $("#dlgError");
            this.$bDlgErrorCancel = $("#bDlgErrorOk");

            this.$bDlgErrorCancel.click(function () { self.bDlgErrorCancelClickHandler(); });

            $(window).bind("unload", function () { self.cleanUpOnWindowClose() });
            this.$fTransferCardReadingInfo = $("#" + formTransferingCardReadingInfoClientSideID);
            this.initCardReaderListener();
            this.loggingService.trace("Opening the card reader...");

            this.checkCardReader(function (state) {
                if (state == "Operable") {
                    SmartClientManager.openCardReader();
                    self.loggingService.trace("The card reader was opened.");
                } else {
                    SmartClientManager.writeStateErrorToLog(UIMessageMap["CARD_READER_NOT_OPERABLE"]);
                    SmartClientManager.writeStateErrorToLog(UIMessageMap["ERROR_NAVIGATING_CARD_READER_NOT_OPERABLE"]);
                    ClientSidePage.layoutPage.navigateToError();
                }
            });
        },

        checkCardReader: function (callback) {
            SmartClientManager.once({
                cardReaderState: function (state) {
                    callback(state);
                }
            });
            SmartClientManager.stateCardReader();
        },

        bDlgErrorCancelClickHandler: function () {
            this.dlgManager.hideDlg(this.$dlgError);
        },

        initCardReaderListener: function () {
            this.smartClientManager.addListener(this.cardReaderListener);
        },

        cleanUpOnWindowClose: function () {
            if (!this._unloadTriggered) {
                this._unloadTriggered = true;
                this.smartClientManager.removeListener(this.cardReaderListener);
                this.smartClientManager.closeCardReader();
            }
        },

        getCardReadingInfoParam: function (paramName) {
            return CardDataFormManager.getParamValue(paramName);
        },
        setCardReadingInfoParam: function (paramName, paramValue) {
            CardDataFormManager.setParamValue(paramName, paramValue);
            return this;
        },
        cardRead: function () {
            this.postCardReadingInfoToAuthenticate();
        },

        postCardReadingInfoToAuthenticate: function () {
            this.$fTransferCardReadingInfo.submit();
        },

        maskCardParam: function (paramName, paramValue) {
            var maskExclusions = [" ", "^", "/", ",", ".", "\\"];
            var paramValueMasked = maskString(paramValue, "*", maskExclusions);
            return paramValueMasked;
        },

        cardReaderCallbackHandler: function (paramName, paramValue) {
            var maskExclusions = null;
            var paramValueMasked = this.maskCardParam(paramName, paramValue);
            this.smartClientManager.writeToLog("Чтение карты " + paramName + " " + paramValueMasked);
            this.$bBack.addClass("th-hidden");
            this.$bMainMenu.addClass("th-hidden");
            switch (paramName) {
                case "CardPosition":
                    {
                        this.setCardReadingInfoParam("CardPosition", paramValue);
                    } break;

                case "CardResult":
                    {
                        this.setCardReadingInfoParam("CardResult", paramValue);
                    } break;

                case "TrackResult1":
                    {
                        card.result1 = parseInt(paramValue, 10);
                    } break;

                case "TrackResult2":
                    {
                        card.result2 = parseInt(paramValue, 10);
                    } break;

                case "TrackResult3":
                    {
                        card.result3 = parseInt(paramValue, 10);
                    } break;

                case "Track1":
                    {
                        card.track1 = paramValue;
                    } break;

                case "Track2":
                    {
                        card.track2 = paramValue;
                    } break;

                case "Track3":
                    {
                        card.track3 = paramValue;
                    } break;

                case "CardReaded":
                    {
                        var cardNumber = cardManager.parseNumber(card.track2),
                                cardExpirationDate = cardManager.parseExpirationDate(card.track2),
                                cardOwner = cardManager.parseOwner(card.track1),
                                cardReaded = card.result1 + "," + card.result2 + "," + card.result3,
                                bin = null;

                        var cardNumberForLog = getCardNumberToShare(cardNumber);
                        this.smartClientManager.writeStateToLog(formatMsg("Пользователь вставил карту %1", cardNumberForLog));
                        var formattedDate = cardExpirationDate != null ? formatDate(cardExpirationDate, FS.TerminalUI.Settings.dateShortPattern) : "";
                        var expirationDate = (cardExpirationDate == null) ? "" : cardExpirationDate.toLocaleDateString();
                        this.setCardReadingInfoParam("CardNumber", cardNumber)
                                .setCardReadingInfoParam("CardExpirationDate", formattedDate)
                                .setCardReadingInfoParam("CardOwner", cardOwner)
                                .setCardReadingInfoParam("Track1", card.track1)
                                .setCardReadingInfoParam("Track2", card.track2)
                                .setCardReadingInfoParam("Track3", card.track3)
                                .setCardReadingInfoParam("CardReaded", cardReaded)
                                .setCardReadingInfoParam("CardDescription", "");

                        if (card.result2 != 0 || card.track2.length == 0 || cardNumber.length == 0) {
                            this.setCardReadingInfoParam("CardReaderMessage", cardMessage.CARD_NOT_READED);
                            this.showError(cardMessage.CARD_NOT_READED);
                            this.smartClientManager.ejectCard();
                            return;
                        }
                        bin = cardManager.getBin(cardNumber, bins);
                        if (bin == null) {
                            this.setCardReadingInfoParam("CardReaderMessage", cardMessage.CARD_NOT_SERVICE);
                            this.showError(cardMessage.CARD_NOT_SERVICE);
                            this.smartClientManager.ejectCard();
                            return;
                        } else {
                            this.setCardReadingInfoParam("CardInfoInstance_Bin", bin.startChars);
                            this.setCardReadingInfoParam("CardInfoInstance_NumLength", bin.cardLength);
                            this.setCardReadingInfoParam("CardInfoInstance_Description", bin.description);
                            this.setCardReadingInfoParam("CardInfoInstance_ProcessingID", bin.processingId);
                            this.setCardReadingInfoParam("CardDescription", bin.description);
                        }

                        if (CARD_CHECK_EXPIRATION_DATE_ENABLED) {
                            var isCardExpirationDateValid = cardManager.checkExpirationDateValid(cardExpirationDate);
                            if (!isCardExpirationDateValid) {
                                this.setCardReadingInfoParam("CardReaderMessage", cardMessage.CARD_EXPIRED);
                                this.showError(cardMessage.CARD_EXPIRED);
                                this.smartClientManager.ejectCard();
                                return;
                            }
                        }
                        this.setCardReadingInfoParam("CardReaderMessage", cardMessage.CARD_READED);
                        this.cardRead();
                    } break;
            }
        },

        showError: function (msg) {
            this.$lError.text(msg);
            this.dlgManager.showDlg(this.$dlgError);
        }
    };
})(jQuery, window);