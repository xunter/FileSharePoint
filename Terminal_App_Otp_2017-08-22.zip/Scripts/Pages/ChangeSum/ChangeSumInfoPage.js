﻿(function (window, $) {
    $(function () {
        var $btnForward = $("#btnForward"),
            $btnMainMenu = $("#btnMainMenu"),
            $divChangeSumInfo = $("#divChangeSumInfo"),
            $divSuccessPayment = $("#divSuccessPayment");



        var clickHandler = function () {
            $btnMainMenu.click();
        };
        $divChangeSumInfo.click(clickHandler);
        $divSuccessPayment.click(clickHandler);
        $btnForward.click(clickHandler);
        setTimeout(function () {
            var navigateUrl = $btnMainMenu.data("navigate_url");
            navigateUrl = passParamToURL(navigateUrl, { immediately_flush_change_sum: 1 });
            go(navigateUrl);
        }, UISettingsMap["CHANGE_SUM_INFO_TIMEOUT_MILLISECONDS"])
    });
})(window, jQuery)