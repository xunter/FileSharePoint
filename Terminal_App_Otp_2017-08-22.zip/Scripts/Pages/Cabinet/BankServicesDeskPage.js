﻿var BankServicesDeskPage = (function ($) {

    var BankServicesDeskPage = function () {
        ClientSidePage.apply(this, arguments);
        this.$accountsList = null;
        this.$containerButtonsRight = null;
        this._deskTopGroupMenuAvailable = false;
    };

    extend(BankServicesDeskPage, ClientSidePage, {

        defaultSettings: {
            pagingEnabled: false
        },

        $bExit: null,

        init: function (settings) {
            ClientSidePage.prototype.init.apply(this, arguments);
            if (typeof (DESK_TOP_GROUP_MENU_SHOWN) != "undefined" && DESK_TOP_GROUP_MENU_SHOWN === true) {
                this.handleDeskTopGroupMenuAvailable();
            }
        },

        load: function () {
            var self = this;
            ClientSidePage.prototype.load.apply(this, arguments);
            this.$bExit = $("#bExit");
            var $accountItems = this.$accountItems = $(".account-item");
            $accountItems.each(function (i, accountItem) {
                var $accountItem = $(accountItem);
                self.initAccountItem($accountItem);
            });

            var $pageBankServicesDesk = this.$pageBankServicesDesk = $("#pageBankServicesDesk");

            $accountDetails = this.$accountDetails = $(".account-details");
            $accountOperations = this.$accountOperations = $accountDetails.find(".operation");
            var $accountsList = this.$accountsList = $("#divAccountsList");

            var $accountsListContainer = this.$accountsListContainer = $("#accountsListContainer");
            var $bAccountsListScrollDown = this.$bAccountsListScrollDown = $("#bAccountsListScrollDown");
            var $bAccountsListScrollUp = this.$bAccountsListScrollUp = $("#bAccountsListScrollUp");

            var $containerButtonsRight = this.$containerButtonsRight = $("#containerButtonsRight");
            $accountOperations.click(function () {
                var $curr = $(this);
                var operationIndex = $curr.data("operation_index");

                var accountIndex = $curr.parentsUntil("[data-account_index]").parent().data("account_index");
                var operationGroupIndex = $curr.parentsUntil("[data-operation_group_index]").parent().data("operation_group_index");
                var account = accountsGroup.Accounts[accountIndex];
                var operationGroup = account.OperationGroups[operationGroupIndex];
                var operation = operationGroup.Operations[operationIndex];


            });

            if (typeof (DESK_TOP_GROUP_MENU_SHOWN) != "undefined" && DESK_TOP_GROUP_MENU_SHOWN === true) {
                this.handleDeskTopGroupMenuAvailable();
            }

            if (this._settings.pagingEnabled === true) {
                this.applyAccountListPaging();
                this.initPaging();
            }
        },

        navigateAccountOperation: function (url, providerId) {
            var self = this;
            self.showWaitDlg();
            var currentChecker = OperatorReceiptRequirementChecker.current;
            var accountProvider = mapAccountProviders["operator" + providerId];
            currentChecker.setProvider(accountProvider);
            currentChecker.checkReceiptUnavailable(function (btnResult, dlgTypeName) {
                if (dlgTypeName == "Alert") {
                    self.hideWaitDlg();
                } else if (dlgTypeName == "Confirm") {
                    if (btnResult == "OK") {
                        go(url);
                    } else {
                        self.hideWaitDlg();
                    }
                }
            });
        },

        callbackDlgCheckReceiptAvailabilityOK: function () {
        },
        callbackDlgCheckReceiptAvailabilityCancel: function () {
        },

        initAccountItem: function ($accountItem) {
            var self = this;
            $accountItem.click(function () {
                var $currItem = $(this);
                self.$accountItems.filter(".selected").removeClass("selected");
                $currItem.addClass("selected");
                var accountId = $currItem.data("account_index");
                self.selectAccount(accountId);
            });
        },

        selectAccount: function (accountId) {
            this.$accountDetails.filter(function () { return !$(this).hasClass("hidden") }).addClass("hidden");
            this.$accountDetails.filter("[data-account_index=" + accountId + "]").removeClass("hidden");
        },

        applyAccountListPaging: function () {
            var self = this;
            var $accountsListContainer = self.$accountsListContainer;
            var $containerButtonsRight = self.$containerButtonsRight;
            var $accountList = self.$accountsList;
            var $accountItems = $accountList.find(".account-item");

            if ($accountItems.length * $accountItems.height() > $accountList.height()) {
                $accountsListContainer.removeClass("scroll-less");
            }

            var countItems = $accountItems.length;
            var heightAccountsList = $accountList.height();
            var outerHeightAccountsList = $accountList.outerHeight();
            var heightItem = $accountItems.height();
            var heightAccountItems = countItems * heightItem;
            var $bAccountsListScrollUp = self.$bAccountsListScrollUp;
            var $bAccountsListScrollDown = self.$bAccountsListScrollDown;
            var heightBtnScroll = $bAccountsListScrollDown.height();
            var heightAccountsListWithScrollBtns = heightAccountsList - 2 * heightBtnScroll;
            var countPages = Math.ceil(heightAccountItems / heightAccountsListWithScrollBtns);

            var countItemsPerPage = Math.floor(countItems / countPages);
            var indexVisibleStart = 0;
            var maxIndexItem = countItems - 1;
            var indexVisibleEnd = countItemsPerPage < countItems ? countItemsPerPage - 1 : maxIndexItem;
            var currScroll = 0;
            var scrollStep = TerminalUI.UISettingsMap["SCROLL_STEP_OFFSET"];

            $bAccountsListScrollUp.click(function () {
                if (indexVisibleStart == 0) {
                    return;
                }

                indexVisibleStart--;
                indexVisibleEnd--;

                var $itemStart = $($accountItems.get(indexVisibleStart));
                var $itemStartPrev = $($accountItems.get(indexVisibleStart + 1));
                var topStart = $itemStart.offset().top;
                var topStartPrev = $itemStartPrev.offset().top;
                var topOffset = topStart - topStartPrev;
                var scrollTop = $accountList.scrollTop();
                var topDiff = scrollTop + topOffset;
                if (scrollTop + topOffset < 0) {
                    topOffset = -scrollTop;
                }
                topOffset = Math.abs(topOffset);

                $accountList.scrollTo({ left: 0, top: "-=" + topOffset + "px" }, 800);
            });

            $bAccountsListScrollDown.click(function () {
                if (indexVisibleEnd == maxIndexItem) {
                    return;
                }

                indexVisibleStart++;
                indexVisibleEnd++;

                var $itemEnd = $($accountItems.get(indexVisibleStart));
                var $itemEndPrev = $($accountItems.get(indexVisibleStart - 1));
                var topStart = $itemEnd.offset().top;
                var topStartPrev = $itemEndPrev.offset().top;
                var topOffset = topStart - topStartPrev;
                var scrollTop = $accountList.scrollTop();
                var topDiff = scrollTop + topOffset;

                if (scrollTop + topOffset + heightAccountsList > heightAccountItems) {
                    topOffset = heightAccountItems - heightAccountsList - scrollTop;
                }

                $accountList.scrollTo({ left: 0, top: "+=" + topOffset + "px" }, 800);
            });
        },

        selectAccountListPage: function (pageNum) {

        },

        initPaging: function () {

        },

        handleDeskTopGroupMenuAvailable: function () {
            if (this._deskTopGroupMenuAvailable === false) {
                this._deskTopGroupMenuAvailable = true;
                this.$pageBankServicesDesk.addClass("desk-top-group-menu-available");
            }
        }
    });

    return BankServicesDeskPage;
})(jQuery);