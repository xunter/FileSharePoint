﻿if (SERVICE_MENU_PREVENT_MAIN_MENU) {
    SmartClientManager.preventPinPadCancel();
    SmartClientManager.denyIdleTimeoutHandler();
    SmartClientManager.addHandler("screenPanelCallbackForced", function () {
        ClientSidePage.layoutPage.navigate(UNAVAILABLE_PAGE_PATH);
    });
}

FS.TerminalUI.preventHandlingPrinterNotOperableStateFromMaster = true;

function ServiceMenuLogOnPage() {
    ClientSidePage.apply(this, arguments);
    ServiceMenuLogOnPage.current = this;
};

extend(ServiceMenuLogOnPage, ClientSidePage, {
    $bBack: null,
    $bMenu: null,
    $bForward: null,
    $dlgError: null,
    $bDlgErrorOk: null,
    $lError: null,

    fieldManager: null,
    tbField: null,
    smartClientManager: SmartClientManager,
    fieldInstance: field,
    fieldElement: null,

    pinPadListener: {
        pinPadCorrectionPressed: function (args) {
            ServiceMenuLogOnPage.current.fieldManager.removeLastLetter();
        },
        pinPadDigitPressed: function (args) {
            ServiceMenuLogOnPage.current.fieldManager.appendLetter(args.letter);
        },
        pinPadAcceptPressed: function (args) {
            if (ServiceMenuLogOnPage.current.$bForward.hasClass("th-hidden")) return;
            ServiceMenuLogOnPage.current.$bForward.click();
        }
    },

    load: function () {
        ClientSidePage.prototype.load.apply(this, arguments);
        var self = this;
        this.$bBack = $("#bBack");
        this.$bMenu = $("#bMenu");
        this.$bForward = $("#bForward");
        this.$bDlgErrorOk = $("#bDlgErrorOk");
        this.$dlgError = $("#dlgError");
        this.$lError = $("#lError");
        this.tbField = document.getElementById("tbField");

        this.fieldElement = document.getElementById("field" + this.fieldInstance.ID);
        this.smartClientManager.addListener(this.pinPadListener);
        this.$bForward.click(function () { self.forwardClickHandler() });
        this.$bDlgErrorOk.click(function () { self.hideErrorDlg() });
        var fieldManager = this.fieldManager = new FieldManager();
        fieldManager.init({
            textBox: this.tbField,
            required: true,
            minlength: this.fieldInstance.MinLength,
            maxlength: this.fieldInstance.MaxLength,
            fieldId: this.fieldInstance.ID,
            fieldElement: this.fieldElement,
            oncomplete: function () {
                self.fieldComplete();
            },
            onincomplete: function () {
                self.fieldIncomplete();
            }
        });
    },
    fieldComplete: function () {
        this.$bForward.removeClass("th-hidden");
    },
    fieldIncomplete: function () {
        this.$bForward.addClass("th-hidden");
    },
    showErrorDlg: function (msg) {
        this.$lError.text(msg);
        DlgManager.showDlg(this.$dlgError);
    },
    hideErrorDlg: function () {
        DlgManager.hideDlg(this.$dlgError);
    },
    forwardClickHandler: function () {


        var self = this;
        var password = this.fieldManager.getFieldValue();
        this.showWaitDlg();
        var listener = {
            terminalManagerPasswordStatus: function (status) {
                if (status == "False") {
                    self.hideWaitDlg();
                    self.showErrorDlg("Неверный пароль!");
                }
                self.smartClientManager.removeListener(listener);
            }
        };
        this.smartClientManager.addListener(listener);
        this.smartClientManager.startTerminalManager(password);
    }
});