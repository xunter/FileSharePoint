﻿///<reference path="../NavManager.js" />

//Init global namespaces
FS = {};
FS.FS = {};
FS.Gateway = {};
TerminalUI = FS.TerminalUI = FS.TerminalUI = {};

var _ajaxClientSideLogging = null;

(function (window, $, SmartClientManager, TerminalUI) {
    layoutMisc = function () {
        initSCMnLSnAS();
        setupJQAjax();
        $(function () { 
            preventDocumentSelection(); 
            logNavBtnClick();    
        });	
    };

    //Init SmartClientManager, logging service and ajax service
    initSCMnLSnAS = function () {
        SmartClientManager.init({ 
            pollTimeout: 60000, 
            communicator: smartClientCommunicator, 
            cardCaptureTimeout: cardCaptureTimeout, 
            pointNumber: pointNumber,
            requestTimeout: SMART_CLIENT_MANAGER_REQUEST_TIMEOUT_MILLISECONDS,
            enableRequestTimeout: TerminalUI.Config.SmartClientManager.RequestTimeout.Enabled
        });

        var ajaxService = new JQueryAjaxService();
        var loggingService = new LoggingService();

        var consoleLogLogging = null;
        if (typeof(window.console) != "undefined" && typeof(window.console.log) != "undefined") {
            consoleLogLogging = {
                logProxy: function(logEntry, logMethodName) {
                    try {
                        if (typeof(console[logMethodName]) != "undefined") {
                            console[logMethodName](logEntry.msg);
                        } else {
                            console.log(logEntry.msg);                      
                        }
                    } catch (e) {
                        
                    }                
                },
                log: function(logEntry) {
                    this.logProxy(logEntry, "log");
                },
                debug: function(logEntry) {
                    this.logProxy(logEntry, "debug");
                },
                info: function(logEntry) {
                    this.logProxy(logEntry, "info");
                },
                warn: function(logEntry) {
                    this.logProxy(logEntry, "warn");
                },
                error: function(logEntry) {
                    this.logProxy(logEntry, "error");
                },
                fatal: function(logEntry) {
                    this.logProxy(logEntry, "error");
                }
            }
        }

        var smartClientManagerLogging = {
            error: function (logEntry) { SmartClientManager.writeErrorToLog(logEntry.msg) },
            fatal: function (logEntry) { SmartClientManager.writeErrorToLog(logEntry.msg) }
        };
        var ajaxClientSideLogging = _ajaxClientSideLogging = {
            batchEnabled: true,
            batchSize: 10,
            batchQueue: [],
            ajaxService: ajaxService,
            url: URL_WRITE_CLIENT_SIDE_LOG,
            urlBatch: URL_WRITE_CLIENT_SIDE_LOG_BATCH,
            writeAllBatchWhileEntriesCome: function(callback) {
                var triggerCallback = function() {
                    if (callback) callback();
                };
                
                var self = this;
                self.writeAllBatch(callback);
                var timer = setInterval(function() {
                    if (self.batchQueue.length) {
                        self.writeAllBatch(callback);                            
                    } else {
                        clearInterval(timer);
                        triggerCallback();
                    }
                }, 300);
            },
            writeAllBatch: function(callback) {
                var triggerCallback = function() {
                    if (callback) callback();
                };
                this.writeBatch(this.batchQueue.length, function() {
                    triggerCallback();
                });
            },
            writeBatch: function(count, callback) {
                var triggerCallback = function() {
                    if (callback) callback();
                };
                var realCount = count < this.batchQueue.length ? count : this.batchQueue.length;
                if (realCount == 0) {
                    triggerCallback();
                }
                var dtoArr = this.batchQueue.splice(0, realCount);
                this.ajaxService.postJSON(this.urlBatch, dtoArr, function() {
                    triggerCallback();
                });
            },
            log: function(logEntry) {
                if (this.batchEnabled) {
                    this.batchQueue.push(logEntry);
                    if (this.batchQueue.length >= this.batchSize) {
                        this.writeBatch(this.batchQueue.length);
                    }                
                } else {
                    this.ajaxService.postJSON(this.url, logEntry);
                }
            }
        };

        if (consoleLogLogging != null) {
            loggingService.addListener(consoleLogLogging);
        }
        loggingService.addListener(smartClientManagerLogging);
        loggingService.addListener(ajaxClientSideLogging);

        extendObject(TerminalUI, {
            ajaxService: ajaxService,
            loggingService: loggingService,
            smartClientManager: SmartClientManager
        });
    };

    //Setup jQuery ajax
    setupJQAjax = function () {
        $.ajaxSetup({
            beforeSend: function(jqXhr, settings) {
                jqXhr.requestUrl = settings.url;
            },
            error: function (jqXHR, textStatus, errorThrown) {
                var requestUrl = jqXHR.requestUrl,
                    status = jqXHR.status,
                    message = formatMsg("A client-side ajax error has occurred! URL is %1. Text status is %2. The thrown error is %3. The http status is %4.", requestUrl, textStatus, errorThrown, status);
                SmartClientManager.writeErrorToLog(message);
            }
        });
    };

    //Writes msg to the state log about the click event on a navigation button
    logNavBtnClick = function() {
        $(".btn-nav").filter(".loggable").click(function() {
            var type = $(this).data("btn_type"),
                logMsg = formatMsg("Нажата кнопка навигации: %1.", type);
            SmartClientManager.writeStateToLog(logMsg);
        });
    };

    initDeviceStateHandling = function () {
        $(function () {
            if (FS.TerminalUI.Config.Devices.DeviceStateHandling.HandlePrinterState) {
                FS.TerminalUI.loggingService.trace("Adding a listener to listen a printer state...");
                SmartClientManager.addListener({
                    printerCallback: function (args) {
                        var paramName = args.paramName;
                        var paramValue = args.paramValue;
                        if (paramName == "DeviceState" && paramValue == "NotOperable") {
                            FS.TerminalUI.loggingService.fatal("The printer is not operable!");
                            FS.TerminalUI.loggingService.trace("The amount in the bill validator is %1.", _layoutPage.billValidatorAmount);
                            if (_layoutPage.billValidatorAmount == 0 && (FS.TerminalUI.preventHandlingPrinterNotOperableStateFromMaster !== true && location.pathname.toLowerCase() != _layoutPage._urlPrinterError.toLowerCase())) {
                                FS.TerminalUI.loggingService.trace("Navigating to the printer error page...");
                                
                                var loggingService = TerminalUI.loggingService;
                                var scm = SmartClientManager;
                                loggingService.info("Navigating to the Error page due to the Printer is not operable...");
                                var humanMsg = TerminalUI.UIMessageMap["ERROR_NAVIGATING_PRINTER_NOT_OPERABLE"];
                                scm.writeStateErrorToLog(humanMsg);

                                _layoutPage.navigateToPrinterError();
                            }
                        }
                    }
                });
                FS.TerminalUI.loggingService.trace("The printer state listener was added.");
                SmartClientManager.statePrinter();
            }
            if (FS.TerminalUI.Config.Devices.DeviceStateHandling.HandleBillValidatorState) {
                SmartClientManager.addListener({
                    billValidatorCallback: function (args) {
                        var paramName = args.paramName;
                        var paramValue = args.paramValue;
                        if (paramName == "DeviceState" && paramValue == "NotOperable" && billValidatorSum == 0) {
                            SmartClientManager.writeErrorToLog("Ошибка при работе с купюроприемником! Купюроприемник не работает!");

                            var loggingService = TerminalUI.loggingService;
                            var scm = SmartClientManager;
                            loggingService.info("Navigating to the Error page due to the bill validator is not operable...");
                            var humanMsg = TerminalUI.UIMessageMap["ERROR_NAVIGATING_BILLVALIDATOR_NOT_OPERABLE"];
                            scm.writeStateErrorToLog(humanMsg);

                            _layoutPage.navigateToError();
                        }
                    }
                });
            }
            if (FS.TerminalUI.Config.Devices.DeviceStateHandling.HandleWMCopyData) {
                SmartClientManager.addListener({
                    wmCopyDataCallback: function (args) {
                        var paramValue = args.paramValue;
                        paramValue = typeof (paramValue) == "number" ? paramValue : parseInt(paramValue);
                        if (paramValue < 0) {
                            SmartClientManager.writeErrorToLog("Ошибка при работе с протоколом обмена с устройствами (код " + paramValue + ")!");
                            
                            var loggingService = TerminalUI.loggingService;
                            var scm = SmartClientManager;
                            loggingService.info("Navigating to the Error page due to the WM_COPY_DATA protocol is not operable...");
                            var humanMsg = TerminalUI.UIMessageMap["ERROR_NAVIGATING_WMCOPYDATA_NOT_OPERABLE"];
                            scm.writeStateErrorToLog(humanMsg);

                            _layoutPage.navigateToError();
                        }
                    }
                });
            }
        });
    };

    initDeviceSet = function (currentDeviceSet) {
        FS.TerminalUI.currentDeviceSet = currentDeviceSet;
        DeviceManager.getInstance().setDeviceSet(currentDeviceSet);
    };

    initLayoutPage = function () {
        _layoutPage = ClientSidePage.runNewPage(
            LayoutPage, 
            {}, 
            { 
                urlMainMenu: URL_MAINMENU, 
                urlCabinetSignOut: urlCabinetSignOut, 
                urlError: URL_ERROR, 
                urlPrinterError: urlPrinterError, 
                showShadowOnNavigating: FS.TerminalUI.Config.General.ShowShadowOnNavigating 
            }
        );

        ClientSidePage.layoutPage = _layoutPage;
        return _layoutPage;
    };

    initUltimateTimeoutIfEnabled = function() {
        var loggingService = TerminalUI.loggingService;
        var scm = SmartClientManager;
        var navManager = NavManager.getInstance();

        if (TerminalUI.UISettingsMap["TIMEOUT_ULTIMATE_ENABLED"] == "1") {     
            var screenPanelCallbackTriggerred = false;     
            loggingService.trace("The ultimate timeout feature is enabled.");  
            var timeoutMills = parseFloat(TerminalUI.UISettingsMap["TIMEOUT_ULTIMATE_MILLISECONDS"]);
            var timeout = null;

            var deleteTimeout = function() {
                clearTimeout(timeout);
                timeout = null;
            };

            var createTimeout = function() {
                timeout = setTimeout(function() {
                    if (!screenPanelCallbackTriggerred) {
                        loggingService.trace("The screenPanelCallback wasn't triggered yet and the ultimate timeout will be exceeded.");
                        deleteTimeout();
                        createTimeout();
                        return;                    
                    }
                    loggingService.info("The ultimate timeout has been triggered.");
                    loggingService.info("The terminal will be navigated to the Start page.");
                    scm.writeStateToLog("LOG_MSG_START_PAGE_NAVIGATING_ULTIMATE_TIMEOUT");
                    scm.writeStateToLog("ULTIMATE_TIMEOUT_TRIGGERRED");
                    navManager.navigateStart({ quiet: true });
                }, timeoutMills);    
                return timeout;
            };
            loggingService.trace("adding handler: LayoutMisc.screenPanelCallbackForced.");            
            scm.addHandler("screenPanelCallbackForced", function() {
                screenPanelCallbackTriggerred = true;
            });
            loggingService.trace("adding handler: LayoutMisc.screenPanelActive.");
            scm.addHandler("screenPanelActive", function() {
                loggingService.trace("LayoutMisc.screenPanelActive. Timeout = %1", timeout);
                if (timeout != null) {
                    deleteTimeout();
                    timeout = createTimeout();
                }
            });

            createTimeout();
        }
    };

    initPinPadForActiveDlgIfEnabled = function() {
        var smartClientManager = SmartClientManager;

        if (TerminalUI.UISettingsMap["PIN_PAD_ACTIONS_FOR_DLG_BTNS_ENABLED"] == "1") {
            var registerPinPadActionForDlgBtn = function(btnType, pinPadBtnType) {
                smartClientManager.addHandler("pinPad"+pinPadBtnType+"Pressed", function () {
                    var $activeDlg = DlgManager.peekDlg();
                    if ($activeDlg != null) {
                        var $btn = $activeDlg.find("[data-btn_type="+btnType+"]");
                        if ($btn != null && $btn.length) {
                            $btn.click();
                            return false;                    
                        }
                    }
                });        
            };

            registerPinPadActionForDlgBtn("OK", "Accept");
            registerPinPadActionForDlgBtn("Cancel", "Cancel");
        }
    };

    var idleTimeoutHandler = TerminalUI.idleTimeoutHandler = function () {
        var loggingService = TerminalUI.loggingService;
        var busy = ClientSidePage.getCurrent().isBusy() === true;
        var navigating = TerminalUI.navigating === true;
        if (busy || navigating)
        {
            loggingService.trace("The screenPanelCallback has triggered and will not have been handled because the current page \"%1\" is busy or navigating.", location.pathname);
        }
        else
        {
            if (TerminalUI.UISettingsMap["DLG_IDLE_TIMEOUT_ENABLED"] == 1)
            {
                var path = location.pathname.toLowerCase();
                var deniedPaths = TerminalUI.UISettingsMap["DLG_IDLE_TIMEOUT_DENIED_PATHS"].split(";");
                for (var i = 0; i < deniedPaths.length; i++)
                {
                    var deniedPathLower = deniedPaths[i].toLowerCase();
                    if (path.indexOf(deniedPathLower) != -1)
                    {
                        loggingService.info("The %1 path is denied to show idling dlg. The default action will be invoked.", path);
                        return;
                    }
                }

                ClientSidePage.layoutPage.showDlgIdleTimeout();
            }                
        }
    };
    
    initStorageManager = function() {
        StorageManager.init();
    };

    initMiscSCMHandlers = function () {
        SmartClientManager.addListener(new Listener({
            //Handle the cancel pin pad cancel (back to main menu)
            pinPadCancelPressed: function () {
                if (SmartClientManager.getPinPadCancelEnabled() === true) {
                    var currPage = ClientSidePage.getCurrent();
                    var allowToCancel = true;
                    if (currPage != null) {
                        allowToCancel = !currPage.busy;
                    }
                    if (allowToCancel && !_layoutPage.isCurrUrlMainMenu()) {
                        var loggingService = TerminalUI.loggingService;
                        var scm = SmartClientManager;

                        loggingService.info("Navigating to the Start page due to the Cancel pin pad button was pressed...");
                        scm.writeStateToLog("LOG_MSG_START_PAGE_NAVIGATING_PINPAD_CANCEL_PRESSED");
                        _layoutPage.navigateToMainMenu();
                    }
                }
            },
            //misc actions on bill validator sum changed
            billValidatorSum: function (args) {
                var sum = args.sum;
                billValidatorAmount = sum;
                _layoutPage.billValidatorAmount = sum;
            },
            
            //handle screen idling timeout (back to main menu)
            screenPanelCallback: idleTimeoutHandler,

            //Push card reader position to server
            cardReaderCallback: function (paramName, paramValue) {
                if (paramName == "CardPosition") {
                    FS.TerminalUI.ajaxService.postJSON(URL_CARD_SET_POSITION, { position: paramValue });
                }
            },
            requestTimeout: function(args) {
                var targetAsyncMethod = args.targetAsyncMethod;
                if (!targetAsyncMethod) {
                    targetAsyncMethod = "Unspecified";
                }
                var loggingService = TerminalUI.loggingService;
                var scm = SmartClientManager;
                loggingService.info("Navigating to the Error page due to the %1 request timeout...", targetAsyncMethod);
                var humanMsg = TerminalUI.UIMessageMap["ERROR_NAVIGATING_REQUEST_TIMEOUT"];
                humanMsg = humanMsg.replace("#TARGET_ASYNC_METHOD#", targetAsyncMethod);
                scm.writeStateErrorToLog(humanMsg);
                _layoutPage.navigateToError();
            },

            changeSumCallback: function (changeSumValue)
            {
                ChangeSumManager.Instance.fetchChangeSumAsync(
                    function ()
                    {
                        ChangeSumManager.Instance.updateBannerAsync();
                    });
            }
        }));
    };

    handleWindowErrorEvent = function () {
        window.onerror = function (msg, url, linenumber) {
            var msgEncoded = encodeURIComponent(msg);
            var urlEncoded = encodeURIComponent(url);
            var msgForLog = "A client-side error has occurred. Msg is \"" + msg + "\". URL is \"" + url + "\". Line number is " + linenumber + ".";
            TerminalUI.loggingService.error(msgForLog);
        };
    };

    initChangeSumManager = function () {
        ChangeSumManager.Instance = new ChangeSumManager(
            {
                urlPushChangeSum: FS.TerminalUI.Settings.urlPushChangeSum,
                urlFetchChangeSum: FS.TerminalUI.Settings.urlFetchChangeSum,
                urlGetChangeSumBanner: FS.TerminalUI.Settings.urlGetChangeSumBanner
            },
            SmartClientManager);
    };

    initCabinetManager = function() {
        var cabinetInfo = TerminalUI.CurrentCabinetInfo;
        if (cabinetInfo != null) {
            CabinetManager.setCabinetInfo(cabinetInfo);
        }
        CabinetManager.init({ urlCabinetAddOperator: URL_CABINET_ADD_OPERATOR, urlCabinetCheckSameOperatorAccount: URL_CABINET_CHECK_SAME_OPERATOR_ACCOUNT });
    };
    
    initEvents = function() {
        var events = new Listenable();
        TerminalUI.events = events;
        events.notify("events.inited");
    };
    
    go = function(path) {
        NavManager.getInstance().navigateAsync(path, function() {
            
        });
    };
    
    initEvents();

    var navManager = TerminalUI.navManager = NavManager.getInstance();
    
    navManager.addPreNavAsyncTask(function(ctx) {
        this.complete();
        TerminalUI.navigating = true;
    });

    navManager.addPreNavAsyncTask(function(ctx) {
        var handlerCtx = this;
        _ajaxClientSideLogging.writeAllBatchWhileEntriesCome(function() {
            handlerCtx.complete();
        });
    });
        
	navManager.addPageLoadAsyncTask(function() {
		var loggingService = TerminalUI.loggingService;
		loggingService.debug("Page loaded nav manager handler has been invoked. Setting the _pageLoaded field to true...");
		navManager._pageLoaded = true;
        this.complete();
	});
     
    $(function() {
		var loggingService = TerminalUI.loggingService;

        loggingService.debug("JQuery ready event has been triggerred from the LayoutMisc.js");
        	
        loggingService.debug("Triggering the NavManager page load event...");

        navManager.triggerEventAsync({
            name: "pageLoad",
            callback: function() {
                loggingService.debug("The NavManager page load event has been triggered and all handlers have been invoked.");
            }
        });
    });

    performUltimateBootstrap = function() {
        handleWindowErrorEvent();
        initStorageManager();
        TerminalUI.isFirstAppRun = IS_FIRST_APP_RUN;
		initChangeSumManager();
        initLayoutPage(); 
        initPinPadForActiveDlgIfEnabled();           
        initMiscSCMHandlers();
        initDeviceStateHandling();
        initCabinetManager();
        initUltimateTimeoutIfEnabled();
    };
})(window, jQuery, SmartClientManager, FS.TerminalUI);