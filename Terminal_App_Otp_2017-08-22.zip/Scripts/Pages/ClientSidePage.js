﻿var ClientSidePage = function () {
    ClientSidePage._current = this;

    this._navManager = null;

    this._settings = null;
    this._loaded = false;
    this.layoutPage = ClientSidePage.layoutPage;
    this._pageTypeName = this.getPageTypeName();

    this._path = null;
    this.busy = false;

    this.initializing = new Listenable();
    this.initialized = new Listenable();
    this.loading = new Listenable();
    this.loaded = new Listenable();
    this.navigating = new Listenable();
    this.navigated = new Listenable();
};
ClientSidePage._current = null;

ClientSidePage.layoutPage = null;
ClientSidePage.prototype = {
    defaultSettings: {},
    layoutPage: null,
    backPath: null,
    loggingService: null,
    smartClientManager: SmartClientManager,
    ajaxService: FS.TerminalUI.ajaxService,
    loggingService: FS.TerminalUI.loggingService,
    dlgManager: DlgManager,
    waitMsgManager: null,
    $: jQuery,

    initializing: null,
    initialized: null,

    loading: null,
    loaded: null,

    navigating: null,
    navigated: null,

    unloading: false,

    getPageTypeName: function () {
        var typeName = getTypeName(this);
        return typeName;
    },
    init: function (settings) {
        this._settings = $.extend({}, ClientSidePage.prototype.defaultSettings, this.defaultSettings);
        if (typeof (settings) == "undefined") {
            settings = {};
        }
        this._settings = settings = $.extend(this._settings, settings);
        var self = this;

        var path = self._path = window.location.pathname;

        var settingsStr = toJSON(settings);
        settingsStr = maskBankCardParams(settingsStr);
        this.loggingService.trace("Initializing the %2 page \"%3\" with the settings which are %1...", settingsStr, this._pageTypeName, path);

        if (typeof (WaitMsgManager) != "undefined") {
            this.waitMsgManager = WaitMsgManager;
        }
        if (settings.hasOwnProperty("backPath")) this.backPath = settings.backPath;

        this._navManager = NavManager.getInstance();

        self.loggingService.trace("The page %1 \"%2\" has initialized.", self._pageTypeName, path);

        this.smartClientManager.addAsyncHandler("pinPadCallbackTriggered", function (ctx) {
            self.pinPadCallbackTriggeredHandler(ctx);

            this.complete();
        });
    },

    pinPadCallbackTriggeredHandler: function (ctx) {
        if (this.busy) {
            ctx.cancel = true;
        }
    },

    isBusy: function () { return this.busy; },
    isLoaded: function () { return this._loaded },
    load: function () {
        var self = this;
        if (this.waitMsgManager != null) {
            this.waitMsgManager.init();
        }


        var $bDlgErrorOk = self.$bDlgErrorOk = $("#bDlgErrorOk");
        var $lDlgError = self.$lDlgError = $("#lError");
        var $dlgError = self.$dlgError = $("#dlgError");

        $bDlgErrorOk.click(function () {
            self.hideDlgError();
        });

        this.loggingService.trace("The %1 page \"%2\" has loaded.", this._pageTypeName, this._path);
        this._loaded = true;
    },
    createEventHandler: function (eventHandler) {
        var self = this;
        return function () { eventHandler.apply(self, arguments); };
    },
    whenLoad: function (func) {
        var self = this;
        whenCondition(function () { return self.isLoaded() }, func);
    },
    unload: function () {
        this.unloading = true;
        this.loggingService.trace("The %1 page \"%2\" has unloaded.", this._pageTypeName, this._path);
    },
    navigate: function (path) {
        this.loggingService.trace("Navigating to %1...", path);
        this._navManager.navigateAsync(path, function () {
        });
    },
    refresh: function () {
        this.navigate(this.getCurrUrl());
    },

    getCurrUrl: function () {
        return window.location.href;
    },

    getCurrUrlSDPless: function () {
        var url = this.getCurrUrl();
        var pathname = window.location.pathname;
        var indexPath = url.indexOf(pathname);
        var currPath = url.substr(indexPath);
        return currPath;
    },

    setBusy: function () {
        this.busy = true;
    },
    unsetBusy: function () {
        this.busy = false;
    },
    showWaitDlg: function () {
        this.setBusy();
        this.loggingService.trace("Showing the waiting dlg...");
        var managerExists = this.waitMsgManager != null;
        if (managerExists) this.waitMsgManager.show();
        this.loggingService.trace("The waiting dlg was shown.");
    },
    hideWaitDlg: function () {
        this.unsetBusy();
        this.loggingService.trace("Hiding the waiting dlg...");
        if (this.waitMsgManager != null) this.waitMsgManager.hide();
        this.loggingService.trace("The waiting dlg has hidden.");
    },
    showDlgError: function (msg) {
        this.$lDlgError.text(msg);
        this.dlgManager.showDlg(this.$dlgError);
    },
    hideDlgError: function () {
        this.dlgManager.hideDlg(this.$dlgError);
    },
    showElement: function (el) {
        var $el = this.$(el);

        if ($el.hasClass("th-hidden")) $el.removeClass("th-hidden");
        if ($el.hasClass("hidden")) $el.removeClass("hidden");
        if ($el.css("display") == "none") $el.show();
    },
    hideElement: function (el) {
        this.$(el).addClass("hidden");
    },
    isHidden: function (el) { return this.$(el).hasClass("th-hidden") || this.$(el).hasClass("hidden") },

    isCardAvailable: function (callback) {
        var isAvailable = typeof (CARD_AVAILABLE) != "undefined" && CARD_AVAILABLE === true;
        if (callback)
        {
            if (isAvailable)
            {
                CardManager.getCardData(function (cardData)
                {
                    callback(isAvailable, cardData);
                });
            }
            else
            {
                callback(isAvailable, cardData);
            }
        }

        return isAvailable;
    }
};

extendObject(ClientSidePage, {
    attachEvent: function ($element, eventName, handler) {
        $element.bind(eventName, function (e) {
            handler($(this), e);
        });
    },
    runNewPage: function (pageType, ctorArgs, settings) {
        var settings = settings ? settings : {};
        var ctorArgs = ctorArgs ? ctorArgs : {};
        var page = new pageType(ctorArgs);
        page.init(settings);

        var navManager = NavManager.getInstance();

        navManager.addPageLoadAsyncTask(function () {
            try {
                page.load();
            } catch (e) {

            }
            this.complete();
        });


        navManager.addPreNavAsyncTask(function (ctx) {
            try {
                page.unload();
            } catch (e) {

            }
            this.complete();
        });

        return page;
    },
    getCurrent: function () { return ClientSidePage._current; }
});