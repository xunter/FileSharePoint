﻿function TCDisplayFrameViewModel(manager, displayXml) {
    this._fieldMap = {};
    this._manager = manager;
    this._displayXml = displayXml;
    this._displayElement = $.parseXML(displayXml).documentElement;
    TCDisplayFrameViewModel._current = this;
};

TCDisplayFrameViewModel.getCurrent = function () { return TCDisplayFrameViewModel._current; };

TCDisplayFrameViewModel.prototype = {
    getDisplayFrameId: function () { return this._displayElement.getAttribute("DisplayFrameId") },
    getFieldMap: function () { return this._fieldMap; },

    setField: function (fieldName, fieldValue) {
        this._fieldMap[fieldName] = fieldValue;
        this.onFieldMapChanged(this._fieldMap, fieldName, fieldValue);
        if (fieldName == "AcceptedAmount") {
            var acceptedAmount = parseFloat(fieldValue);
            if (!isNaN(acceptedAmount)) {
                this.onAmountAccepted(acceptedAmount);
            }
        }
    },

    isRequiredTypeAmount: function () {
        return this._fieldMap.hasOwnProperty("AvailableAmount") && parseFloat(this._fieldMap["AvailableAmount"]) == 0;
    },

    isAmountTyped: function () {
        return this._fieldMap.hasOwnProperty("AvailableAmount") && parseFloat(this._fieldMap["AvailableAmount"]) > 0;
    },

    processUserAction: function (displayFrameId, buttonAction, userAction) {
        this._manager.processUserAction(displayFrameId, buttonAction, userAction);
        this.onUserAction(buttonAction, userAction);
    },

    onAmountAccepted: function (amount) { },

    onFieldMapChanged: function (fieldMap, fieldName, fieldValue) { },

    onUserAction: function (buttonAction, userAction) { }
};