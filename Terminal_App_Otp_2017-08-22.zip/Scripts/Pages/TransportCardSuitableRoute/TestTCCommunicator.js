﻿function TestTCCommunicator() {
    TCCommunicator.apply(this, arguments);
};

extend(TestTCCommunicator, TCCommunicator, {
    _step: null,
    START_SESSION_TEST_RESULT: "<DETAIL ReqAction=\"Start_of_card_service\" RespStatus=\"Success\" LongProcess=\"Yes\"><DISPLAY DisplayFrameId=\"0x1234\"><MESSAGE Type=\"Plain\">Предъявите карту</MESSAGE><BUTTON ButtonAction=\"Cancel\" Enable=\"Yes\">Отмена</BUTTON></DISPLAY></DETAIL>",
    CARD_AUTH_COMPLETE_TEST_RESULT: "<DETAIL ReqAction=\"CallBack request\" RespStatus=\"Success\"><DISPLAY DisplayFrameId=\"0x1234\"><BUTTON ButtonAction=\"Cancel\" Enable=\"Yes\">Отмена</BUTTON><BUTTON ButtonAction=\"Enter\" Enable=\"Yes\">Оплата</BUTTON><AMOUNT_PARAMETER Type=\"CardBalance\" Value=\"101.00\" Name=\"Баланс:\"/><DATE_TIME_PARAMETER Type=\"ExpireDate\" Name=\"Действителен до:\" Year=\"2010\" Month=\"11\" Day=\"24\"/><DATE_TIME_PARAMETER Type=\"ExpireCardDate\" Name=\"Предельный срок карты:\" Year=\"2019\" Month=\"12\" Day=\"31\"/><TRANSPORT_CARD_TYPE Type=\"EP\" Full_String_Value=\"Электронный кошелек\" Code_String_Value=\"EP\"/><DISCOUNT_PERCENT Name=\"Скидка:\">20</DISCOUNT_PERCENT><BOOLEAN_PARAMETER Type=\"ActiveCard\" StringValue=\"Карта активирована\" Value=\"true\"/><NUMERIC_PARAMETER Type=\"Series\" Name=\"Серия:\" Value=\"11\"/><NUMERIC_PARAMETER Type=\"Systematic\" Name=\"№\" Value=\"536866826\"/><COMPOUND_PARAMETER Type=\"Vehicles\" SubType=\"String\" Name=\"Проезд:\"><SUB_PARAMETER Id=\"0\" Name=\"Метро\"/><SUB_PARAMETER Id=\"1\" Name=\"АВТОБУС (городской маршрут)\"/><SUB_PARAMETER Id=\"2\" Name=\"Троллейбус\"/><SUB_PARAMETER Id=\"3\" Name=\"Трамвай\"/><SUB_PARAMETER Id=\"4\" Name=\"Такси\"/><SUB_PARAMETER Id=\"5\" Name=\"АВТОБУС (пригородный/междугородный маршрут)\" /><SUB_PARAMETER Id=\"6\" Name=\"ВОДНОЕ СООБЩЕНИЕ (паромы и т.д.)\"/><SUB_PARAMETER Id=\"7\" Name=\"ПОЕЗД (пригородное сообщение)\"/></COMPOUND_PARAMETER></DISPLAY></DETAIL>",
    PAY_SUMS_TEST_RESULT: "<DETAIL ReqAction=\"User action\" RespStatus=\"Success\"><DISPLAY DisplayFrameId=\"0x123419\"><BUTTON ButtonAction=\"Cancel\" Enable=\"Yes\">Отмена</BUTTON><BUTTON ButtonAction=\"Enter\" Enable=\"Yes\">Оплата</BUTTON><AMOUNT_PARAMETER Type=\"MaxAmount\" Value=\"100.00\" Name=\"Максимальная сумма, руб.:\"/><AMOUNT_PARAMETER Type=\"MinAmount\" Value=\"0.00\" Name=\"Минимальная сумма, руб.:\"/><AMOUNT_PARAMETER Type=\"AvailableAmount\" Value=\"0.00\" Name=\"Сумма, руб:\"/><AMOUNT_PARAMETER Type=\"StepAmount\" Value=\"1.23\" Name=\"Кратность пополнения, руб.:\"/><DATE_TIME_PARAMETER Type=\"NewExpireDate\" Name=\"Действителен до:\" Year=\"2010\" Month=\"11\" Day=\"24\"/></DISPLAY></DETAIL>",
    PAY_COMMIT_TEST_RESULT: "<DETAIL ReqAction=\"User action\" RespAction=\"Waiting\" RespStatus=\"Success\" LongProcess=\"Yes\"><DISPLAY DisplayFrameId=\"0x16197197\"><MESSAGE Type=\"Table\" RowCnt=\"2\" ColCnt=\"1\"><ROW Id=\"0\" RowFont=\"Normal\" RowOption=\"RowBar\"/><ROW Id=\"0\"><COL Id=\"0\" Align=\"Center\">Ожидание карты.</COL></ROW><ROW Id=\"333\" RowOption=\"RowSpaceLine\" /><ROW Id=\"1\"><COL Id=\"0\" Align=\"Center\">Предъявите карту на запись.</COL></ROW></MESSAGE><BUTTON ButtonAction=\"Cancel\" Enable=\"Yes\">Отмена</BUTTON></DISPLAY></DETAIL>",
    PAY_COMPLETE_TEST_RESULT: "<DETAIL ReqAction=\"CallBack request\" RespStatus=\"Success\"><DISPLAY DisplayFrameId=\"0x1919\"><MESSAGE Type=\"Plain\">Карта успешно пополнена</MESSAGE><BUTTON ButtonAction=\"Enter\" Enable=\"Yes\">Завершить</BUTTON><AMOUNT_PARAMETER Type=\"AcceptedAmount\" Value=\"99.63\" Name=\"Зачисленная сумма, руб.:\"/></DISPLAY><PRINT PrintFormId=\"0x1919\" TableCount=\"6\"><PRINT_TABLE TableId=\"0\" RowCnt=\"9\" ColCnt=\"1\"><ROW Id=\"0\" RowFont=\"Normal\" RowOption=\"RowBar\"/><ROW Id=\"1\"><COL Id=\"0\" Align=\"Center\" Font=\"Normal\">1. Железный</COL></ROW><ROW Id=\"2\"><COL Id=\"0\" Align=\"Center\" Font=\"Normal\">2. ящик</COL></ROW><ROW Id=\"3\"><COL Id=\"0\" Align=\"Center\" Font=\"Normal\">3. Тестовый заголовок</COL></ROW><ROW Id=\"4\" RowFont=\"Normal\" RowOption=\"RowBar\"/><ROW Id=\"5\"><COL Id=\"0\" Align=\"Center\" Font=\"Normal\">Терминал № c0009092</COL></ROW><ROW Id=\"6\"><COL Id=\"0\" Align=\"Center\" Font=\"Normal\">04.12.2012   17:01</COL></ROW><ROW Id=\"7\"><COL Id=\"0\" Align=\"Center\" Font=\"Normal\">Квитанция № 1</COL></ROW><ROW Id=\"8\"><COL Id=\"0\" Align=\"Center\" Font=\"Normal\">Серия 10 № 698358</COL></ROW></PRINT_TABLE><PRINT_TABLE TableId=\"1\" RowCnt=\"2\" ColCnt=\"1\"><ROW Id=\"0\"><COL Id=\"0\" Align=\"Center\" Font=\"Normal\">ПОПОЛНЕНИЕ</COL></ROW><ROW Id=\"1\"><COL Id=\"0\" Align=\"Center\" Font=\"Normal\">ЭЛЕКТРОННЫЙ КОШЕЛЕК</COL></ROW></PRINT_TABLE><PRINT_TABLE TableId=\"2\" RowCnt=\"2\" ColCnt=\"2\"><ROW Id=\"0\"><COL Id=\"0\" Align=\"Left\" Font=\"Normal\">ПОПОЛНЕНИЕ:</COL><COL Id=\"1\" Align=\"Right\" Font=\"Normal\">   99.63</COL></ROW><ROW Id=\"1\"><COL Id=\"0\" Align=\"Left\" Font=\"Normal\">БАЛАНС:</COL><COL Id=\"1\" Align=\"Right\" Font=\"Normal\">199.63</COL></ROW></PRINT_TABLE><PRINT_TABLE TableId=\"3\" RowCnt=\"0\" ColCnt=\"0\"/><PRINT_TABLE TableId=\"4\" RowCnt=\"1\" ColCnt=\"2\"><ROW Id=\"0\"><COL Id=\"0\" Align=\"Left\" Font=\"Normal\">ДЕЙСТВУЕТ ДО:</COL><COL Id=\"1\" Align=\"Right\" Font=\"Normal\">06.12.2012</COL></ROW></PRINT_TABLE><PRINT_TABLE TableId=\"5\" RowCnt=\"7\" ColCnt=\"2\"><ROW Id=\"0\"><COL Id=\"0\" Align=\"Left\" Font=\"Normal\">Оператор:</COL><COL Id=\"1\" Align=\"Right\" Font=\"Normal\">99990</COL></ROW><ROW Id=\"1\" RowFont=\"Normal\" RowOption=\"RowBar\"/><ROW Id=\"2\" RowFont=\"Normal\" RowOption=\"RowSpaceLine\"/><ROW Id=\"3\" RowFont=\"Normal\" RowOption=\"RowSpaceLine\"/><ROW Id=\"4\" RowFont=\"Normal\" RowOption=\"RowSpaceLine\"/><ROW Id=\"5\" RowFont=\"Normal\" RowOption=\"RowSpaceLine\"/><ROW Id=\"6\" RowFont=\"Normal\" RowOption=\"RowSpaceLine\"/></PRINT_TABLE></PRINT><FIELDS><FIELD Name=\"Custom1\" Value=\"Value1\" /></FIELDS></DETAIL>",
    STOP_CARD_SERVICE_RESULT: "<DETAIL ReqAction=\"User action\" RespAction=\"Stop_of_card_service\"/>",
    ERROR_TEST_RESULT: "<DETAIL ReqAction=\"Idle_status_request\" RespStatus=\"Error\"><ERROR_TEXT>The SBSK is inaccessible.</ERROR_TEXT></DETAIL>",
    ERROR_STOP_CARD_SERVICE_TEST_RESULT: "<DETAIL ReqAction=\"Idle_status_request\" RespStatus=\"Error\" RespAction=\"Stop_of_card_service\"><ERROR_TEXT>The SBSK is inaccessible.</ERROR_TEXT></DETAIL>",
    sendRequest: function (detailXml) {
        this.preSendRequest();
        var self = this;
        TCCommunicator.prototype.sendRequest.apply(this, arguments);
        var detailElement = $.parseXML(detailXml).documentElement;
        var reqAction = detailElement.getAttribute("ReqAction");
        if (reqAction == "Start_of_card_service") {
            this._step = "START_SESSION";
            this.receiveResponse(this.START_SESSION_TEST_RESULT);
            /*setTimeout(function () {
            self._step = "ERROR";
            self.receiveResponse(self.ERROR_STOP_CARD_SERVICE_TEST_RESULT);
            }, 2000);*/
            setTimeout(function () {
                self._step = "CARD_AUTH";
                self.receiveResponse(self.CARD_AUTH_COMPLETE_TEST_RESULT);
            }, 10000);
        } else if (reqAction == "User action") {
            var isActionEnter = detailElement.getElementsByTagName("DISPLAY")[0].getElementsByTagName("BUTTON")[0].getAttribute("ButtonAction") == "Enter";
            var isActionCancel = detailElement.getElementsByTagName("DISPLAY")[0].getElementsByTagName("BUTTON")[0].getAttribute("ButtonAction") == "Cancel";
            if (isActionEnter) {
                if (this._step == "CARD_AUTH" && isActionEnter) {
                    setTimeout(function () {
                        self._step = "REQUIRED_TYPE_AMOUNT";
                        self.receiveResponse(self.PAY_SUMS_TEST_RESULT);
                    }, 2000);
                } else if (this._step == "REQUIRED_TYPE_AMOUNT" && isActionEnter) {
                    setTimeout(function () {
                        self._step = "PAY_COMMIT";
                        self.receiveResponse(self.PAY_COMMIT_TEST_RESULT);
                        setTimeout(function () {
                            self._step = "SUCCESS";
                            self.receiveResponse(self.PAY_COMPLETE_TEST_RESULT);
                        }, 2000);
                    }, 2000);
                } else if (this._step == "SUCCESS" && isActionEnter) {
                    setTimeout(function () {
                        self._step = "ACCEPT_SUCCESS";
                        self.receiveResponse(self.STOP_CARD_SERVICE_RESULT);
                    }, 2000);
                }
            } else {
                setTimeout(function () {
                    self._step = "CANCEL";
                    self.receiveResponse(self.STOP_CARD_SERVICE_RESULT);
                }, 2000);
            }
        }
    }
});