﻿function TCCommunicator() { };

TCCommunicator.prototype = {

    preSendRequest: function () {
        //this.initTimeoutObserver();
    },

    sendRequest: function (detailXml) {
        this.preSendRequest();
        this.onRequestSent(detailXml);
    },
    preReceiveResponse: function () {
        //this.releaseTimeoutObserver();
    },
    receiveResponse: function (detailXml) {
        this.preReceiveResponse();
        this.onResponseReceived(detailXml);
    },

    triggerTimeout: function () {
        if (this.onTimeout != null) {
            this.onTimeout();
        }
    },

    onRequestSent: function (requestXml) { },
    onResponseReceived: function (responseXml) { },
    onTimeout: function () { }
};