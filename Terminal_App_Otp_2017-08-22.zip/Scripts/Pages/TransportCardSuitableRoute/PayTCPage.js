﻿/// <reference path="~/Scripts/Payment/FetchPaymentReceiptLogic.js" />

function PayTCPage(args) {
    ClientSidePage.apply(this, arguments);
    var self = this,
        tcManager = args.tcManager,
        operatorManager = args.operatorManager;

    this._tcManager = tcManager;
    this._operatorManager = operatorManager;
    this._chequeManager = args.chequeManager;
    
    this._forceCancel = false;

    this._pinPadListener = {
        pinPadAcceptPressed: function (args) {
            self.pinPadAcceptPressed();
        },
        pinPadCancelPressed: function () {
            self.pinPadCancelPressed();
        },
        pinPadDigitPressed: function(args) {
            self.pinPadDigitPressed(args);
        },
        pinPadCorrectionPressed: function() {
            self.pinPadCorrectionPressed();
        }
    };
};

extend(PayTCPage, ClientSidePage, {
    _urlTransformDisplayFrameXml: null,
    _currentTCDisplayFrameViewModel: null,
    _tcManager: null,
    _cardDataMap: null,

    $tcContainer: null,

    $dlgBillValidator: null,
    $bDlgBillValidatorOK: null,
    $bDlgBillValidatorCancel: null,
    $lDlgBillValidatorAmount: null,
    $lDlgBillValidatorPayAmount: null,
    $lDlgBillValidatorModuleAmount: null,
    $lDlgBillValidatorStepAmount: null,
    $lDlgBillValidatorMinAmount: null,
    $lDlgBillValidatorMaxAmount: null,
    $dlgBillValidatorModuloAmountContainer: null,
    $dlgBillValidatorStepAmountContainer: null,

    $dlgBillValidatorNotOperable: null,
    $bDlgBillValidatorNotOperableOK: null,

    $dlgCardSum: null,
    $bDlgCardSumOK: null,
    $bDlgCardSumCancel: null,
    $tbCardSum: null,
    $hfCardSum: null,

    cardSumFieldManager: null,

    $dlgError: null,
    $lDlgErrorError: null,
    $bDlgErrorCancel: null,

    $dlgTakeCardAlert: null,
    $bDlgTakeCardAlertOK: null,

    _billValidator: null,

    _isPaySuccessful: false,
    _isPayCompleted: false,

    _amount: 0,
    _billValidatorAmount: 0,
    _changeSumAmount: 0,
    _payAmount: 0,
    _moduloAmount: 0,

    _receipt: null,

    createCardSumFieldManager: function (limit) {
        var self = this;
        cardSumField.Description = cardSumField.Description
            .replace("#MIN_AMOUNT#", this.getMinAmount())
            .replace("#MAX_AMOUNT#", this.getMaxAmount())
            .replace("#STEP_AMOUNT#", this.getStepAmount());

        this.$dlgCardSum.find(".th-field .th-info").html(cardSumField.Description.replace("[b]", "<strong>").replace("[/b]", "</strong>"));
        var initData = {
            textBox: this.$tbCardSum.get(0),
            fieldElement: this.$hfCardSum.get(0),
            type: cardSumField.Type,
            limit: limit,
            decimalSeparator: FS.TerminalUI.Settings.numberDecimalSeparator,
            oncomplete: function () {
                if (!isNaN(fieldManager.getFloatValue()) && fieldManager.getFloatValue() > 0) self.showElement(self.$bDlgCardSumOK);
            },
            onincomplete: function () {
                self.hideElement(self.$bDlgCardSumOK);
            }
        };
        var fieldManager = this.cardSumFieldManager = new CurrencyFractionalPartAutoHideFieldManager();
        fieldManager.init(initData);
        return fieldManager;
    },

    pinPadCancelPressed: function () {
        if (this._tcManager.busy || this.busy) return;
        if (this.dlgManager.isShown(this.$dlgBillValidator)) {
            if (!this.isHidden(this.$bDlgBillValidatorCancel)) {
                this.$bDlgBillValidatorCancel.click();
            }
        } else if (this.dlgManager.isShown(this.$dlgError)) {
            this.$bDlgErrorCancel.click();
        } else if (this.dlgManager.isShown(this.$dlgCardSum)) {
            this.$bDlgCardSumCancel.click();
        } else {
            var $btnNavCancel = $(".btn-nav-cancel", this.$tcContainer);
            if ($btnNavCancel.length && !this.isHidden($btnNavCancel)) {
                this.forceTCManagerCancel();
            }
        }
    },
    pinPadAcceptPressed: function () {
        if (this._tcManager.busy || this.busy) return;
        if (this.dlgManager.isShown(this.$dlgBillValidator)) {
            if (!this.isHidden(this.$bDlgBillValidatorOK)) {
                this.$bDlgBillValidatorOK.click();
            }
        } else if (this.dlgManager.isShown(this.$dlgBillValidatorNotOperable)) {
            this.$bDlgBillValidatorNotOperableOK.click();
        } else if (this.dlgManager.isShown(this.$dlgTakeCardAlert)) {
            this.$bDlgTakeCardAlertOK.click();
        } else if (this.dlgManager.isShown(this.$dlgCardSum)) {
            if (!this.isHidden(this.$bDlgCardSumOK)) {
                this.$bDlgCardSumOK.click();
            }
        } else if (DlgMsgManager.findDlg("dlgAlertCardSumChanged") != null && DlgMsgManager.findDlg("dlgAlertCardSumChanged").isShown()) {
            DlgMsgManager.findDlg("dlgAlertCardSumChanged").triggerBtnClick("OK");
        } else {
            var $btnNavOK = $(".btn-nav-ok, .btn-nav-gopay", this.$tcContainer);
            if ($btnNavOK.length && !this.isHidden($btnNavOK)) {
                $btnNavOK.click();
            }
        }
    },

    pinPadCorrectionPressed: function () {
        if (this.dlgManager.isShown(this.$dlgCardSum)) {
            this.cardSumFieldManager.removeLastLetter();
        }
    },

    pinPadDigitPressed: function (args) {
        if (this.dlgManager.isShown(this.$dlgCardSum)) {
            this.cardSumFieldManager.appendLetter(args.letter);
        }
    },

    init: function (settings) {
        ClientSidePage.prototype.init.apply(this, arguments);
        var self = this;
        if (settings.hasOwnProperty("urlTransformDisplayFrameXml")) this._urlTransformDisplayFrameXml = settings.urlTransformDisplayFrameXml;
        this._cardDataMap = {};
        this.initTCManager();
        if (this.isCardAvailable()) {
        } else {
            this.initBillValidator();
        }
        this.initPinPad();
        this.smartClientManager.addHandler("transportCardSuitableRouteCallback", function (paramName, paramValue) {
            if (paramName == "DeviceState" && paramValue == "NotOperable") {
                self.hideWaitDlg();
                self.showDlgErrorWithGenericErrorMessage(true);
            }
        });

        if (CabinetManager.isCabinetSession()) {
            CabinetManager.addCabinetOperatorAsync(operatorInstance.ID, operatorFieldMap);
        }
    },
    initPinPad: function () {
        var smartClientManager = this.smartClientManager;
        smartClientManager.preventPinPadCancel();
        smartClientManager.openPinPad();
        smartClientManager.addListener(this._pinPadListener);
    },
    initBillValidator: function () {
        var self = this;
        var bv = this._billValidator = new SmartClientBillValidatorImpl(this.smartClientManager);
        bv.onBillExceeded = this.createEventHandler(self.billValidatorBillExceededHandler);
        bv.onInvalidBill = this.createEventHandler(self.billValidatorInvalidBillHandler);
        bv.onStateChanged = this.createEventHandler(self.billValidatorStateChangedHandler);
        bv.onSumChanged = this.createEventHandler(self.billValidatorSumChangedHandler);
        bv.onBillPushed = this.createEventHandler(self.billValidatorBillPushedHandler);
        bv.state();
    },
    billValidatorBillExceededHandler: function (billValue) {
        if (TerminalUI.UISettingsMap["SHOW_DLG_MAX_SUM_EXCEEDED"] == "1") {
            this.showDlgMaxSumExceeded();
        }
        var $bDlgBillValidator = this.getShownDlgBillValidatorButton();
        $bDlgBillValidator.removeClass("hidden");
    },

    billValidatorInvalidBillHandler: function () {
        DlgManager.showDlgInvalidBill(this.$dlgInvalidBill);
    },

    pollBillValidatorStateAsync: function (callback) {
        var self = this,
                    smartClientManager = self.smartClientManager,
                    loggingService = self.loggingService;
        loggingService.trace("Creating a handler to listen for the BillValidator state...");
        var handler = function (state) {
            loggingService.trace("The Bill Validator state is %1.", state);
            if (typeof (callback) == "function") callback(state);
            smartClientManager.removeHandler("billValidatorState", handler);
        };
        loggingService.trace("The handler to listen for the BillValidator state has been created.");
        loggingService.trace("Adding the handler to listen for the BillValidator state...");
        smartClientManager.addHandler("billValidatorState", handler);
        loggingService.trace("The handler to listen for the BillValidator state has been added.");
        loggingService.trace("Polling the BillValidator to get state...");
        smartClientManager.stateBillValidator();
        loggingService.trace("The Bill Validator has been polled to get state.");
    },
    billValidatorPollDescriptionChangedHandler: function (pollDescription) {
        if (this.dlgManager.isShown(this.$dlgBillValidator)) {
            var $bDlgBillValidator = this.getShownDlgBillValidatorButton();
            if (pollDescription == "Accepting") {
                $bDlgBillValidator.addClass("hidden");
            } else if (pollDescription == "Idling") {
                if ($bDlgBillValidator.hasClass("hidden")) {
                    $bDlgBillValidator.removeClass("hidden");
                }
            }
        }
    },
    getShownDlgBillValidatorButton: function () {
        return this.$bDlgBillValidatorOK.hasClass("th-hidden") ? this.$bDlgBillValidatorCancel : this.$bDlgBillValidatorOK;
    },
    billValidatorStateChangedHandler: function (state) {
    },
    billValidatorSumChangedHandler: function (sum) {
    },
    billValidatorBillPushedHandler: function (bill) {
        var self = this;
        this.smartClientManager.denyIdleTimeoutHandler();
        this._billValidatorAmount += bill;
        var nextAmount = self._amount + bill;
        var maxAmount = self.getMaxAmount();
        var postActions = function () {
            self.handleAmount(nextAmount);
            self.updateDlgBillValidatorAmount();
        };
        if (nextAmount >= maxAmount && TerminalUI.UISettingsMap["BILL_VALIDATOR_AUTO_CLOSE_ENABLED"] == "1") {
            self.verifyBillValidatorClosed(function () {
                if (nextAmount > maxAmount && TerminalUI.UISettingsMap["SHOW_DLG_MAX_SUM_EXCEEDED"] == "1") {
                    DlgManager.showDlg(self.$dlgMaxSumExceeded);
                }
                postActions();
            });
        } else {
            postActions();
        }
    },
    handleAmount: function (nextAmount) {
        var maxAmount = this.getMaxAmount();
        if (nextAmount > maxAmount) {
            var changeSumAddon = nextAmount - maxAmount;
            ChangeSumManager.Instance.incrementChangeSumAsync(changeSumAddon);
            this._amount = maxAmount;
        } else {
            this._amount = nextAmount;
        }
    },
    initTCManager: function () {
        var self = this,
                    manager = this._tcManager;
        manager.onDisplayUpdated = function (displayXml) { self.displayUpdatedEventHandler(displayXml) },
                manager.onPrintCheque = function (printXml) { self.printChequeHandler(printXml) };
        manager.onStopCardService = this.createEventHandler(this.stopCardServiceHandler);
        manager.onBusy = this.createEventHandler(this.tcManagerBusyHandler);
        manager.onReady = this.createEventHandler(this.tcManagerReadyHandler);
        manager.onError = this.createEventHandler(this.tcManagerErrorHandler);
        manager.onSessionBegin = this.createEventHandler(this.tcManagerSessionBeginHandler);
        manager.onFieldsAvailable = this.createEventHandler(this.tcManagerFieldsAvailableHandler);
    },
    tcManagerFieldsAvailableHandler: function (fields) {
        for (var i = 0; i < fields.length; i++) {
            var field = fields[i];
            this._operatorManager.setFieldByComment(field.name, field.value);
        }
    },
    tcManagerSessionBeginHandler: function () {
        this.smartClientManager.denyIdleTimeoutHandler();
    },
    tcManagerErrorHandler: function (errorText, stopCardService) {
        this.loggingService.fatal("An error has occurred while paying a transpord card! Error text is %1.", errorText);
        this.showDlgErrorWithGenericErrorMessage(stopCardService);
    },
    tcManagerBusyHandler: function () {
        this.showWaitDlg();
    },
    tcManagerReadyHandler: function () {
        this.hideWaitDlg();
    },
    stopCardServiceHandler: function () {
        this.showWaitDlg();
        this.navigateAway();
    },

    navigateAway: function () {
        var loggingService = TerminalUI.loggingService;
        var scm = SmartClientManager;

        loggingService.info("Navigating to the Start page due to the navigateAway method was invoked...");
        scm.writeStateToLog("LOG_MSG_START_PAGE_NAVIGATING_TRANSPORT_CARD_SUIT_ROUTE_NAVIGATE_AWAY_INVOKED");
        ClientSidePage.layoutPage.navigateToMainMenu();
    },

    printChequeHandler: function (printXml, callback) {
        var self = this;
        whenCondition(function () { return self._receipt != null && self._isPaySuccessful === true }, function () { self.smartClientManager.printText(self._receipt, self._amountAll, callback); });
    },

    displayUpdatedEventHandler: function (displayXml) {
        var self = this,
                    displayFrameViewModel = new TCDisplayFrameViewModel(this._tcManager, displayXml);
        displayFrameViewModel.onFieldMapChanged = this.createEventHandler(this.fieldMapChangedHandler);
        displayFrameViewModel.onAmountAccepted = this.createEventHandler(this.amountAcceptedHandler);
        this._currentTCDisplayFrameViewModel = displayFrameViewModel;
        this.showDisplayFrameXmlAsync(displayXml, this.createEventHandler(this.displayFrameShownHandler));
    },
    fieldMapChangedHandler: function (fieldMap, fieldName, fieldValue) {
        this._cardDataMap[fieldName] = fieldValue;
        this._operatorManager.setFieldByComment(fieldName, fieldValue);
    },
    displayFrameShownHandler: function () {
        var self = this;
        if (this._currentTCDisplayFrameViewModel.isRequiredTypeAmount()) {
            this._stepAmount = this.getStepAmount();
            var $buttonEnter = $(".Enter", this.$tcContainer);
            $buttonEnter.attr("onclick", "");
            $buttonEnter.click(function () {
                if (self.isCardAvailable()) {
                    self.showDlgCardSum();
                } else {
                    //Activate the bill validator                    
                    self.initAndShowDlgBillValidator();
                }
            });
        }
    },

    load: function () {
        ClientSidePage.prototype.load.apply(this, arguments);
        var self = this;
        this.$tcContainer = $("#tcContainer");

        var $dlgMaxSumExceeded = this.$dlgMaxSumExceeded = $("#dlgMaxSumExceeded");
        var $btnDlgMaxSumExceededOk = this.$btnDlgMaxSumExceededOk = $("#btnDlgMaxSumExceededOk");

        $btnDlgMaxSumExceededOk.click(function () {
            DlgManager.hideDlg($dlgMaxSumExceeded);
        });

        var $dlgInvalidBill = this.$dlgInvalidBill = $("#dlgInvalidBill");
        var $btnDlgInvalidBill = this.$btnDlgInvalidBill = $("#btnDlgInvalidBillOk");

        $btnDlgInvalidBill.click(function () {
            DlgManager.hideDlg($dlgInvalidBill);
        });

        this.$dlgBillValidator = $("#dlgBillValidator");
        this.$bDlgBillValidatorOK = $("#bDlgBillValidatorOK");
        this.$bDlgBillValidatorCancel = $("#bDlgBillValidatorCancel");
        this.$lDlgBillValidatorAmount = $("#lDlgBillValidatorAmount");
        this.$lDlgBillValidatorPayAmount = $("#lDlgBillValidatorPayAmount");
        this.$lDlgBillValidatorModuloAmount = $("#lDlgBillValidatorModuloAmount");
        this.$lDlgBillValidatorStepAmount = $("#lDlgBillValidatorStepAmount");
        this.$lDlgBillValidatorMinAmount = $("#lDlgBillValidatorMinAmount");
        this.$lDlgBillValidatorMaxAmount = $("#lDlgBillValidatorMaxAmount");

        this.$bDlgBillValidatorOK.click(this.createEventHandler(this.bDlgBillValidatorOKClickHandler));
        this.$bDlgBillValidatorCancel.click(this.createEventHandler(this.bDlgBillValidatorCancelClickHandler));

        this.$dlgBillValidatorStepAmountContainer = $("#dlgBillValidatorStepAmountContainer");
        this.$dlgBillValidatorModuloAmountContainer = $("#dlgBillValidatorModuloAmountContainer");

        this.$dlgBillValidatorNotOperable = $("#dlgBillValidatorNotOperable");
        this.$bDlgBillValidatorNotOperableOK = $("#bDlgBillValidatorNotOperableOK");
        this.$bDlgBillValidatorNotOperableOK.click(this.createEventHandler(this.bDlgBillValidatorNotOperableOKClickHandler));

        this.$dlgCardSum = $("#dlgCardSum");
        this.$bDlgCardSumOK = $("#bDlgCardSumOK");
        this.$bDlgCardSumCancel = $("#bDlgCardSumCancel");
        this.$tbCardSum = $("#tbCardSum");
        this.$hfCardSum = $("#hfCardSum");

        this.$bDlgCardSumOK.click(this.createEventHandler(this.bDlgCardSumOKClickHandler));
        this.$bDlgCardSumCancel.click(this.createEventHandler(this.bDlgCardSumCancelClickHandler));

        this.$dlgError = $("#dlgError");
        this.$lDlgErrorError = $("#lDlgErrorError");
        this.$bDlgErrorCancel = $("#bDlgErrorCancel").click(this.createEventHandler(this.bDlgErrorCancelClickHandler));

        this.$dlgTakeCardAlert = $("#dlgTakeCardAlert");
        var $bDlgTakeCardAlertOK = this.$bDlgTakeCardAlertOK = $("#bDlgTakeCardAlertOK");
        $bDlgTakeCardAlertOK.click(this.createEventHandler(this.bDlgTakeCardAlertOKClickHandler));

        if (this._billValidator != null) {
            this._billValidator.onPollDescriptionChanged = this.createEventHandler(self.billValidatorPollDescriptionChangedHandler);

            this.showWaitDlg();
            this.pollBillValidatorStateAsync(function (state) {
                if (state == "NotOperable") {
                    self.hideWaitDlg();
                    self.showDlgBillValidatorNotOperable();
                } else {
                    self.hideWaitDlg();
                    self._tcManager.startSession();
                }
            });
        } else {
            self._tcManager.startSession();
        }
    },

    showDlgMaxSumExceeded: function () {
        DlgManager.showDlg(this.$dlgMaxSumExceeded);
    },

    bDlgCardSumOKClickHandler: function () {
        var self = this,
            cardSum = this.cardSumFieldManager.getFloatValue();

        this._amount = cardSum;
        var payAmount = this.computeAndGetPayAmount();
        this._amount = payAmount;

        this.dlgManager.hideDlg(this.$dlgCardSum);
        if (payAmount < cardSum) {
            this._amount = payAmount;
            var dlgAlertCardSumChanged = DlgMsgManager.findDlg("dlgAlertCardSumChanged");
            var dlgMsgText = dlgAlertCardSumChanged.getMsgText();
            dlgMsgText = dlgMsgText
                .replace("#CARD_SUM#", cardSum)
                .replace("#STEP_AMOUNT#", this.getStepAmount())
                .replace("#PAY_AMOUNT#", payAmount);
            dlgAlertCardSumChanged.setMsgText(dlgMsgText);
            dlgAlertCardSumChanged.show();
        } else {
            self.processUserAmount(payAmount);
        }
    },

    processUserAmount: function (amount) {
        var self = this;
        var displayFrameId = this._currentTCDisplayFrameViewModel.getDisplayFrameId();
        self._tcManager.processUserAction(displayFrameId, "Enter", "Pressed", amount);
    },

    bDlgAlertCardSumChangedClickHandler: function () {
        var self = this;
        DlgMsgManager.findDlg("dlgAlertCardSumChanged").hide();
        self.processUserAmount(this._amount);
    },

    bDlgCardSumCancelClickHandler: function () {
        this.dlgManager.hideDlg(this.$dlgCardSum);
        this.forceTCManagerCancel();
    },

    bDlgTakeCardAlertOKClickHandler: function () {
        this.hideDlgTakeCardAlert();
    },

    showDlgCardSum: function () {
        var cardSumLimit = { Min: this.getMinAmount(), Max: this.getMaxAmount() };
        this.cardSumFieldManager = this.createCardSumFieldManager(cardSumLimit);
        this.dlgManager.showDlg(this.$dlgCardSum);
    },

    showDlgTakeCardAlert: function () {
        this.dlgManager.showDlg(this.$dlgTakeCardAlert);
    },
    hideDlgTakeCardAlert: function () {
        this.dlgManager.hideDlg(this.$dlgTakeCardAlert);
    },
    releasePinPad: function () {
        this.smartClientManager.closePinPad();
        this.smartClientManager.removeListener(this._pinPadListener);
    },
    unload: function () {
        var self = this;
        ClientSidePage.prototype.unload.apply(this, arguments);
        this.verifyBillValidatorClosed(function () {
            self.releasePinPad();
            var loggingService = TerminalUI.loggingService;
            loggingService.trace("Is pay successful: %1", self._isPaySuccessful);
            if (!self._isPaySuccessful) {
                var initialChangeSumAmount = self._changeSumAmount;
                var allMoneyAmount = initialChangeSumAmount + self._billValidatorAmount;
                var saveMoneyToChangeSum = function (customChangeSumAmount) {
                    var changeSum = typeof (customChangeSumAmount) != "undefined" ? customChangeSumAmount : allMoneyAmount;
                    loggingService.trace("Saving changeSum=%1 on completed payment...", changeSum);
                    if (changeSum > 0) {
                        ChangeSumManager.Instance.pushChangeSumAsync(changeSum);
                    }
                };
                if (self._isPayCompleted && TerminalUI.UISettingsMap["SAVE_MONEY_TO_CHANGESUM_ON_FAILED_PAYMENT"] == "0") {
                    saveMoneyToChangeSum(initialChangeSumAmount);
                } else {
                    saveMoneyToChangeSum();
                }
            }
        });
    },
    bDlgErrorCancelClickHandler: function () {
        this.hideDlgError();
        if (this.$bDlgErrorCancel.data("stopCardService") == true) {
            this.showWaitDlg();
            this.navigateAway();
        }
    },

    bDlgBillValidatorNotOperableOKClickHandler: function () {
        this.hideDlgBillValidatorNotOperable();
        this.showWaitDlg();
        var loggingService = TerminalUI.loggingService;
        var scm = SmartClientManager;
        loggingService.info("Navigating to the Start page due to the dlg bill validator not operable button OK was clicked...");
        scm.writeStateToLog("LOG_MSG_START_PAGE_NAVIGATING_BTN_DLG_BILL_VALIDATOR_NOT_OPERABLE_OK_CLICK");
        ClientSidePage.layoutPage.navigateToMainMenu();
    },

    bDlgBillValidatorOKClickHandler: function () {
        var displayFrameId = this._currentTCDisplayFrameViewModel.getDisplayFrameId(),
                    self = this,
                    availableAmount = this._amount;
        self.showWaitDlg();
        this.verifyBillValidatorClosed(function () {
            self.hideWaitDlg();
            self.hideDlgBillValidator();
            self._tcManager.processUserAction(displayFrameId, "Enter", "Pressed", availableAmount);
        });
    },
    bDlgBillValidatorCancelClickHandler: function () {
        var displayFrameId = this._currentTCDisplayFrameViewModel.getDisplayFrameId();
        var self = this;
        self.showWaitDlg();
        this.verifyBillValidatorClosed(function () {
            self.hideWaitDlg();
            self.hideDlgBillValidator();
            self.forceTCManagerCancel();
        });
    },
    forceTCManagerCancel: function () {
        var displayFrameId = this._currentTCDisplayFrameViewModel.getDisplayFrameId();
        this._tcManager.processUserAction(displayFrameId, "Cancel", "Pressed");
    },
    amountAcceptedHandler: function (acceptedAmount) {
        var self = this;
        this.showWaitDlg();
        this.initTimeoutAction();
        this.payOperatorAsync(function (resultCode) {
            var postPayDone = function () {
                self.hideWaitDlg();
                self.showDlgTakeCardAlert();
            };
            var incrementChangeSumByModuloAndPostPayDone = function () {
                ChangeSumManager.Instance.incrementChangeSumAsync(self._moduloAmount, function ()
                {
                    postPayDone();
                });
            };
            if (self._moduloAmount > 0) {
                incrementChangeSumByModuloAndPostPayDone();
            } else {
                postPayDone();
            }
        });
    },
    initTimeoutAction: function () {
        var self = this,
            smartClientManager = this.smartClientManager;
        smartClientManager.addHandler("screenPanelCallbackForced", function () {
            var displayFrameId = self._currentTCDisplayFrameViewModel.getDisplayFrameId();
            self._tcManager.processUserAction(displayFrameId, "Enter", "Pressed");
        });
    },
    payOperatorAsync: function (callback) {
        var self = this,
                    operatorInstance = this._operatorManager.getOperatorInstance(),
                    operatorId = operatorInstance.ID,
                    operatorName = operatorInstance.Name,
                    amount = this._payAmount,
                    payAmount = this._payAmount,
                    date = new Date(),
                    balance = this.getCardBalance() + payAmount,
                    balanceAsString = balance.toFixed(2);
        var entireAmount = payAmount;

        this._operatorManager.setFieldByComment("CardBalance", balanceAsString);
        this._operatorManager.setFieldByComment("ExpireDate", this._cardDataMap["NewExpireDate"]);

        var paymentFailed = function (chequeNum, reasonMsg, specifiedErrorMsg) {
            chequeNum = chequeNum || "";
            reasonMsg = reasonMsg || "";
            specifiedErrorMsg = specifiedErrorMsg || "";
            SmartClientManager.writeStateErrorToLog("Платеж для оператора " + operatorId + " на сумму " + entireAmount + " с номером чека " + chequeNum + " на дату и время " + formatDate(date, "yyyy-MM-dd HH:mm:ss") + " не выполнен по причине: " + reasonMsg);
            var showPayError = function () {
                self.hideWaitDlg();
                if (specifiedErrorMsg) {
                    self.showDlgErrorAndStopCardService(specifiedErrorMsg);
                } else {
                    self.showDlgErrorWithGenericErrorMessage(true);
                }
            };
            self._chequeManager.fetchPaymentErrorReceipt(operatorId, date, entireAmount, function (fetchPaymentErrorReceiptArgs) {
                if (fetchPaymentErrorReceiptArgs.error) {
                    SmartClientManager.writeStateErrorToLog("Не удалось сформировать чек об ошибке платежа!");
                    showPayError();
                } else {
                    SmartClientManager.printText(fetchPaymentErrorReceiptArgs.receiptText, self._amountAll, function () {
                        showPayError();
                    });
                }
            });
        };

        var fieldMap = this._operatorManager.getFieldMap(),
                    postPayComplete = function (resultCode, chequeNum, responseMap) {

                        var postErrorHandler = function (reasonMsg, specifiedErrorMsg) {
                            reasonMsg = reasonMsg || "";
                            specifiedErrorMsg = specifiedErrorMsg || "";
                            paymentFailed(chequeNum, reasonMsg, specifiedErrorMsg);
                        };

                        self._amountAll = amount;

                        self._isPayCompleted = true;
                        if (resultCode == 0) {

                            var postSuccessHandler = function () {
                                var fetchReceiptLogic = new FetchPaymentReceiptLogic(self._chequeManager);
                                fetchReceiptLogic.fetchReceiptAsync(operatorInstance, fieldMap, amount, entireAmount, 0, date, chequeNum, function (resultCtx) {
                                    if (resultCtx.error === true) {
                                        self.loggingService.error("Failed to fetch a receipt text!");
                                    } else {
                                        self._receipt = resultCtx.receiptText;
                                    }
                                    self._isPaySuccessful = true;
                                    if (callback) callback();
                                });
                            };
                            if (typeof (CARD_AVAILABLE) != "undefined" && CARD_AVAILABLE == true) {

                                var invoiceXml = responseMap["ANSWER_DATA"];
                                CardManager.parseTransactionRequestXml(invoiceXml, function (invoiceMap) {
                                    var responseCode = invoiceMap["RESPONSE_CODE"];
                                    if (responseCode == "00") {
                                        postSuccessHandler();
                                    } else {
                                        var cardResponseCodeInfo = FS.TerminalUI.CardAuthResponseCodesMap[responseCode];
                                        var reasonMsg = "Получен авторизационный код ошибки платежа по банковской карте = " + responseCode;
                                        var errorMsg = "";
                                        if (cardResponseCodeInfo != null) {
                                            errorMsg = CardOperationFailedGeneralMsgTemplate.replace("{0}", cardResponseCodeInfo.UserMessage);
                                            reasonMsg += ". " + errorMsg;
                                        }
                                        postErrorHandler(reasonMsg, errorMsg);
                                    }
                                });
                            } else {
                                postSuccessHandler();
                            }
                        } else {
                            postErrorHandler("Получен код ошибки от шлюза = " + resultCode, "");
                        }
                    };

        this._chequeManager.fetchNextChequeNumAsync(function (chequeNum) {
            if (chequeNum.error) {
                paymentFailed("", "Ошибка при формировании следующего номера чека");
            } else {
                if (isCabinetSession) {
                    var cabinetId = cabinetInfo.ID;
                    var userId = cabinetInfo.UserID;
                    payOperatorCabinetAsync(operatorId, operatorName, amount, payAmount, date, chequeNum, fieldMap, cabinetId, userId, function (result, responseMap) {
                        postPayComplete(result, chequeNum, responseMap);
                    });
                } else {
                    payOperatorAsync(operatorId, operatorName, amount, payAmount, date, chequeNum, fieldMap, function (result, responseMap) {
                        postPayComplete(result, chequeNum, responseMap);
                    });
                }
            }
        });
    },
    verifyBillValidatorClosed: function (callback) {
        var triggerCallback = function () {
            if (callback) callback();
        };
        if (this._billValidator != null && this._billValidator.isOpened()) {
            this._billValidator.close(function () { triggerCallback() });
        } else {
            triggerCallback();
        }
    },
    transformDisplayFrameToHtmlAsync: function (displayFrameXml, callback) {
        var self = this;
        this.ajaxService.postJSON(this._urlTransformDisplayFrameXml, { displayFrameXml: displayFrameXml }, function (displayFrameHtml) {
            if (callback) callback(displayFrameHtml);
        });
    },
    showDisplayFrameHtml: function (displayFrameHtml) {
        this.$tcContainer.html(displayFrameHtml);
    },
    showDisplayFrameXmlAsync: function (displayFrameXml, callback) {
        var self = this;
        this.transformDisplayFrameToHtmlAsync(displayFrameXml, function (displayFrameHtml) {
            self.showDisplayFrameHtml(displayFrameHtml);
            if (callback) callback(displayFrameHtml);
        });
    },
    getStepAmount: function () {
        return this._cardDataMap.hasOwnProperty("StepAmount") ? parseFloat(this._cardDataMap["StepAmount"]) : 0;
    },
    getMinAmount: function () {
        return this._cardDataMap.hasOwnProperty("MinAmount") ? parseFloat(this._cardDataMap["MinAmount"]) : null;
    },
    getMaxAmount: function () {
        var maxSum = 0;
        var suitableRouteCardMaxAmount = this._cardDataMap.hasOwnProperty("MaxAmount") ? parseFloat(this._cardDataMap["MaxAmount"]) : null;
        if (suitableRouteCardMaxAmount != null) {
            maxSum = suitableRouteCardMaxAmount;
        }
        if (FS.TerminalUI.UISettingsMap["PAYMENT_GLOBAL_MAX_SUM_ENABLED"] == "1" && maxSum > FS.TerminalUI.UISettingsMap["PAYMENT_GLOBAL_MAX_SUM"]) {
            maxSum = parseFloat(FS.TerminalUI.UISettingsMap["PAYMENT_GLOBAL_MAX_SUM"]);
        }
        return maxSum;
    },
    getCardBalance: function () { return parseFloat(this._cardDataMap["CardBalance"]) },
    initAndShowDlgBillValidator: function () {
        var self = this,
                    changeSum = ChangeSumManager.Instance.getChangeSum(),
                    stepAmount = this.getStepAmount(),
                    amount = 0,
                    payAmount = 0,
                    moduloAmount = 0,
                    minAmount = this.getMinAmount(),
                    maxAmount = this.getMaxAmount(),
                    postInit = function () {
                        var neededCashAmount = maxAmount - self._amount;
                        var cashLimit = maxAmount;
                        if (operatorInstance.RestrictionsInstance != null && TerminalUI.UISettingsMap["BILL_VALIDATOR_MAX_SUM_BILL_MAX_SUM_MODE"] == "MaxSum") {
                            cashLimit = operatorInstance.RestrictionsInstance.Max;
                        }
                        var initialSum = self._amount;
                        cashLimit = cashLimit - initialSum;
                        if (cashLimit < 0) cashLimit = 0;

                        self._billValidator.open(cashLimit);

                        if (stepAmount == 0) {
                            self.$dlgBillValidator.addClass("step-amount-less");
                        }
                        self.$lDlgBillValidatorMinAmount.text(minAmount.toFixed(2));
                        self.$lDlgBillValidatorMaxAmount.text(maxAmount.toFixed(2));
                        self.updateDlgBillValidatorAmount();
                        self.dlgManager.showDlg(self.$dlgBillValidator);
                    };
        this._amount = 0;
        this._stepAmount = stepAmount;
        if (ChangeSumManager.Instance.isChangeSumAvailable())
        {
            this._changeSumAmount = changeSum;
            amount = changeSum;
            this.showWaitDlg();
            ChangeSumManager.Instance.updateChangeSumAsync(0, function ()
            {
                self.hideWaitDlg();
                setTimeout(function () {
                    self.handleAmount(amount);
                    postInit();
                }, 0);
            });
        } else {
            postInit();
        }

    },
    computeAndGetPayAmount: function () {
        if (this._amount == 0 || this._stepAmount == 0 || this._stepAmount == 1) {
            this._payAmount = this._amount;
        } else {
            this._payAmount = Math.floor(this._amount / this._stepAmount) * this._stepAmount;
        }
        return this._payAmount;
    },
    updateDlgBillValidatorAmount: function () {
        var amount = this._amount,
                    stepAmount = this.getStepAmount(),
                    payAmount = this.computeAndGetPayAmount(),
                    moduloAmount = amount - payAmount;
        this._payAmount = payAmount;
        this._moduloAmount = moduloAmount;

        if (stepAmount == 0) {
            this.$dlgBillValidatorModuloAmountContainer.addClass("hidden");
            this.$dlgBillValidatorStepAmountContainer.addClass("hidden");
        }

        this.$lDlgBillValidatorAmount.text(amount.toFixed(2));
        this.$lDlgBillValidatorPayAmount.text(payAmount.toFixed(2));
        this.$lDlgBillValidatorModuloAmount.text(moduloAmount.toFixed(2));
        this.$lDlgBillValidatorStepAmount.text(stepAmount);

        if (this._amount > 0 && this._amount >= this.getMinAmount() && this._payAmount > 0 && this.$bDlgBillValidatorOK.hasClass("th-hidden")) {
            this.$bDlgBillValidatorCancel.addClass("th-hidden");
            this.$bDlgBillValidatorOK.removeClass("th-hidden");
        }
    },
    hideDlgBillValidator: function () {
        this.dlgManager.hideDlg(this.$dlgBillValidator);
    },
    showDlgErrorWithGenericErrorMessage: function (stopCardService) {
        var genericErrorMsg = GENERAL_ERROR_MESSAGE;
        this.$bDlgErrorCancel.data("stopCardService", stopCardService);
        this.showDlgError(genericErrorMsg);
    },
    showDlgErrorAndStopCardService: function (errorMsg) {
        this.showDlgError(errorMsg);
        this.$bDlgErrorCancel.data("stopCardService", true);
    },
    showDlgError: function (msg) {
        this.$lDlgErrorError.text(msg);
        this.dlgManager.showDlg(this.$dlgError);
    },
    hideDlgError: function () {
        this.dlgManager.hideDlg(this.$dlgError);
    },
    showDlgBillValidatorNotOperable: function () {
        this.dlgManager.showDlg(this.$dlgBillValidatorNotOperable);
    },
    hideDlgBillValidatorNotOperable: function () {
        this.dlgManager.hideDlg(this.$dlgBillValidatorNotOperable);
    },
    receiptUnavailableConfirmCancelCallback: function () {
        this.forceTCManagerCancel();
    },
    receiptUnavailableAlertOKCallback: function () {
        this.forceTCManagerCancel();
    }
});