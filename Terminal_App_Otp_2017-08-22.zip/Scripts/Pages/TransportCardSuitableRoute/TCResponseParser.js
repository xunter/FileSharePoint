﻿function TCResponseParser() { };

TCResponseParser.prototype = {
    parseResponse: function (responseXml) {
        var responseElement = $.parseXML(responseXml).documentElement,
                    reqAction = responseElement.getAttribute("ReqAction"),
                    respStatus = responseElement.getAttribute("RespStatus"),
                    respAction = responseElement.getAttribute("RespAction"),
                    longProcess = responseElement.getAttribute("LongProcess"),
                    responseMap = { reqAction: reqAction, respStatus: respStatus, respAction: respAction, longProcess: longProcess },
                    displayElements = responseElement.getElementsByTagName("DISPLAY"),
                    printElements = responseElement.getElementsByTagName("PRINT"),
                    errorTextElements = responseElement.getElementsByTagName("ERROR_TEXT"),
                    fieldsElements = responseElement.getElementsByTagName("FIELDS");
        if (displayElements.length) {
            responseMap.displayXml = displayElements[0].xml;
        }
        if (printElements.length) {
            responseMap.printXml = printElements[0].xml;
        }
        if (errorTextElements.length) {
            responseMap.errorText = errorTextElements[0].firstChild.nodeValue;
        }
        var fields = responseMap.fields = [];
        if (fieldsElements.length) {
            var fieldsElement = fieldsElements[0];
            var fieldElements = fieldsElement.getElementsByTagName("FIELD");
            for (var i = 0; i < fieldElements.length; i++) {
                var currFieldElement = fieldElements[i];
                var fieldName = currFieldElement.getAttribute("Name");
                var fieldValue = currFieldElement.getAttribute("Value");
                fields.push({ name: fieldName, value: fieldValue });
            }
        }

        return responseMap;
    }
};