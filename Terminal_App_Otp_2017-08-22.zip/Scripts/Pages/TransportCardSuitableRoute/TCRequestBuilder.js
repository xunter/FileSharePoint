﻿function TCRequestBuilder() { };

TCRequestBuilder.prototype = {
    START_SESSION_DETAIL_XML: "<DETAIL ReqAction=\"Start_of_card_service\"/>",
    USER_ACTION_DETAIL_XML_TEMPLATE: "<DETAIL ReqAction=\"User action\"><DISPLAY DisplayFrameId=\"{displayFrameId}\"><BUTTON ButtonAction=\"{buttonAction}\" UserAction=\"{userAction}\"/></DISPLAY></DETAIL>",
    USER_ACTION_DETAIL_WITH_AMOUNT_XML_TEMPLATE: "<DETAIL ReqAction=\"User action\"><DISPLAY DisplayFrameId=\"{displayFrameId}\"><BUTTON ButtonAction=\"{buttonAction}\" UserAction=\"{userAction}\"/><AMOUNT_PARAMETER Type=\"AvailableAmount\" Value=\"{availableAmount}\" /></DISPLAY></DETAIL>",
    createStartSessionRequestXml: function () {
        return this.START_SESSION_DETAIL_XML;
    },
    createUserActionRequestXml: function (displayFrameId, buttonAction, userAction) {
        var requestXml = this.bindParams(this.USER_ACTION_DETAIL_XML_TEMPLATE, { displayFrameId: displayFrameId, buttonAction: buttonAction, userAction: userAction });
        return requestXml;
    },
    createUserActionWithAmountRequestXml: function (displayFrameId, buttonAction, userAction, availableAmount) {
        var requestXml = this.bindParams(this.USER_ACTION_DETAIL_WITH_AMOUNT_XML_TEMPLATE, { displayFrameId: displayFrameId, buttonAction: buttonAction, userAction: userAction, availableAmount: availableAmount });
        return requestXml;
    },
    bindParams: function (template, paramMap) {
        var boundTemplate = template;
        for (var paramName in paramMap) {
            boundTemplate = boundTemplate.replace("{" + paramName + "}", paramMap[paramName]);
        }
        return boundTemplate;
    }
};