﻿function ForPayCardPage() {
    ForPayPageBase.apply(this, arguments);
};

extend(ForPayCardPage, ForPayPageBase, {
    cardReadingInfo: null,
    $bDoPayment: null,
    $bCancel: null,
    $bBack: null,
    currentChequeNum: null,
    init: function (settings) {
        ForPayPageBase.prototype.init.apply(this, arguments);
        if (settings.hasOwnProperty("cardInfo")) this.cardReadingInfo = settings.cardInfo;
    },
    load: function () {
        ForPayPageBase.prototype.load.apply(this, arguments);
        var self = this;
        this.$bDoPayment = $("#bDoPayment");
        this.$bBack = $("#bBack");
        this.$bCancel = $("#bCancel");

        this.$bDoPayment.click(function () { self.bDoPaymentClickHandler() });
        this.$bBack.click(function () { self.bBackClickHandler() });
        this.$bCancel.click(function () { self.bCancelClickHandler() });
    },
    bDoPaymentClickHandler: function () {
        this.showWaitDlg();
        var self = this;
        this.fetchNextChequeNumAsync(function (nextChequeNum) {
            var chequeNum = formatNumber(nextChequeNum, 4);
            self.currentChequeNum = chequeNum;
            self.doPaymentAsync(this.paySumInfo.SumToPay, this.paySumInfo.Sum, new Date(), chequeNum);
        });
    },
    bBackClickHandler: function () {
        OperatorFieldsFormManager.setFieldElement("sumToCharge", this.sumToCharge);
        OperatorFieldsFormManager.setActionUrl(this.backPath);
        OperatorFieldsFormManager.navigate();
    },
    bCancelClickHandler: function () { },
    makeRequestForGateway: function (params) {
        var request = ForPayPageBase.prototype.makeRequestForGateway.call(this, params);
        return request;
    },
    doPaymentSuccessHandler: function (responseMap) {
        var self = this;
        var logger = self.loggingService;
        ForPayPageBase.prototype.doPaymentSuccessHandler.apply(this, arguments);
        var successHandler = function () {
            logger.trace("The success handler invoced. Fetching a receipt text to print async...");
            self.fetchReceiptAsync(self.currentChequeNum);
        };
        var failedHandler = function (responseMap, errorMsg) {
            self.doPaymentFailedHandler(responseMap, errorMsg);
        };

        logger.trace("Checking that a card transaction response has an answer data xml...");
        if (responseMap.hasOwnProperty("ANSWER_DATA")) {
            logger.trace("A card transaction response has an answer data xml. Parsing the xml...");
            var invoiceXml = responseMap["ANSWER_DATA"];
            CardManager.parseTransactionRequestXml(invoiceXml, function (invoiceMap) {
                CardManager.setCurrentTransaction(invoiceMap);
                var responseCode = invoiceMap["RESPONSE_CODE"];
                logger.trace("The xml parsed and responseCode is \"%1\". Handling it...", responseCode);
                if (responseCode == "00") {
                    logger.trace("The response code is SUCCESSFULL. Handling the success handler...");
                    successHandler();
                } else {
                    logger.trace("The response code is UNSUCCESSFULL and the card transaction is FAILED. Checking the failed response code...");
                    var cardResponseCodeInfo = FS.TerminalUI.CardAuthResponseCodesMap[responseCode];
                    logger.trace("The info about the given response code is %1.", toJSON(cardResponseCodeInfo));
                    var errorMsg = "";
                    if (cardResponseCodeInfo != null) {
                        errorMsg = CardOperationFailedGeneralMsgTemplate.replace("{0}", cardResponseCodeInfo.UserMessage);
                    }
                    logger.trace("Handling the failing handler with the error message is \"%1\"...", errorMsg);
                    failedHandler(responseMap, errorMsg);
                }
            });
        } else {
            logger.error("A card transaction response doesn't have an answer data xml! Handling the failed handler...");
            failedHandler(responseMap);
        }
    },
    fetchReceiptCallback: function (receiptText) {
        ForPayPageBase.prototype.fetchReceiptCallback.apply(this, arguments);
        var self = this;
        var loggingService = self.loggingService;
        var amountAll = self._amountAll;
        loggingService.trace("Printing the cheque text...");
        try {
            SmartClientManager.printText(receiptText, amountAll, function () {
                loggingService.trace("The cheque text was printed.");
                self.loggingService.trace("Navigating to the success payment page...");
                self.navigateToSuccessPayment();
            });
        } catch (e) {
            loggingService.trace("An error has occurred while print the cheque text! Error is \"" + e.toString() + "\".");
            self.loggingService.trace("Navigating to the success payment page...");
            self.navigateToSuccessPayment();
        }
    },
    failedFetchReceiptHandler: function () {
        this.loggingService.trace("Failed to fetch a receipt text. Navigating to the success payment page...");
        this.navigateToSuccessPayment();
    },
    doPaymentFailedHandler: function (responseMap, errorMsg) {
        var self = this;
        var logging = self.loggingService;
        ForPayPageBase.prototype.doPaymentFailedHandler.apply(this, arguments);
        this.hideWaitDlg();
        logging.trace("Printing a payment error receipt...");
        if (!errorMsg) {
            errorMsg = "";
        }
        this.printPaymentErrorReceiptAsync(function () {
            logging.trace("A payment error receipt was printed.");
            logging.trace("Navigating to the error page due to a failed payment with msg=\"%1\"...", errorMsg);

            SmartClientManager.writeStateErrorToLog("ERROR_NAVIGATING_FAILED_PAYMENT");

            self.navigateToError(errorMsg);
        });
    },
    navigateToError: function (msg) {
        this.layoutPage.navigateToError(msg);
    }
});