﻿var TypeSumToChargePage = (function (window, $) {
    function TypeSumToChargePage() {
        ClientSidePage.apply(this, arguments);
        this._urlBack = null;
        this._sumToChargeElement = null;
        this.sumFieldManager = null;
        this.fieldPinPadListener.page = this;
    };

    extend(TypeSumToChargePage, ClientSidePage, {
        $bCancel: null,
        $bMenu: null,
        $bGoToPay: null,
        sumToCharge: 0,
        fieldPinPadListener: {
            page: null,
            pinPadCorrectionPressed: function (args) {
                this.page.sumFieldManager.removeLastLetter();
            },
            pinPadDigitPressed: function (args) {
                this.page.sumFieldManager.appendLetter(args.letter);
            },
            pinPadAcceptPressed: function (args) {
                if (!this.page.isHidden(this.page.$bGoToPay)) this.page.$bGoToPay.click();
            }
        },

        smartClientManager: SmartClientManager,
        sumFieldManager: null,
        fieldsFormManager: OperatorFieldsFormManager,

        init: function (settings) {
            ClientSidePage.prototype.init.apply(this, arguments);
            if (settings.hasOwnProperty("urlBack")) this._urlBack = settings.urlBack;
            if (settings.hasOwnProperty("sumToCharge")) this.sumToCharge = settings.sumToCharge;
            if (settings.hasOwnProperty("sumLimit")) this._sumLimit = settings.sumLimit;
            if (settings.hasOwnProperty("sumField")) this._sumField = settings.sumField;
        },

        load: function () {
            var self = this;
            ClientSidePage.prototype.load.apply(this, arguments);
            this.$bCancel = $("#bCancel");
            this.$bGoToPay = $("#bGoToPay");

            this.$bCancel.click(function () { self.bCancelClickHandler() });
            this.$bGoToPay.click(function () { self.bGoToPayClickHandler() });

            this.fieldsFormManager.setFieldElement("sumToCharge", this.sumToCharge);
            this._sumToChargeElement = this.fieldsFormManager.getFieldElement("sumToCharge");

            this.createSumFieldManager();

            this.smartClientManager.addListener(this.fieldPinPadListener);
        },

        unload: function () {
            ClientSidePage.prototype.unload.apply(this, arguments);
            this.smartClientManager.removeListener(this.fieldPinPadListener);
        },

        bCancelClickHandler: function () {
            this.showWaitDlg();
            OperatorFieldsFormManager.setActionUrl(this._urlBack);
            OperatorFieldsFormManager.navigate();
        },

        bGoToPayClickHandler: function () {
            this.showWaitDlg();
            OperatorFieldsFormManager.navigate();
        },

        sumComplete: function () {
            this.showElement(this.$bGoToPay);
        },

        sumIncomplete: function () {
            this.hideElement(this.$bGoToPay);
        },

        createSumFieldManager: function () {
            var sumField = this._sumField;
            var limit = this._sumLimit;
            var self = this;
            var initData = {
                textBox: document.getElementById("tbSum"),
                fieldElement: this._sumToChargeElement,
                type: sumField.Type,
                limit: limit,
                decimalSeparator: FS.TerminalUI.Settings.numberDecimalSeparator,
                oncomplete: function () {
                    self.sumComplete();
                },
                onincomplete: function () {
                    self.sumIncomplete();
                }
            };
            var fieldManager = this.sumFieldManager = new CurrencyFractionalPartAutoHideFieldManager();
            fieldManager.init(initData);
            return fieldManager;
        }
    });

    window.TypeSumToChargePage = window.TypeChargingSumPage = TypeSumToChargePage;
    return TypeSumToChargePage;
})(window, jQuery);