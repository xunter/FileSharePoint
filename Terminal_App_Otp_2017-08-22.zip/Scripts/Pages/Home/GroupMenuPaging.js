﻿(function (window, $) {
    var MAX_DISPLAY_PAGING_BTNS = TerminalUI.UISettingsMap["PAGING_MAX_PAGE_BTNS_SIZE"],
		ulMenu = document.getElementById("ulMenu"),
		$menu = $("#ulMenu"),
		$menuItems = $(".th-item", $menu),
		menuHeight = $menu.height(),
		$workArea = $("#workArea"),
		workAreaHeight = $workArea.height(),
		itemArray = [],
		currMenuHeight = menuHeight,
		itemCount = ulMenu.childNodes.length,
		$bNext = $("#bNext"),
		$bPrevious = $("#bPrevious");
    if (menuHeight <= workAreaHeight) {
        return false;
    }

    //fill items array    
    $menuItems.each(function (i, menuItem) {
        itemArray.push(menuItem.outerHTML);
    });
        

    //clear menu    
    if (ulMenu.innerHTML) {
        ulMenu.innerHTML = "";
    } else {
        $menu.empty();
    }
    
    //compute page size and add items to the first page
    var perPageItemCount = 0;
    do {
        var currMenuItem = itemArray[perPageItemCount++];
        ulMenu.innerHTML += currMenuItem;
        currMenuHeight = ulMenu.scrollHeight;
    } while (currMenuHeight <= workAreaHeight);
    if (currMenuHeight > workAreaHeight) {
        ulMenu.removeChild(ulMenu.lastChild);
        perPageItemCount--;
    }

    //compute page count
    var pageCount = Math.ceil(itemCount / perPageItemCount);
    if (pageCount > MAX_DISPLAY_PAGING_BTNS) {
        $bNext.removeClass("hidden");
    }

    //init paging bar
    var $btnPagingContainer = $("#btnPagingContainer");
    var btnPageMarkupAcc = "";
    var displayBtnCounter = 0;
    var displayGroupCounter = 0;
    var displayGroupBarrierCounter = 0;
    for (var i = 0; i < pageCount; i++) {
        if (displayGroupBarrierCounter == 0) {
            displayGroupCounter++;
        }
        var activePageCssClassName = i == 0 ? "active-page" : "";
        var pageNum = i + 1;
        var visibilityCssClassName = displayBtnCounter >= MAX_DISPLAY_PAGING_BTNS ? "hidden" : "";
        var btnPageHtmlMarkup = formatMsg("<div class='hyperlink btn-page %2 %3' data-group_num='%4' data-num='%1'>%1</div>", pageNum, activePageCssClassName, visibilityCssClassName, displayGroupCounter);
        btnPageMarkupAcc += btnPageHtmlMarkup;
        displayBtnCounter++;
        displayGroupBarrierCounter++;
        if (displayGroupBarrierCounter > MAX_DISPLAY_PAGING_BTNS - 1) displayGroupBarrierCounter = 0;
    }
    $menu.data("active_group_num", 1);
    var $btnPage = $(btnPageMarkupAcc);
    $btnPage.insertBefore($btnPagingContainer);
    $btnPagingContainer.remove();

    //attach click handler to paging buttons
    $btnPage.click(function (e) {
        var $currBtnPage = $(this);
        var pageNum = $currBtnPage.data("num");
        $btnPage.filter(".active-page").removeClass("active-page");
        $currBtnPage.addClass("active-page");

        var startItemIndex = (pageNum - 1) * perPageItemCount;
        var endItemIndex = startItemIndex + perPageItemCount;
        if (endItemIndex > itemArray.length) endItemIndex = itemArray.length;
        $menu.empty();
        for (var i = startItemIndex; i < endItemIndex; i++) {
            var currMenuItemToAdd = itemArray[i];
            $menu.append(currMenuItemToAdd);
        }
    });

    //attach a click handler to the next page button
    $bNext.click(function (e) {
        var currActiveGroupNum = $menu.data("active_group_num"),
                    nextActiveGroupNum = currActiveGroupNum + 1,
                    $nextBtnPage = $btnPage.filter(function () { return $(this).data("group_num") == nextActiveGroupNum });
        if (nextActiveGroupNum == displayGroupCounter) $bNext.addClass("hidden");
        if ($bPrevious.hasClass("hidden")) $bPrevious.removeClass("hidden");
        $btnPage.filter(function () { return $(this).data("group_num") == currActiveGroupNum }).removeClass("active-page").addClass("hidden");
        $nextBtnPage.removeClass("hidden");
        $nextBtnPage.first().click();
        $menu.data("active_group_num", nextActiveGroupNum);
    });

    $bPrevious.click(function (e) {
        var currActiveGroupNum = $menu.data("active_group_num"),
                    prevActiveGroupNum = currActiveGroupNum - 1,
                    $nextBtnPage = $btnPage.filter(function () { return $(this).data("group_num") == prevActiveGroupNum });
        if (prevActiveGroupNum == 1) $bPrevious.addClass("hidden");
        if ($bNext.hasClass("hidden")) $bNext.removeClass("hidden");
        $btnPage.filter(function () { return $(this).data("group_num") == currActiveGroupNum }).removeClass("active-page").addClass("hidden");
        $nextBtnPage.last().click();
        $nextBtnPage.removeClass("hidden");
        $menu.data("active_group_num", prevActiveGroupNum);
    });
})(window, jQuery);