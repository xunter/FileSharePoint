﻿var barcodePinPadListener = {
    pinPadCorrectionPressed: function (args) {
        barcodeFieldManager.removeLastLetter();
    },

    pinPadDigitPressed: function (args) {
        barcodeFieldManager.appendLetter(args.letter);
    },

    barcodeScannerOpening: function () { },

    barcodeScannerOpened: function () { },

    barcodeScannerClosing: function () { },

    barcodeScannerClosed: function () { },

    barcodeScannerReadValue: function (readText) {
        barcodeFieldManager.setFieldValue(readText);
    }
};

function navigateBack() {
    var backPath = getUriParamValue("backPath");
    go(backPath);
};

var fieldPinPadListener = new Listener({
    pinPadCorrectionPressed: function (args) {
        fieldManager.removeLastLetter();
    },
    pinPadDigitPressed: function (args) {
        fieldManager.appendLetter(args.letter);
    }
});

$(function () {
    WaitMsgManager.init();

    $.each(otherFieldsWithBarcode, function (i, fieldWithBarcode) {
        var initData = {
            fieldId: fieldWithBarcode.ID,
            fieldElement: OperatorFieldsFormManager.getFieldElementByFieldId(fieldWithBarcode.ID),
            barcodeInstance: fieldWithBarcode.BarcodeInstance,
            urlParseBarcodeText: urlParseBarcodeText
        };
        var fieldManager = new FieldManager();
        fieldManager.init(initData);
        fieldManagersWithBarcode.add(fieldManager);
    });

    var $bPay = $("#bGoToPay");
    var $bDlgErrorOk = $("#bDlgErrorOk");
    var $lDlgError = $("#lDlgError");
    var $lockScreen = $("#lock");
    var $dlgWait = $("#dlgWait");
    var $dlgError = $("#dlgError");
    var $tbField = $("#tbField");

    var $bBarcode = $("#bBarcode");
    var $dlgBarcode = $("#dlgBarcode");
    var $bDlgBarcodeCancel = $("#bDlgBarcodeCancel");
    var $bDlgBarcodeGoToPay = $("#bDlgBarcodeGoToPay");
    var $tbBarcode = $("#tbBarcode");

    var barcodeAcceptListener = {
        pinPadAcceptPressed: function (args) {
            $bDlgBarcodeGoToPay.click();
        }
    };
    var showDlg = function ($dlg) {
        DlgManager.showDlg($dlg);
    };

    var hideDlg = function ($dlg) {
        DlgManager.hideDlg($dlg);
    };

    var showDlgWait = function () {
        WaitMsgManager.show();
        SmartClientManager.removeListener(fieldPinPadListener);
        SmartClientManager.removeListener(acceptListener);
    };
    var hideDlgWait = function () {
        SmartClientManager.addListener(fieldPinPadListener);
        SmartClientManager.addListener(acceptListener);
        WaitMsgManager.hide();
    };

    var showDlgError = function (msg) {
        $lDlgError.text(msg);
        SmartClientManager.removeListener(fieldPinPadListener);
        SmartClientManager.removeListener(acceptListener);
        showDlg($dlgError);
    };
    var hideDlgError = function () {
        hideDlg($dlgError);
        SmartClientManager.addListener(fieldPinPadListener);
        SmartClientManager.addListener(acceptListener);
    };

    var showDlgBarcode = function () {
        SmartClientManager.removeListener(fieldPinPadListener);
        SmartClientManager.addListener(barcodePinPadListener);
        showDlg($dlgBarcode);
        var currValue = fieldManager.getFieldValue();
        barcodeFieldManager.clear();
        if (currValue.length) {
            barcodeFieldManager.setFieldValue(currValue);
        }
        barcodeFieldManager.focusTextBox();
        SmartClientManager.openBarcodeScanner();
    };

    var hideDlgBarcode = function () {
        hideDlg($dlgBarcode);
        SmartClientManager.removeListener(barcodePinPadListener);
        SmartClientManager.addListener(fieldPinPadListener);
        barcodeFieldManager.clear();
        //fieldManager.clear();
        SmartClientManager.closeBarcodeScanner();
    };

    $bDlgErrorOk.click(function () {
        hideDlgError();
    });

    $bPay.click(function () {
        showDlgWait();
        var fieldValueForStateLogging = fieldInstance.IsCrypt ? "****SECURE****" : fieldManager.getViewFieldValue();
        SmartClientManager.writeStateToLog("Заполнено поле \"" + fieldInstance.Title + "\" значением: " + fieldValueForStateLogging);
        var fieldValue = fieldManager.getHiddenFieldValue();
        var fieldId = fieldManager.getFieldID();
        fieldsMap["field" + fieldId] = fieldValue;
        OperatorFieldsEditingUtil.processFieldsBeforePayAsync({
            invoiceSearchEnabled: IS_INVOICE_SEARCH_ENABLED,
            fieldsCheckingEnabled: IS_FIELDS_CHECKING_ENABLED,
            urlGetFieldsMapByAnswerData: URLGetFieldsMapByAnswerData,
            operatorId: operatorId,
            operatorInstance: operatorInstance,
            fieldsMap: fieldsMap,
            error: function (msg) {
                hideDlgWait();
                showDlgError(msg);
            },
            callback: function (fieldsMap) {
                OperatorFieldsFormManager.navigate();
            }
        });
    });

    var acceptListener = new Listener({
        pinPadAcceptPressed: function (args) {
            $bPay.click();
        }
    });

    $(window).bind("unload", function () {
        SmartClientManager.removeListener(barcodePinPadListener);
        SmartClientManager.removeListener(fieldPinPadListener);
        SmartClientManager.removeListener(acceptListener);
        SmartClientManager.removeListener(barcodeAcceptListener);
        SmartClientManager.closeBarcodeScanner();
    });

    var tbField = document.getElementById("tbField");

    fieldManager = FieldsUtil.createFieldManagerForField({
        field: fieldInstance,
        operator: operatorInstance,
        isFieldEditable: true,
        fieldKey: "field" + FIELD_ID,
        textBoxId: "tbField",
        fieldManagerSuffix: FIELD_ID,
        urlParseBarcodeText: urlParseBarcodeText,
        oncomplete: function () {
            $bPay.removeClass("th-unvisible");
            SmartClientManager.addListener(acceptListener);
        },
        onincomplete: function () {
            if (!$bPay.hasClass("th-unvisible")) {
                $bPay.addClass("th-unvisible");
                SmartClientManager.removeListener(acceptListener);
            }
        }
    });

    $bBarcode.click(function () {
        showDlgBarcode();
    });

    $bDlgBarcodeCancel.click(function () {
        hideDlgBarcode();
        $tbBarcode.val("");
    });

    $bDlgBarcodeGoToPay.click(function () {
        var barcodeValue = barcodeFieldManager.getFieldValue();
        hideDlgBarcode();
        fieldManagersWithBarcode.applyBarcodeValue(barcodeValue);
        fieldManager.applyBarcodeValue(barcodeValue);
    });

    barcodeFieldManager = new FieldManager();
    barcodeFieldManager.init({
        textBox: $tbBarcode.get(0),
        //minlength: barcodeMinLength,
        required: true,
        oncomplete: function () {
            $bDlgBarcodeGoToPay.removeClass("th-hidden");
            SmartClientManager.addListener(barcodeAcceptListener);
        },
        onincomplete: function () {
            SmartClientManager.removeListener(barcodeAcceptListener);
            if (!$bDlgBarcodeGoToPay.hasClass("th-hidden")) {
                $bDlgBarcodeGoToPay.addClass("th-hidden");
            }
        }
    });
    if (FORCE_SHOW_DLG_BARCODE) {
        showDlgBarcode();
    }

    fieldManager.checkComplete();
});