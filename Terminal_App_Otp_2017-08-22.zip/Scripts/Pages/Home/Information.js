(function(window, $) {
	showPage = function(pageNum) {
		$(".th-page[data-num!=" + pageNum + "]").addClass("th-hidden");
		$(".th-page[data-num=" + pageNum + "]").removeClass("th-hidden");
	}

	$(function () {
		$(".th-set .th-btn-page").click(function (e) {
			var $btn = $(this),
				pageNum = $btn.data("num"),
				currSet = $(".th-set").not("th-hidden");
			$(".th-btn-page.th-selected", currSet).removeClass("th-selected");
			$(".th-btn-page[data-num=" + pageNum + "]").addClass("th-selected");
			showPage(pageNum);
		});

		$(".th-set .th-btn-prev-set, .th-set .th-btn-next-set").click(function (e) {
			var $btn = $(this),
				nextSet = $btn.data("next_set"),
				$currSet = $(".th-set").not("th-hidden"),
				currNum = $btn.data("set_num");
			$(".th-btn-page.th-selected", $currSet).removeClass("th-selected");
			$currSet.addClass("th-hidden");
			var $nextSet = $(".th-set[data-set_num=" + nextSet + "]").removeClass("th-hidden");
			var minPageNum = null;
			$(".th-btn-page", $nextSet).each(function (i, elem) {
				var currPage = $(elem).data("num");
				if (minPageNum == null || minPageNum > currPage) {
					minPageNum = currPage;
				}
			});
			$(".th-btn-page[data-num=" + minPageNum + "]").addClass("th-selected");
			showPage(minPageNum);
		});
	});
})(window, jQuery);