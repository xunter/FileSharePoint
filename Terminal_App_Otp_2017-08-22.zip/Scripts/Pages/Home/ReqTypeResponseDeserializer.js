var ReqTypeResponseDeserializer = (function () {
    function ReqTypeResponseDeserializer() {
    }
    ReqTypeResponseDeserializer.prototype.ToReqType13Response = function (gatewayResponse) {
        if (gatewayResponse.responseMap["ANSWER_DATA"] == null) {
            throw "Response doesn't contains text. Check ANSWER_DATA";
        }
        var xmlDoc = $.parseXML(gatewayResponse.responseMap.ANSWER_DATA);
        var $xml = $(xmlDoc);
        return {
            Result: parseInt(gatewayResponse.result),
            Error: parseInt(gatewayResponse.error),
            Status: parseInt($xml.find('status').text())
        };
    };
    return ReqTypeResponseDeserializer;
})();
//# sourceMappingURL=ReqTypeResponseDeserializer.js.map