﻿function PrinterErrorPage() {
    ClientSidePage.apply(this, arguments);
    this._urlMainMenu = null;
};

extend(PrinterErrorPage, ClientSidePage, {
    init: function (settings) {
        this.loggingService.trace("Initializing a page instance ot the PrinterErrorPage type...");
        this.loggingService.trace("Calling the init method of the base type...");
        ClientSidePage.prototype.init.apply(this, arguments);
        this.loggingService.trace("The base class init method was called.");
        this.loggingService.trace("Setting settings...");
        if (settings.hasOwnProperty("urlMainMenu")) this._urlMainMenu = settings.urlMainMenu;
        this.loggingService.trace("Settings were setted.");
        this.loggingService.trace("Set FS.TerminalUI.preventHandlingPrinterNotOperableStateFromMaster = true");
        FS.TerminalUI.preventHandlingPrinterNotOperableStateFromMaster = true;
        this.loggingService.trace("Set smartClientManager.idleTimeoutHandlerEnabled = false");
        this.smartClientManager.denyIdleTimeoutHandler();
        this.loggingService.trace("Closing the pin pad...");
        this.smartClientManager.closePad();
        this.loggingService.trace("The pin pad was closed.");
        this.loggingService.trace("printerStateListener.page = this");
        this.printerStateListener.page = this;
        this.loggingService.trace("Adding the printer state listener to listen a printer state from the smartClientManager object...");
        this.smartClientManager.addListener(this.printerStateListener);
        this.loggingService.trace("The printer state listener to listen a printer state from the smartClientManager object was added.");
        this.loggingService.trace("The printer error page was initialized");

    },

    printerStateListener: {
        page: null,
        printerState: function (state) {
            this.page.loggingService.trace("A new printer state was received. The state is %1.", state);
            if (state == "Operable") {
                this.page.loggingService.trace("Set smartClientManager.idleTimeoutHandlerEnabled = true");
                this.page.smartClientManager.allowIdleTimeoutHandler();
                this.page.loggingService.trace("Navigating to the main menu page...");
                this.page.navigate(this.page._urlMainMenu);
            }
        }
    }
});