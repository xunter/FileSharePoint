﻿var FieldsUtil = {
    serializeFieldsMapToTransfer: function (fieldMap) {
        return _.map(fieldMap, function (value, key) { return { Key: key, Value: value} });
    },

    isNumberFieldType: function (fieldType) {
        return fieldType == "decimal" || fieldType == "currency" || fieldType == "regext";
    },

    // inits a field manager for the specified field and adds the created field manager to the field manager collection
    //var args = { operator: {}, field: {}, isFieldEditable: false, fieldKey: "", textBoxId: "", fieldManagerSuffix: "" }
    createFieldManagerForField: function (passedArgs) {
        var initialArgs = {
            operator: {},
            field: {},
            isFieldEditable: false,
            fieldKey: "",
            textBoxId: "",
            fieldManagerSuffix: "",
            onMaxSumExceeded: function () { },
            onMinSumNotReached: function () { },
            urlParseBarcodeText: "",
            oncomplete: null,
            onincomplete: null
        };
        var args = $.extend({}, initialArgs, passedArgs);
        var fieldInstance = args.field;
        var operatorInstance = args.operator;
        var fieldKey = args.fieldKey;
        var textBoxId = args.textBoxId;
        var fieldManagerSuffix = args.fieldManagerSuffix;
        var isFieldEditable = args.isFieldEditable;
        var barcodeInstance = fieldInstance.BarcodeInstance;
        var field = fieldInstance;
        var fieldType = fieldInstance.Type;
        var isAmountField = fieldInstance.IsAmountField;
        var mask = field.IsMaskUsed ? field.Mask : null;
        var limit = operatorInstance.RestrictionsInstance;
        var urlParseBarcodeText = args.urlParseBarcodeText;
        var initData = {
            fieldId: fieldManagerSuffix,
            type: fieldType,
            required: field.IsRequired,
            maxlength: field.MaxLength,
            minlength: field.MinLength,
            fieldElement: document.getElementById(fieldKey),
            ajaxService: FS.TerminalUI.ajaxService,
            fieldInstance: fieldInstance
        };
        if (args.oncomplete != null) {
            initData.oncomplete = args.oncomplete;
        }
        if (args.onincomplete != null) {
            initData.onincomplete = args.onincomplete;
        }
        if (barcodeInstance != null) {
            initData.barcodeInstance = barcodeInstance;
            initData.urlParseBarcodeText = urlParseBarcodeText;
        }

        if (isFieldEditable) initData.textBox = document.getElementById(textBoxId);
        var fieldManager = null;
        var isNumberField = FieldsUtil.isNumberFieldType(fieldType);
        if (isNumberField) {
            fieldManager = new CurrencyFractionalPartAutoHideFieldManager();
            if (FS.TerminalUI.UISettingsMap["PAYMENT_GLOBAL_MAX_SUM_MODE"] == "RestrictByEntireAmount") {
                fieldManager.validateMaxSum = function (sum) {
                    var baseValidateResult = CurrencyFractionalPartAutoHideFieldManager.prototype.validateMaxSum.call(fieldManager, sum);
                    if (!baseValidateResult) {
                        return false;
                    }
                    var amountAll = OperatorManager.computeAmountAll(operatorInstance, sum, IS_CABINET_SESSION);
                    return amountAll <= limit.Max;
                };
                fieldManager.validateMinSum = function (sum) {
                    var baseValidateResult = CurrencyFractionalPartAutoHideFieldManager.prototype.validateMinSum.call(fieldManager, sum);
                    if (!baseValidateResult) {
                        return false;
                    }
                    var amountAll = OperatorManager.computeAmountAll(operatorInstance, sum, IS_CABINET_SESSION);
                    return amountAll >= limit.Min;
                };
            }
            fieldManager.onMaxSumExceeded = args.onMaxSumExceeded;
            fieldManager.onMinSumNotReached = args.onMinSumNotReached;
            initData.limit = limit;
            initData.decimalSeparator = FS.TerminalUI.Settings.numberDecimalSeparator;
        } else if (mask == null) {
            fieldManager = new FieldManager();
        } else {
            initData.mask = mask;
            fieldManager = new MaskedFieldManager();
        }
        fieldManager.init(initData);
        return fieldManager;
    }
};