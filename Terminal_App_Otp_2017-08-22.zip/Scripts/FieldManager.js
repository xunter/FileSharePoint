﻿var FieldManager = function () {
    this._fieldElement = null;
    this._tb = null;
    this._maxlength = null;
    this._minlength = null;
    this._fieldId = null;
    this._fieldType = null;
    this._barcodeInstance = null;
    this._urlParseBarcodeText = null;
    this._ajaxService = null;
    this._required = false;
    this._fieldInstance = null;
    this._checkOnSetField = true;
    this._inited = false;
};

FieldManager.prototype = {
    getFieldID: function () {
        return this._fieldId;
    },

    getFieldType: function () {
        return this._fieldType;
    },

    formatValueForView: function (val) {
        return this.getFieldValue();
    },

    isEditable: function () { return this._tb != null },

    fieldChanged: function (newValue) {
        this.triggerValueChanged(newValue);
    },

    _setViewFieldValue: function (newValue) {
        this.$tb.val(newValue);
    },

    setViewFieldValue: function (newValue) {
        var viewVal = newValue;
        if (this._fieldInstance != null && this._fieldInstance.Type == "enum") {
            var enumViewVal = this.getEnumTextByValue(newValue);
            if (enumViewVal != null) {
                viewVal = enumViewVal;
            }
        }
        this._setViewFieldValue(viewVal);
    },

    getViewFieldValue: function () {
        var rawViewValue = this.$tb.val();
        if (this._fieldInstance != null && this._fieldInstance.IsSecrete) {
            var secreteValue = rawViewValue.replace(/./g, "*");
            return secreteValue;
        }
        return rawViewValue;
    },

    setHiddenFieldValue: function (newValue) {
        this._fieldElement.value = newValue;
    },

    getHiddenFieldValue: function () {
        return this._fieldElement.value;
    },

    getFieldValue: function () {
        return this.getHiddenFieldValue();
    },

    setFieldValue: function (value, fieldValue) {
        var fieldValue = typeof (fieldValue) == "undefined" ? value : fieldValue;
        fieldValue = this.preProcessFieldValue(fieldValue);
        if (this.isEditable()) this.setViewFieldValue(value);
        if (this._fieldElement != null) this.setHiddenFieldValue(fieldValue);
        this.fieldChanged(fieldValue);
        if (this._checkOnSetField) {
            this.checkComplete();
        }
    },

    preProcessFieldValue: function (fieldValue) {
        if (typeof (fieldValue) != "undefined" && fieldValue != null && this._maxLength && fieldValue.length > this._maxLength) {
            fieldValue = substr(fieldValue, 0, this._maxLength);
        }
        return fieldValue;
    },

    oncomplete: null,
    onincomplete: null,

    onValueChanged: null,

    triggerValueChanged: function (fieldValue) {
        if (this.onValueChanged != null) {
            this.onValueChanged(fieldValue);
        }
    },

    triggerComplete: function () {
        if (this.oncomplete !== null) {
            this.oncomplete();
        }
    },

    triggerIncomplete: function () {
        if (this.onincomplete !== null) {
            this.onincomplete();
        }
    },

    getEnumTextByValue: function (val) {
        var fieldInstance = this._fieldInstance;
        if (fieldInstance == null) return null;
        var enums = fieldInstance.EnumCollection;
        if (enums == null) return null;
        for (var i = 0; i < enums.length; i++) {
            var enumItem = enums[i];
            if (enumItem.Value == val) {
                return enumItem.Title;
            }
        }
        return null;
    },

    initBase: function (args) {
        var self = this;
        var args = this._settings = args || {};
        if (typeof (args.fieldId) != "undefined") {
            this._fieldId = args.fieldId;
        }
        if (typeof (args.type) != "undefined") {
            this._fieldType = args.type;
        }
        this._pos = 0;
        this._fieldElement = args.fieldElement ? args.fieldElement : null;
        if (args.hasOwnProperty("maxlength") && args.maxlength != null && args.maxlength > 0) this._maxlength = args.maxlength;
        if (args.hasOwnProperty("minlength")) this._minlength = args.minlength;
        if (args.hasOwnProperty("onValueChanged")) this.onValueChanged = args.onValueChanged;
        if (args.hasOwnProperty("urlParseBarcodeText")) this._urlParseBarcodeText = args.urlParseBarcodeText;
        if (args.hasOwnProperty("ajaxService")) this._ajaxService = args.ajaxService;
        if (args.hasOwnProperty("required")) this._required = args.required;

        if (args.hasOwnProperty("textBox")) {
            var tbField = this._tb = args.textBox;
            var $tbField = this.$tb = $(tbField);
            $tbField.focus(function () { self.updateCaretPos() });
            if (args.initialValue) {
                $tbField.val(args.initialValue);
            }
            if (!args.hasOwnProperty("fieldElement")) this._fieldElement = tbField;
        }
        if (args.oncomplete) {
            this.oncomplete = args.oncomplete;
        }
        if (args.onincomplete) {
            this.onincomplete = args.onincomplete;
        }
        if (args.hasOwnProperty("barcodeInstance")) this._barcodeInstance = args.barcodeInstance;
        if (args.hasOwnProperty("fieldInstance")) this._fieldInstance = args.fieldInstance;
    },

    init: function (args) {
        this.initBase(args);
        this.processFieldElement();
        this._inited = true;
    },

    applyBarcodeValue: function (val) {
        var self = this;
        if (this._barcodeInstance == null) return;
        var barcodeInstance = this._barcodeInstance,
            startPos = barcodeInstance.Start - 1,
            len = barcodeInstance.End - startPos,
            postApplyBarcodeValue = function (resultValue) {
                self.setFieldValue();
            };
        if (barcodeInstance.ClassName == null || barcodeInstance.ClassName.length === 0) {
            var valLengthToApply = len;
            var endPos = barcodeInstance.End;
            if (val.length > startPos) {
                var valLenDiff = val.length - startPos;
                if (valLenDiff.length < endPos) valLengthToApply = val.length - startPos;
            }
            if (valLengthToApply <= 0) return;
            var valueForFieldFromBarcode = val.substr(startPos, valLengthToApply);
            if (barcodeInstance.Divider) {
                var decimalSeparatorPosition = valueForFieldFromBarcode.length - barcodeInstance.Divider,
                valueBeforeDecimalSeparator = valueForFieldFromBarcode.substr(0, decimalSeparatorPosition),
                valueAfterDecimalSeparator = valueForFieldFromBarcode.substr(decimalSeparatorPosition, valueForFieldFromBarcode.length - decimalSeparatorPosition),
                valueResult = valueBeforeDecimalSeparator + "." + valueAfterDecimalSeparator;
                valueResult = valueResult.replace(/^[0]+/, "");
                this.setFieldValue(valueResult);
            } else {
                this.setFieldValue(valueForFieldFromBarcode);
            }
        } else {
            this.parseBarcodeTextAsync(val, function (parsedValue) {
                self.setFieldValue(parsedValue);
            });
        }
    },

    parseBarcodeTextAsync: function (val, callback) {
        if (this._urlParseBarcodeText === null || this._ajaxService === null) {
            throw new Error("An ajax service or url to parse is not defined!");
        }
        var dataToPost = { BarcodeInstance: this._barcodeInstance, Value: val };
        this._ajaxService.postJSON(this._urlParseBarcodeText, dataToPost, function (result) { callback(result) });
    },

    isWithBarcode: function () { return this._barcodeInstance != null },

    processFieldElement: function () {
        var self = this;
        if (this._fieldElement != null) {
            var fieldValue = this.getHiddenFieldValue();
            if (this.isEditable()) {
                this.setViewFieldValue(fieldValue);
                this._pos = fieldValue.length;
                this.updateCaretPos();
            }
            if (this.isComplete()) {
                this.triggerComplete();
            }
        }
    },

    isComplete: function (currValueParam) {
        var currValue = this.getFieldValue();
        var length = currValue.length;

        if (!this._required && length == 0) {
            return true;
        }
        if (this._maxlength != null) {
            if (this._minlength) {
                return length >= this._minlength && length <= this._maxlength;
            } else {
                if (this._required) {
                    return length > 0 && length <= this._maxlength;
                } else {
                    return length <= this._maxlength;
                }
            }
        } else {
            if (this._required) {
                if (this._minlength) {
                    return length >= this._minlength;
                } else {
                    return length > 0;
                }
            } else {
                if (this._minlength) {
                    return length >= this._minlength;
                } else {
                    return length >= 0;
                }
            }
        }
    },

    appendLetter: function (letter) {
        var currValue = this.getFieldValue();
        if (this._maxlength != null && currValue.length >= this._maxlength) return;
        var newValue = currValue + letter;
        this._pos++;
        this.setFieldValue(newValue);
        if (this.isEditable()) {
            this.updateCaretPos();
        }
        this.checkComplete();
    },

    focusTextBox: function () {
        if (!this._tb) return;
        var self = this;
        var focusTextBoxFunc = function () {
            setTimeout(function () {
                try {
                    self._tb.focus();
                } catch (e) {
                    focusTextBoxFunc();
                }
            }, 0);
        };


        focusTextBoxFunc();
    },

    clear: function () {
        this.setFieldValue("");
        if (this.isEditable()) {
            this.focusTextBox();
        }
        this._pos = 0;
        this.clearAfter();
    },

    clearAfter: function () {
        if (this.isEditable()) {
            this.updateCaretPos();
        }
        this.checkComplete();
    },

    checkComplete: function () {
        if (this.isComplete()) {
            this.triggerComplete();
        } else {
            this.triggerIncomplete();
        }
    },

    removeLastLetter: function () {
        var currValue = this.getFieldValue();
        if (currValue.length) {
            var newValue = currValue.substr(0, currValue.length - 1);
            this._pos--;
            this.setFieldValue(newValue);
            if (this.isEditable()) {
                //this.setViewFieldValue(newValue);
                this.updateCaretPos();
            }
            this.checkComplete();
        }
    },

    updateCaretPos: function () {
        setCursorPos(this._tb, this._pos);
    },

    getViewFieldLength: function () { return this.getViewFieldValue().length; }
};