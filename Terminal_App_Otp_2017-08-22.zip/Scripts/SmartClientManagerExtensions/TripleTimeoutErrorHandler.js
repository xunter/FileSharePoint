﻿///<reference path="~/Scripts/SmartClientManager.js" />

(function (window, $, smartClientManager) {
    var MAX_TIMEOUT_COUNT = TerminalUI.UISettingsMap["MAX_COUNT_SCREEN_PANEL_IDLE_TIMEOUT"];
    var timeoutCounter = 0;
    var loggingService = TerminalUI.loggingService;
    var targetPage = TerminalUI.UISettingsMap["TRIPLE_SCREEN_PANEL_TIMEOUT_TARGET_PAGE"];

    // on dom ready
    $(function () {

        //reset timeout counter on document click
        $(document).click(function () {
            timeoutCounter = 0;
        });
    });

    loggingService.trace("adding handler: TripleTimeoutErrorHandler.screenPanelCallbackForced");
    smartClientManager.addHandler("screenPanelCallbackForced", function () {
        var scm = SmartClientManager;
        

        loggingService.trace("TimeoutCounter = %1", timeoutCounter);
        timeoutCounter++;
        var dlgIdleTimeout = DlgMsgManager.findDlg(TerminalUI.UISettingsMap["DLG_IDLE_TIMEOUT_CLIENT_ID"]);
        if (dlgIdleTimeout.isShown()) {
            loggingService.trace("dlgIdleTimeout.isShown = true ");
            timeoutCounter = 0;
        }

        if (timeoutCounter == MAX_TIMEOUT_COUNT) {
            
            loggingService.warn("The number %1 of screen panel idle timeouts was exceeded. The web app will be navigated to the %2 page!", MAX_TIMEOUT_COUNT, targetPage);
            scm.writeStateErrorToLog("Таймаут работы с экраном сработал " + MAX_TIMEOUT_COUNT + " раз(а) и приложение будет принудительно переведено на страницу " + targetPage + ".");

            if (FS.TerminalUI.UISettingsMap["FORCED_PAYMENT_AFTER_TIMEOUT_ENABLED"] == "1" && scm.cashReceive != null && !scm.paid) {
                loggingService.warn("Оплата платежа по истечению таймаута");
                scm.cashReceive.$bPay.click();
            }else if (targetPage == "Error") {
                loggingService.trace("Navigating to the ERROR page due to the max timeout count exceeded!");
                scm.writeStateErrorToLog("ERROR_NAVIGATING_TRIPLE_TIMEOUT");
                ClientSidePage.layoutPage.navigateToError();
            } else if (targetPage == "MainMenu") {
                loggingService.trace("Navigating to the MainMenu page due to the max timeout count exceeded!");
                scm.writeStateErrorToLog("ERROR_NAVIGATING_TRIPLE_TIMEOUT");
                ClientSidePage.layoutPage.navigateToMainMenu();
                //TerminalUI.events.notify("tripleTimeoutTriggerred");
                //TerminalUI.idleTimeoutHandler();
            }
        }
    });

    loggingService.trace("adding handler: TripleTimeoutErrorHandler.screenPanelActive");
    smartClientManager.addHandler("screenPanelActive", function () {
        var loggingService = TerminalUI.loggingService;
        loggingService.trace("TripleTimeoutErrorHandler.screenPanelActive.");
        timeoutCounter = 0;
    });
})(window, jQuery, SmartClientManager);