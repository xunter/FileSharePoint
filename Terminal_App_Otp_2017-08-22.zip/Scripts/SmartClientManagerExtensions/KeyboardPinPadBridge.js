﻿(function (window, smartClientManager, $) {
    $(function () {
        $(document).keypress(function (e) {
            SmartClientManager.notifyListeners({
                state: "pinPadCallback",
                paramName: "PinPadLastKey",
                paramValue: e.keyCode 
            });
            e.preventDefault();
        });
    });

})(window, SmartClientManager, jQuery);