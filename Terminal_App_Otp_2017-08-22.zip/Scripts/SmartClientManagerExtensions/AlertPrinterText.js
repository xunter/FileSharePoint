﻿(function (window, smartClientManager) {

    smartClientManager.alertPrinterText = true;

})(window, SmartClientManager);