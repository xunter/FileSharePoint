var DefaultTimeoutManager = (function () {
    function DefaultTimeoutManager(urlCabinetSignOut, loggingService) {
        this._ajaxService = null;
        this._urlCabinetSignOut = urlCabinetSignOut;
        this._loggingService = loggingService;
        this.UITimeout = new FireEvent();
        this._ajaxService = new JQueryAjaxService();
    }
    DefaultTimeoutManager.prototype.OnUITimeout = function () {
        var _this = this;
        this._loggingService.trace("Обработка timeout (по умолчанию)...");
        if (isCabinetSession) {
            this.SignoutCabinetAsync(function () {
                _this.UITimeout.fire(_this, null);
            });
        }
        else {
            this.UITimeout.fire(this, null);
        }
    };
    DefaultTimeoutManager.prototype.OnUITimeoutCancelled = function () {
        // Если нажали Отмена - выход из CabinetSession не делается
        this.UITimeout.fire(this, null);
    };
    DefaultTimeoutManager.prototype.SignoutCabinetAsync = function (asyncCallback) {
        var _this = this;
        this._loggingService.trace("Signout cabinet session...");
        this._ajaxService.postJSON(this._urlCabinetSignOut, 1, $.proxy(function () {
            _this._loggingService.trace("The cabinet session has been signed out.");
            asyncCallback();
        }, this));
    };
    return DefaultTimeoutManager;
})();
//# sourceMappingURL=DefaultTimeoutManager.js.map