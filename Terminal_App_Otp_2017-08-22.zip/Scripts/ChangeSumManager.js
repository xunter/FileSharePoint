var ChangeSumManager = (function () {
    function ChangeSumManager(settings, terminalExplorerLogger) {
        this._ajaxService = null;
        this._changeSum = 0;
        this._urlPushChangeSum = null;
        this._urlFetchChangeSum = null;
        this._urlGetChangeSumBanner = null;
        this._onchangesumchanged = null;
        this._terminalExplorerLogger = terminalExplorerLogger;
        if (settings.hasOwnProperty("changeSum")) {
            this._changeSum = settings.changeSum;
        }
        if (settings.hasOwnProperty("urlPushChangeSum")) {
            this._urlPushChangeSum = settings.urlPushChangeSum;
        }
        if (settings.hasOwnProperty("urlFetchChangeSum")) {
            this._urlFetchChangeSum = settings.urlFetchChangeSum;
        }
        if (settings.hasOwnProperty("urlGetChangeSumBanner")) {
            this._urlGetChangeSumBanner = settings.urlGetChangeSumBanner;
        }
        var ajaxService = new JQueryAjaxService();
        this._ajaxService = new JQAjaxSynchronousServiceWrapper(ajaxService);
    }
    ChangeSumManager.prototype.getChangeSum = function () {
        return this._changeSum;
    };
    ChangeSumManager.prototype.setChangeSum = function (changeSum) {
        this._changeSum = changeSum;
    };
    ChangeSumManager.prototype.isChangeSumAvailable = function () {
        return this._changeSum > 0;
    };
    ChangeSumManager.prototype.fetchChangeSumAsync = function (callback) {
        var _this = this;
        var url = passParamToURL(this._urlFetchChangeSum, { clientDate: new Date() });
        this._ajaxService.get(url, $.proxy(function (changeSumFromTheServer) {
            _this._terminalExplorerLogger.writeToLog("Прочитана сумма сдачи с сервера. Сумма=" + changeSumFromTheServer);
            _this._changeSum = changeSumFromTheServer;
            if (callback) {
                callback(changeSumFromTheServer);
            }
        }, this));
    };
    ChangeSumManager.prototype.pushChangeSumAsync = function (changeSum, callback) {
        var _this = this;
        this._changeSum = changeSum;
        var changeSumAsText = changeSum.toFixed(2);
        this._ajaxService.postJSON(this._urlPushChangeSum, {
            changeSum: changeSumAsText
        }, $.proxy(function () {
            _this._terminalExplorerLogger.writeToLog("Записана сумма сдачи на сервер. Сумма=" + changeSumAsText);
            if (callback) {
                callback();
            }
        }, this));
    };
    ChangeSumManager.prototype.updateBannerAsync = function (callback) {
        var changeSumBannerElement = document.getElementById("divChangeSumBanner");
        if (changeSumBannerElement != null) {
            changeSumBannerElement.parentNode.removeChild(changeSumBannerElement);
        }
        this._ajaxService.get(this._urlGetChangeSumBanner + "?t=" + new Date().getTime(), function (html) {
            $("#divWrapper").append(html);
            if (callback) {
                callback();
            }
        });
    };
    ChangeSumManager.prototype.updateChangeSumAsync = function (changeSum, callback) {
        var _this = this;
        this.pushChangeSumAsync(changeSum, $.proxy(function () {
            _this.updateBannerAsync(callback);
        }, this));
    };
    ChangeSumManager.prototype.incrementChangeSumAsync = function (changeSumToIncrement, callback) {
        this._changeSum = (parseFloat(this._changeSum) + parseFloat(changeSumToIncrement)).toFixed(2);
        this.updateChangeSumAsync(this._changeSum, callback);
    };
    return ChangeSumManager;
})();
//# sourceMappingURL=ChangeSumManager.js.map