﻿/// <reference path="SmartClientCommunicator.js" />
/// <reference path="Common.js" />
/// <reference path="Devices/DeviceManager.js" />
/// <reference path="underscore-1.4.4.js" />
/// <reference path="Listenable.js" />
/// <reference path="Listener.js" />
/// <reference path="underscore-1.4.4.js" />

var PinPadCharCodes = {
    CANCEL: 10,
    CANCEL_OTHER: 27,
    CORRECTION: 11,
    CORRECTION_OTHER: 8,
	INFO: 12,
	ACCEPT: 13,

	PLUS: 35,
	SHARP: 35,
	MINUS: 42,
	STAR: 42,
					
	ZERO: 48,
	ONE: 49,
	TWO: 50,
	THREE: 51,
	FOUR: 52,
	FIVE: 53,
	SIX: 54,
	SEVEN: 55,
	EIGHT: 56,
	NINE: 57,
	
	isDigit: function(charCode) {
		var num = typeof(charCode) == "number" ? charCode : parseInt(charCode);
		return num >= PinPadCharCodes.ZERO && num <= PinPadCharCodes.NINE;
	}
};

var RequestTypes = {
	INPUT_DATA_VALIDATION: 1,
	DO_PAYMENT: 3,
    GET_MISSING_FIELDS: 5,
    AMOUNT_DIFF: 55
};

var GatewayResults = {
	SUCCESS: 0,
	ERROR: 1
};

var DeviceStates = {
    OPERABLE: "Operable",
    NOT_OPERABLE: "NotOperable"
};

var PinPadOpenMode = {
    Closed: 0,
    Clear: 1, 
    Cypher: 2
};

var SmartClientManager = extendObject(new Listenable(), {
    cashReceive: null,
    paid: false,

    _settings: null,
    _pinPadOpenMode: 0,

    enableRequestTimeout: false,

    pinPadOpened: false,
    deviceManager: null,
    communicator: null,
    sessionKey: null,
    ap: null,
    cardCaptureTimeout: 60000,
    requestTimeout: 60000,

    pinPadCancelEnabled: true,
    idleTimeoutHandlerEnabled: true,
    logDeviceState: true,

    alertPrinterText: false,

    denyIdleTimeoutHandler: function () {
        this.idleTimeoutHandlerEnabled = false;
    },

    allowIdleTimeoutHandler: function () {
        this.idleTimeoutHandlerEnabled = true;
    },

    getPinPadCancelEnabled: function () {
        return this.isPinPadCancelEnabled();
    },
    isPinPadCancelEnabled: function () {
        return this.pinPadCancelEnabled;
    },

    preventPinPadCancel: function () {
        this.pinPadCancelEnabled = false;
    },

    allowPinPadCancel: function () {
        this.pinPadCancelEnabled = true;
    },

    getAP: function () {
        return this.ap;
    },

    setAP: function (ap) {
        this.ap = ap;
    },

    makeChequeNum: function () {
        var num = Math.floor(Math.random() * 10000);
        return num;
    },

    makeSessionKey: function () {
        var session = "";
        session += new Date().getTime();
        var remainingLength = LENGTH_SESSION_KEY - session.length;

        for (var i = 0; i < remainingLength; i++) {
            var currNum = Math.floor(Math.random() * 10);
            session += currNum;
        }
        return session;
    },

    updateSessionKey: function () {
        var newSessionKey = this.makeSessionKey();
        this.setSessionKey(newSessionKey);
    },

    getSessionKey: function () {
        return this.sessionKey;
    },

    setSessionKey: function (sessionKey) {
        var old = this.sessionKey;
        if (old == sessionKey) return;
        this.sessionKey = sessionKey;
        smartClientCommunicator.writeSessionToLog(sessionKey);
    },

    init: function (settings) {
        var self = this,
			settings = settings || {};
        if (settings.hasOwnProperty("logDeviceState")) this.logDeviceState = settings.logDeviceState;
        if (settings.hasOwnProperty("pointNumber")) this.ap = settings.pointNumber;
        if (settings.hasOwnProperty("communicator")) this.communicator = settings.communicator;
        if (settings.hasOwnProperty("cardCaptureTimeout"))
            self.writeToLog("Инициализация объекта для работы со СмартКлиентом SmartClientManager...");
        self.writeToLog("Настройки объекта для работы со СмартКлиентом SmartClientManager: " + toJSON(settings) + ".");
        self.writeToLog("Запись версии приложения интерфейса " + VERSION + "...");
        this.communicator.writeVersionToLog(VERSION);
        self.writeToLog("Запись версии приложения интерфейса завершена.");
        if (settings.sessionKey) {
            self.session = settings.sessionKey;
            smartClientCommunicator.writeSessionToLog(self.sessionKey);
        }

        if (settings.hasOwnProperty("requestTimeout")) this.requestTimeout = settings.requestTimeout;
        if (settings.hasOwnProperty("enableRequestTimeout")) this.enableRequestTimeout = settings.enableRequestTimeout;
        this._settings = settings;
        this.deviceStatePollingIntervalMilliseconds = parseFloat(TerminalUI.UISettingsMap["INTERVAL_DEVICE_STATE_POLLING_MILLISECONDS"]);

        this.deviceManager = DeviceManager.getInstance();
        if (this.isPinPadSupported()) {
            this.initPinPadListener();
        }
        if (this.isBarcodeScannerSupported()) {
            this.initBarcodeScannerListener();
        }
        //this.obtainPointNumberAsync();

        if (this.logDeviceState) this.initDeviceStateLogging();

        self.writeToLog("Инициализация объекта для работы со СмартКлиентом SmartClientManager завершена.");
    },

    initDeviceStateLogging: function () {
        var self = this;
        this.addListener({
            smartClientManager: this,
            getDeviceDisplayNameByType: function (deviceType) {
                switch (deviceType) {
                    case "BarcodeScanner": return "Сканер штрих-кодов";
                    case "BillValidator": return "Купюроприемник";
                    case "CardReader": return "Кард-Ридер";
                    case "PinPad": return "ПинПад";
                    case "Printer": return "Принтер";
                    default: return null;
                }
            },
            logDeviceState: function (deviceName, state) {
                var selfListener = this;
                var scm = selfListener.smartClientManager;
                var deviceDisplayName = selfListener.getDeviceDisplayNameByType(deviceName);

                var msg = null;
                if (state == DeviceStates.OPERABLE) {
                    msg = formatMsg("Устройство \"%1\" работает исправно.", deviceDisplayName);
                    scm.writeStateToLog(msg);
                } else {
                    msg = formatMsg("Устройство \"%1\" не работает или работает некорректно!", deviceDisplayName);
                    scm.writeStateErrorToLog(msg);
                }

                var storageKey = "DeviceState_" + deviceName + "_";
                var firstAppRun = !!TerminalUI.isFirstAppRun;
                StorageManager.getItem(storageKey, function (storedDeviceState) {
                    if (firstAppRun || !storedDeviceState || storedDeviceState != state) {
                        if (state == "Operable") {
                            scm.writeStateToLog("Состояние устройства " + deviceDisplayName + " изменилось на " + state + ".");
                        } else {
                            scm.writeStateErrorToLog("Состояние устройства " + deviceDisplayName + " изменилось на " + state + "!");
                        }

                        StorageManager.setItem(storageKey, state, function () {
                            //ok
                        });
                    }
                });
            },
            barcodeScannerState: function (state) { this.logDeviceState("BarcodeScanner", state) },
            billValidatorState: function (state) { this.logDeviceState("BillValidator", state) },
            cardReaderState: function (state) { this.logDeviceState("CardReader", state) },
            pinPadState: function (state) { this.logDeviceState("PinPad", state) },
            printerState: function (state) { this.logDeviceState("Printer", state) }
        });
    },

    initPrinterAndBillValidatorStatePolling: function () {
        var self = this;
        var settings = self._settings;
        var stateListener = {
            billValidatorCallback: function (args) {
                if (args.paramName == "DeviceState") {
                    self.notify("billValidatorState", { state: args.paramValue });
                }
            },
            printerCallback: function (args) {
                if (args.paramName == "PrinterState") {
                    self.notify("printerState", { state: args.paramValue });
                }
            }
        };
        var pollTimeout = settings.pollTimeout ? settings.pollTimeout : this.deviceStatePollingIntervalMilliseconds;
        self.writeToLog("Временной интервал опроса устройств: " + pollTimeout + ".");
        self.writeToLog("Добавление слушателя состояний устройств...");
        self.addListener(stateListener);
        self.writeToLog("Слушатель состояний устройств добавлен.");
        self.writeToLog("Запуск потока опроса состояния купюроприемника...");
        self.billValidatorPollInterval = setInterval(function () {
            self.writeToLog("Опрос состояния купюроприемника...");
            smartClientCommunicator.stateBillValidator();
            self.writeToLog("Опрос состояния купюроприемника выполнен.");
        }, pollTimeout);
        self.writeToLog("Запуск потока опроса состояния принтера...");
        self.printerPollInterval = setInterval(function () {
            self.writeToLog("Опрос состояния принтера...");
            smartClientCommunicator.statePrinter();
            self.writeToLog("Опрос состояния принтера выполнен.");
        }, pollTimeout);
    },

    isDeviceSupported: function (deviceType) {
        return this.deviceManager.isDeviceTypeSupported(deviceType);
    },
    isPinPadSupported: function () {
        return this.isDeviceSupported("PinPad");
    },
    isBarcodeScannerSupported: function () {
        return this.isDeviceSupported("BarcodeScanner");
    },
    isCardReaderSupported: function () {
        return this.isDeviceSupported("CardReader");
    },
    isBillValidatorSupported: function () {
        return this.isDeviceSupported("BillValidator");
    },
    isPrinterSupported: function () {
        return this.isDeviceSupported("Printer");
    },

    startTerminalManager: function (password) {
        this.communicator.startTerminalManager(password);
    },

    obtainPointNumberAsync: function () {
        var self = this;
        self.writeToLog("Получение кода точки...");
        var apListener = new Listener({
            bufferCallback: function (args) {
                if (args.paramName == "AP") {
                    self.setAP(args.paramValue);
                    self.removeListener(apListener);
                    self.writeToLog("Получение кода точки завершено. Код точки: " + args.paramValue + ".");
                }
            }
        });
        this.addListener(apListener);
        this.getFieldBuffer("AP");
    },

    initPinPadListener: function () {
        var self = this;
        self.writeToLog("Подписка на события PinPad...");
        this.addListener(new Listener({
            pinPadCallback: function (args)
            {
                self.writeToLog("The pinPadCallback function was triggered. Params are " + toJSON(args));
                var pinPadCallbackInnerHandler = function (args) {
                    if (args.paramName === "PinPadLastKey") {
                        var charCode = parseInt(args.paramValue);
                        var letter = String.fromCharCode(charCode);
                        var charCodeForLogging = charCode;
                        var letterForLogging = letter;
                        if (self._pinPadOpenMode == PinPadOpenMode.Cypher) {
                            charCodeForLogging = maskString(charCode);
                            letterForLogging = maskString(letter);
                        }
                        self.writeStateToLog(formatMsg("На Пин-Паде нажата клавиша с кодом: %1", charCodeForLogging));
                        self.writeToLog("A user has pushed the pin pad btn with charcode that is " + charCodeForLogging + "a and the charcode is " + letterForLogging + " as letter.");
                        var resultArgs = { charCode: charCode, letter: letter };
                        if (PinPadCharCodes.isDigit(charCode)) {
                            self.notify("pinPadDigitPressed", resultArgs);
                        } else if (PinPadCharCodes.STAR == charCode) {
                            self.notify("pinPadStarPressed", resultArgs);
                        } else if (PinPadCharCodes.MINUS == charCode) {
                            self.notify("pinPadMinusPressed", resultArgs);
                        } else if (PinPadCharCodes.PLUS == charCode) {
                            self.notify("pinPadPlusPressed", resultArgs);
                        } else if (PinPadCharCodes.ACCEPT == charCode) {
                            self.notify("pinPadAcceptPressed", resultArgs);
                        } else if (PinPadCharCodes.CORRECTION == charCode || PinPadCharCodes.CORRECTION_OTHER == charCode) {
                            self.notify("pinPadCorrectionPressed", resultArgs);
                        } else if (PinPadCharCodes.INFO == charCode) {
                            self.notify("pinPadInfoPressed", resultArgs);
                        } else if (PinPadCharCodes.CANCEL == charCode || PinPadCharCodes.CANCEL_OTHER == charCode) {
                            self.notify("pinPadCancelPressed", resultArgs);
                        } else if (letter == ".") {
                            self.notify("pinPadDotPressed", resultArgs);
                        }
                    }
                };
                self.addOnceAsyncHandler("pinPadCallbackTriggered", function (ctx) {
                    if (!ctx.cancel) {
                        pinPadCallbackInnerHandler(ctx);
                    }
                });
                var newArgs = extendObject({}, args, {
                    state: "pinPadCallbackTriggered",
                    cancel: false,
                    originalState: args.state
                });
                self.notifyListeners(newArgs);
            }
        }));
        self.writeToLog("Подписка на события PinPad завершена.");
    },

    initBarcodeScannerListener: function () {
        var self = this;
        self.writeToLog("Подписка на события сканнера штрих кодов...");
        self.addListener({
            barcodeScannerCallback: function (paramName, paramValue) {
                self.writeToLog("Обработка события сканнера штрих кодов: paramName=" + paramName + ", paramValue=" + paramValue + "...");
                if (paramName === "BarCode") {
                    self.writeToLog("Получение считанного значения сканнером штрих кодов в текстовом виде...");
                    var readText = hex2ascii(paramValue);
                    self.writeStateToLog("Сканер Штрих-Кодов считал значение: " + paramValue);
                    self.writeToLog("Сканнер штрих кодов считал текст: \"" + readText + "\".");
                    self.notify("barcodeScannerReadValue", readText);
                }
                self.writeToLog("Обработка события сканнера штрих кодов завершена.");
            }
        });
        self.writeToLog("Подписка на события сканнера штрих кодов завершена.");
    },

    getFieldBuffer: function (key) {
        smartClientCommunicator.getFieldBuffer("AP");
    },

    statePinPad: function () {
        if (this.isPinPadSupported()) {
            this.writeStateToLog("Опрос состояния Пин-Пада...");
            this.communicator.statePinPad();
        }
    },

    openClearPad: function () {
        if (this.isPinPadSupported()) {
            this.writeStateToLog("Открытие Пин-Пада...");
            try {
                var timeStamp = new Date().getTime();
                this.writeToLog("Открытие ПинПада (timeStamp=" + timeStamp + ")...");
                smartClientCommunicator.openClearPad();
                this._pinPadOpenMode = PinPadOpenMode.Clear;
                this.writeToLog("ПинПад открыт (timeStamp=" + timeStamp + ").");
                //if (!this.pinPadCancelEnabled) this.pinPadCancelEnabled = true;
            } catch (e) {
                this.writeErrorToLog("An error has occurred while open the pin pad! The error is " + e);
            }
        }
    },

    openCipherPad: function (processingId, cardNumber, pinLength) {
        if (this.isPinPadSupported()) {
            this.writeStateToLog("Открытие Пин-Пада в режиме ввода пин-кода...");
            try {
                smartClientCommunicator.openCipherPad(processingId, cardNumber, pinLength);
                this._pinPadOpenMode = PinPadOpenMode.Cypher;
            } catch (e) {
                this.writeErrorToLog("An error has occurred while open the pin pad in the cipher mode! The error is " + e);
            }
        }
    },

    openPinPad: function () { this.openClearPad() },
    closePinPad: function () { this.closePad() },
    closePad: function () {
        if (this.isPinPadSupported()) {
            this.writeStateToLog("Закрытие Пин-Пада...");
            try {
                smartClientCommunicator.closePinPad();
                this._pinPadOpenMode = PinPadOpenMode.Closed;
            } catch (e) {
                this.writeErrorToLog("An error has occurred while the pin pad is being closed! The error is " + e);
            }
        }
    },
    readPinBlock: function () {
        if (this.isPinPadSupported()) {
            this.writeStateToLog("Считывание Пин-Блока с Пин-Пада...");
            try {
                smartClientCommunicator.readPinBlock();
            } catch (e) {
                this.writeErrorToLog("An error has occurred while read a pin block from the pin pad! The error is " + e);
            }
        }
    },

    triggerChangeSumChanged: function (sum) {
        this.notify("changeSumCallback", sum);
    },

    triggerPinPadCallback: function (paramName, paramValue)
    {
        this.notify(
            "pinPadCallback",
            {
                paramName: paramName,
                paramValue: paramValue
            });
        if (paramName == "DeviceState")
        {
            this.notify("pinPadState", paramValue);
            return;
        }

        if (paramName == "OpenCipherPad")
        {
            this.notify("pinPadCipherOpened", paramValue);
            return;
        }
    },

    triggerWMCopyDataCallback: function (paramName, paramValue) {
        this.notify("wmCopyDataCallback", {
            paramName: paramName,
            paramValue: paramValue
        });
    },

    triggerBillValidatorCallback: function (paramName, paramValue) {

        if (paramName == "Bill") {
            var bill = typeof (paramValue) == "number" ? paramValue : parseFloat(paramValue);
            this.writeStateToLog("Клиент внес купюру номиналом: " + paramValue);
            this.notify("billValidatorBill", { bill: bill });
        }

        if (paramName == "Sum") {
            var sum = parseFloat(paramValue);
            this.writeStateToLog("Сумма в купюроприемнике: " + sum.toFixed(2));
            this.notify("billValidatorSum", { sum: sum });
        }

        if (paramName == "DeviceState") {
            var state = paramValue;
            this.notify("billValidatorState", state);
        }

        if (paramName == "ButtonState") {
            this.notify("billValidatorButtonState", paramValue);
        }

        if (paramName == "ValidBill") {
            this.notify("billValidatorValidBill", paramValue);
        }

        if (paramName == "ExceededBill") {
            var billValue = parseFloat(paramValue);
            this.writeStateToLog(formatMsg("Купюроприемник возвратил купюру номиналом %1 превышающую сумму платежа", billValue));
            this.notify("billValidatorExceededBill", billValue);
        }

        if (paramName == "ExceededSum") {
            var exceededSum = parseFloat(paramValue);
            this.writeStateToLog(formatMsg("Купюроприемник возвратил купюру номиналом превышающую сумму платежа на %1", exceededSum));
            this.notify("billValidatorExceededSum", exceededSum);
        }

        this.notify("billValidatorCallback", paramName, paramValue);
    },

    triggerAmountDiffRequestCallback: function (result, response) {
        this.writeToLog("Notifying listeners about an amount diff request callback... Result is " + result + ". Response is " + response + ".");
        this.notify("AmountDiffRequestCallback", { result: result, response: response, responseData: response });
        this.writeToLog("Listeners were notified about an amount diff request callback. Result is " + result + ". Response is " + response + ".");
    },

    triggerOfflineRequestCallback: function (result, response) {
        this.writeToLog("Notifying listeners about an offline request callback... Result is " + result + ". Response is " + response + ".");

        //result = 0;
        //var response = "RESULT=0\nERROR=0\nANSWER_DATA=<?xml version=\"1.0\" encoding=\"Windows-1251\"?><root><RRN>022700006420</RRN><AUTH_CODE>680901</AUTH_CODE><RESPONSE_CODE>00</RESPONSE_CODE><ACQUIRING_CODE>B000179</ACQUIRING_CODE><FORWARDING_CODE>EN00123</FORWARDING_CODE><TRANSACTION_FEE></TRANSACTION_FEE></root>";

        this.notify("offlineRequestCallback", { result: result, response: response, responseData: response });
        this.writeToLog("Listeners were notified about an offline request callback. Result is " + result + ". Response is " + response + ".");
    },

    triggerOnlineRequestCallback: function (result, error, responseData) {
        this.writeStateToLog("Пришел ответ от шлюза: " + responseData + ".");
        this.writeToLog("The onlineRequestCallback function was triggered. Result is " + result + " and responseData is " + responseData + ".");
        this.notify("onlineRequestCallback", { result: result, error: error, responseData: responseData });
    },

    triggerBufferCallback: function (paramName, paramValue) {
        this.notify("bufferCallback", { paramName: paramName, paramValue: paramValue });
    },

    triggerPrinterCallback: function (paramName, paramValue) {
        this.writeToLog("Notifying about a triggered printer callback. ParamName is " + paramName + ". ParamValue is " + paramValue + ".");
        this.notify("printerCallback", { paramName: paramName, paramValue: paramValue });
        if (paramName == "DeviceState") {
            this.notify("printerState", paramValue);
        }
        this.writeToLog("Notified about a triggered printer callback. ParamName is " + paramName + ". ParamValue is " + paramValue + ".");
    },

    triggerScreenPanelCallback: function (paramName, paramValue) {
        if (paramName == "Status" || paramName == "Screen") {
            if (paramValue == "False" || paramValue == "Lock") {
                this.notify("screenPanelIdling");

                //For interoperability
                if (this.idleTimeoutHandlerEnabled) {
                    this.notify("screenPanelCallback", paramName, paramValue);
                }
                this.notify("screenPanelCallbackForced", paramName, paramValue);
            } else {
                this.notify("screenPanelActive.");
            }
        }
    },

    triggerBarcodeScannerCallback: function (paramName, paramValue) {
        this.notify("barcodeScannerCallback", paramName, paramValue);
        if (paramName == "DeviceState") this.notify("barcodeScannerState", paramValue);
    },

    triggerCardReaderCallback: function (paramName, paramValue) {
        this.notify("cardReaderCallback", paramName, paramValue);
        if (paramName == "DeviceState") this.notify("cardReaderState", paramValue);
    },

    triggerTerminalManagerCallback: function (paramName, paramValue) {
        this.notify("terminalManagerCallback", paramName, paramValue);
        switch (paramName) {
            case "PasswordStatus": this.notify("terminalManagerPasswordStatus", paramValue);
                break;
            case "Started": this.notify("terminalManagerStarted", paramValue);
                break;
        }
    },

    triggerTransportCardSuitableRoute: function (paramName, paramValue) {
        this.writeToLog("A response has received from the Smart Way software.");
        this.notify("transportCardSuitableRouteCallback", paramName, paramValue);
    },

    //TransportCardSmartWayReader
    sendDataToContactlessCardReader: function (requestDetailXml) {
        this.writeToLog("A request has sent to the Smart Way software.");
        this.communicator.sendDataToContactlessCardReader(requestDetailXml);
    },

    stateCardReader: function () {
        if (this.isCardReaderSupported()) {
            this.writeStateToLog("Опрос состояния кард-ридера...");
            smartClientCommunicator.stateCardReader();
        } else {
            this.triggerCardReaderCallback("DeviceState", "NotOperable");
        }
    },

    //CardReader
    openCardReader: function () {
        if (this.isCardReaderSupported()) {
            this.writeStateToLog("Открытие Кард-Ридера...");
            smartClientCommunicator.openCardReader();
        }
    },
    closeCardReader: function () {
        if (this.isCardReaderSupported()) {
            this.writeStateToLog("Закрытие Кард-Ридера...");
            smartClientCommunicator.closeCardReader();
        }
    },
    ejectCard: function () {
        if (this.isCardReaderSupported()) {
            this.writeStateToLog("Возврат карты...");
            this.notify("cardEjecting");
            smartClientCommunicator.cardEject();
            this.notify("cardEjected");
            this.writeStateToLog("Возврат карты выполнен. Обработка взятия карты клиентом...");
            this.handleCardTakingAsync(this.cardCaptureTimeout);
        }
    },
    captureCard: function () {
        if (this.isCardReaderSupported()) {
            this.writeStateToLog("Захват карты...");
            this.notify("cardCapturing");
            smartClientCommunicator.cardCapture();
            this.notify("cardCaptured");
            this.writeStateToLog("Захват карты выполнен.");
        }
    },

    stateCardResult: function () {
        if (this.isCardReaderSupported()) {
            this.writeStateToLog("Получение результата ввода карты...");
            smartClientCommunicator.stateCardResult();
        }
    },
    stateCardPosition: function () {
        if (this.isCardReaderSupported()) {
            this.writeStateToLog("Опрос позиции карты...");
            smartClientCommunicator.stateCardPosition();
        }
    },

    pollCardPositionAsync: function (callback) {
        if (this.isCardReaderSupported()) {
            this.writeToLog("Опрос позиции карты...");
            var self = this;
            var listener = {
                cardReaderCallback: function (paramName, paramValue) {
                    if (paramName == "CardPosition") {
                        self.writeToLog("Опрос позиции карты выполнен. Позиция карты: " + paramValue);
                        callback(paramValue);
                    }
                }
            };

            this.once(listener);
            this.stateCardPosition();
        }
    },

    handleCardTakingAsync: function (callback) {
        this.writeToLog("Контроль взятия карты клиентом запущен.");
        var self = this;
        setTimeout(function () {
            self.pollCardPositionAsync(function (position) {
                if (position == "Outside") {
                    self.writeStateToLog("Клиент забрал карту.");
                } else if (position == "Present") {
                    self.writeStateToLog("Клиент НЕ забрал карту. Переход к захвату карты...");
                    self.captureCard();
                }
            });
        }, this.cardCaptureTimeout);
    },

    //Bill Validator
    openBillValidator: function (maxSum) {
        maxSum = maxSum || 0;
        if (this.isBillValidatorSupported()) {
            if (TerminalUI.UISettingsMap["BILL_VALIDATOR_MAX_SUM_BILL_ENABLED"] == "0") {
                maxSum = null;
            }
            var sessionNum = this.getSessionKey();
            this.writeStateToLog(formatMsg("Открытие купюроприемника сессия=%1 макс.сумма=%2...", sessionNum, maxSum || ""));
            if (maxSum != null) {
                smartClientCommunicator.openBillValidator(sessionNum, maxSum);
            } else {
                smartClientCommunicator.openBillValidator(sessionNum);
            }
        }
    },

    closeBillValidatorAsync: function (callback)
    {
        var self = this;
        var triggerCallback = function (sum)
        {
            self.writeToLog("closeBillValidatorAsync: triggerCallback");
            self.removeHandler("billValidatorCallback", pollDescriptionBillValidatorHandler);
            if (callback)
            {
                callback(sum);
            }
        };
        var timeoutObserver = null;
        if (this.enableRequestTimeout)
        {
            timeoutObserver = this.observeRequestTimeout(
            {
                timeoutHandler: function ()
                {
                    self.removeHandler("billValidatorCallback", pollDescriptionBillValidatorHandler);
                    self.writeStateErrorToLog("Операция запроса PollDescription Купюроприемника прервана. Истекло время ожидания.");
                    self.notify("requestTimeout", { targetAsyncMethod: "closeBillValidator" });
                    self.notify("closeBillValidatorRequestTimeout", {});
                    triggerCallback(0);
                }
            });
        }

        var pollDescriptionBillValidatorHandler = function (paramName, paramValue)
        {
            // Ожидание состояния - купюроприемник закрыт: Unit Disabled
            if (paramName == "PollDescription" && paramValue == "Unit Disabled")
            {
                if (timeoutObserver)
                {
                     timeoutObserver.success();
                }

                self.writeToLog("triggerCallback(0)");
                triggerCallback(0);
            }
        };
        if (this.isBillValidatorSupported())
        {
            self.addHandler("billValidatorCallback", pollDescriptionBillValidatorHandler);
            self.closeBillValidator();
            if (timeoutObserver)
            {
                timeoutObserver.start();
            }
        }
        else
        {
            triggerCallback(0);
        }
    },

    closeBillValidator: function () {
        if (this.isBillValidatorSupported()) {
            this.writeStateToLog("Закрытие купюроприемника...");
            var sessionNum = this.getSessionKey();
            smartClientCommunicator.closeBillValidator(sessionNum);
        }
    },

    stateBillValidator: function () {
        if (this.isBillValidatorSupported()) {
            this.writeStateToLog("Опрос состояния купюроприемника...");
            smartClientCommunicator.stateBillValidator();
        }
    },

    stateBillValidatorAsync: function (callback)
    {
        var triggerCallback = function (state)
        {
            if (callback)
            {
                callback(state);
            }
        };
        var self = this;
        var timeoutObserver = null;
        if (this.enableRequestTimeout)
        {
            timeoutObserver = this.observeRequestTimeout(
            {
                timeoutHandler: function ()
                {
                    self.removeHandler("billValidatorState", stateBillValidatorHandler);
                    self.writeStateErrorToLog("Операция запроса состояния Купюроприемника прервана. Истекло время ожидания.");
                    self.notify("requestTimeout", { targetAsyncMethod: "stateBillValidator" });
                    self.notify("stateBillValidatorRequestTimeout", {});
                    triggerCallback("NotOperable");
                }
            });
        }

        stateBillValidatorHandler = function (state)
        {
            if (timeoutObserver)
            {
                timeoutObserver.success();
            }

            triggerCallback(state);
        };
        if (this.isBillValidatorSupported())
        {
            self.addOnceHandler("billValidatorState", stateBillValidatorHandler);
            self.stateBillValidator();
            if (timeoutObserver)
            {
                timeoutObserver.start();
            }
        }
        else
        {
            triggerCallback("NotOperable");
        }
    },

    //Printer
    statePrinter: function () {
        var self = this;
        if (this.isPrinterSupported()) {
            this.writeStateToLog("Опрос состояния принтера...");
            try {
                this.writeToLog("Trying to get the printer state...");
                smartClientCommunicator.statePrinter();
                this.writeToLog("The printer state command has been invoked successfully.");
            } catch (e) {
                this.writeErrorToLog("An error has occurred while get the printer state! The error is " + e);
            }
        } else {
            self.writeStateErrorToLog("Принтер недоступен!");
            this.notify("printerState", "NotOperable");
        }
    },

    statePrinterAsync: function (callback)
    {
        var self = this;
        var timeoutObserver = null;
        if (this.enableRequestTimeout)
        {
            timeoutObserver = this.observeRequestTimeout(
            {
                timeoutHandler: function ()
                {
                    self.removeHandler("printerState", statePrinterHandler);
                    self.writeStateErrorToLog("Операция запроса состояния Принтера прервана. Истекло время ожидания.");
                    self.notify("requestTimeout", { targetAsyncMethod: "statePrinter" });
                    self.notify("statePrinterRequestTimeout", {});
                    self.notify("printerState", "NotOperable");
                }
            });
        }

        var callbackCtx = { error: null, state: null };
        var triggerCallback = function ()
        {
            if (callback)
            {
                callback(callbackCtx);
            }
        };
        var statePrinterHandler = function (state)
        {
            if (timeoutObserver)
            {
                timeoutObserver.success();
            }

            callbackCtx.state = state;
            triggerCallback();
        };

        this.addOnceHandler("printerState", statePrinterHandler);
        this.statePrinter();
        if (timeoutObserver)
        {
            timeoutObserver.start();
        }
    },

    printText: function (text, amountAll, callback) {
        var self = this;
        var triggerSuccess = function ()
        {
            if (callback)
            {
                callback({ success: true });
            }
        };
        var isCard = typeof (CARD_AVAILABLE) != "undefined" && CARD_AVAILABLE === true;
        var isCash = !isCard;
        if (self.isPrinterSupported()) {
            self.writeStateToLog("Печать чека...");
            
            var funcPrintText = function () {
                var loggingService = TerminalUI.loggingService;
                loggingService.trace("Printing a text...");
                if (self.alertPrinterText) {
                    loggingService.trace("The alert text printing feature is ON and the text is being shown with alert()...");
                    alert(text);
                } else {
                    if (TerminalUI.UISettingsMap["PRINTER_TYPE"] == "FISCAL") {
                        var amountAllKopeyki = amountAll * 100;
                        loggingService.trace("PRINTER_TYPE is FISCAL. Printing the text with amountAll=%1 and isCash=%2...", amountAllKopeyki, isCash);
                        smartClientCommunicator.printToFiscalPrinter(text, amountAllKopeyki, isCash);
                    } else {
                        loggingService.trace("PRINTER_TYPE is TEXT. Printing the text...");
                        smartClientCommunicator.printToPrinter(text);
                    }
                }

                triggerSuccess();
            };

            if (TerminalUI.UISettingsMap["CONFIRM_TEXT_PRINTING"] == "1") {

                var timeoutInterval = setTimeout(function () {
                    funcPrintText();
                }, self.requestTimeout);

                var $containerCheque = $("<div class='container-visual-virtual-cheque' />").hide().appendTo("#divWrapper");
                var $containerChequeInner = $("<div class='container-visual-virtual-cheque-inner' />").appendTo($containerCheque);

                var $preCheque = $("<pre class='visual-virtual-cheque' />").appendTo($containerChequeInner).text(text);
                var msgConfirmTextPrinting = TerminalUI.UIMessageMap["CONFIRM_TEXT_PRINTING"];
                var $askPrint = $("<div class='block-ask-print' style='font-weight:bold' />").text(msgConfirmTextPrinting).appendTo($containerCheque);

                var $containerButtons = $("<div class='nav-btn-container' />").appendTo($containerCheque);

                var $btnPrint = $("<div class='th-hyperlink th-btn-nav btn-nav loggable th-btn-nav-nav_bg_ok btn-nav-nav_bg_ok' />").appendTo($containerButtons);

                $btnPrint.click(function () {
                    $containerCheque.remove();
                    clearTimeout(timeoutInterval);
                    funcPrintText();
                });

                var $btnOk = $("<div class='th-hyperlink th-btn-nav btn-nav loggable th-btn-nav-nav_bg_cancel btn-nav-nav_bg_cancel' />").appendTo($containerButtons);

                $btnOk.click(function () {
                    clearTimeout(timeoutInterval);
                    $containerCheque.remove();

                    triggerSuccess();
                });

                $containerCheque.show();
            } else {
                funcPrintText();
            }
        } else {
            triggerSuccess();
        }
    },

    //BarcodeScanner
    openBarcodeScanner: function () {
        if (this.isBarcodeScannerSupported()) {
            this.writeStateToLog("Открытие Сканера Штрих-кодов...");
            this.writeToLog("Открытие сканнера штрих кодов...");
            this.notify("barcodeScannerOpening");
            smartClientCommunicator.openScanner();
            this.notify("barcodeScannerOpened");
            this.writeToLog("Сканнер штрих кодов открыт.");
        }
    },
    closeBarcodeScanner: function () {
        if (this.isBarcodeScannerSupported()) {
            this.writeStateToLog("Закрытие Сканера Штрих-кодов...");
            this.writeToLog("Закрытие сканнера штрих кодов...");
            this.notify("barcodeScannerClosing");
            smartClientCommunicator.closeScanner();
            this.notify("barcodeScannerClosed");
            this.writeToLog("Сканнер штрих кодов закрыт.");
        }
    },

    makeFieldsForGateway: function (fields) {
        var EMPTY_FIELD_VALUE = "";
        var copyFields = {};
        var arr = [];
        var re = /^field(\d+)_(\d+)$/;
        for (var key in fields) {
            if (!key) continue;
            var order = 1;
            var id = key.substr(5);
            if (re.test(key)) {
                var matches = re.exec(key);
                id = matches[1];
                order = matches[2];
            }
            arr.push({ key: key, id: id, order: order, sortKey: parseInt(order.toString() + id.toString()) });
        }
        arr.sort(function (a, b) { return a.sortKey - b.sortKey; });
        var resultArr = [];
        for (var i = 0; i < arr.length; i++) {
            var currArrItem = arr[i];
            var fieldValue = fields[currArrItem.key];
            if (typeof (fieldValue) == "undefined" || fieldValue == null) {
                fieldValue = EMPTY_FIELD_VALUE;
            }
            resultArr.push("field" + currArrItem.id + "=" + fieldValue);
        }
        var dataToTransfer = resultArr.join("&");
        return dataToTransfer;
    },

    setFieldBuffer: function (key, val) {
        var valString = "";
        if (typeof (val) != "undefined" && val != null) {
            if (typeof (val) == "string") {
                valString = val;
            } else {
                valString = val.toString();
            }
        }
        this.communicator.setFieldBuffer(key, valString);
        return this;
    },

    composeRequestForGateway: function (request) {
        this.setFieldBuffer("AP", this.ap);
        this.setFieldBuffer("REQ_TYPE", request.type);
        this.setFieldBuffer("SESSION", this.sessionKey);
        if (request.hasOwnProperty("date")) {
            var formattedDate = formatDate(request.date, FS.TerminalUI.Settings.dateLongPattern);
            this.setFieldBuffer("DATE", formattedDate);
            this.setFieldBuffer("INIT_DATETIME", formattedDate);
        }
        if (request.hasOwnProperty("count")) this.setFieldBuffer("COUNT", request.count);
        if (request.hasOwnProperty("cabinetId")) this.setFieldBuffer("CAB_ID", request.cabinetId);
        if (request.hasOwnProperty("accountId")) this.setFieldBuffer("ACCOUNT_ID", request.accountId);
        if (request.hasOwnProperty("userId")) this.setFieldBuffer("USER_ID", request.userId);
        if (typeof (request.operatorId) != "undefined") this.setFieldBuffer("OP_ID", request.operatorId);
        if (typeof (request.fields) != "undefined") {
            var fieldsForGateway = this.makeFieldsForGateway(request.fields);
            this.setFieldBuffer("FIELDS", fieldsForGateway);
        }
        if (typeof (request.amount) != "undefined") this.setFieldBuffer("AMOUNT", request.amount);
        this.composeRequestForUpperCaseParams(request);
    },

    cleanUpFieldsBuffer: function (request) {
        this.communicator.clearBuffer();
    },

    composeAmountDiffRequest: function (request) {
        this.setFieldBuffer("REQ_TYPE", request.type);
        this.setFieldBuffer("AP", this.ap);
        this.setFieldBuffer("SESSION", this.sessionKey);
        this.setFieldBuffer("AMOUNT_CASH", request.amount_cash);
        this.setFieldBuffer("AMOUNT_PAY", request.amount_pay);
        this.setFieldBuffer("NOTES", request.notes);

        this.composeRequestForUpperCaseParams(request);
    },

    composeOfflineRequest: function (request) {
        var fieldsForGateway = this.makeFieldsForGateway(request.fields);
        this.setFieldBuffer("OP", request.op);
        this.setFieldBuffer("AP", this.ap);
        this.setFieldBuffer("REQ_TYPE", request.type);
        this.setFieldBuffer("SESSION", this.sessionKey);
        this.setFieldBuffer("OP_ID", request.operatorId);
        this.setFieldBuffer("FIELDS", fieldsForGateway);
        this.setFieldBuffer("AMOUNT", request.amount.toFixed(2));
        this.setFieldBuffer("AMOUNT_ALL", request.amountAll.toFixed(2));
        this.setFieldBuffer("CHEQUE_NUM", request.chequeNum);
        this.setFieldBuffer("INIT_DATETIME", formatDate(request.initDateTime, FS.TerminalUI.Settings.dateLongPattern));

        if (request.hasOwnProperty("cabinetId")) this.setFieldBuffer("CAB_ID", request.cabinetId);
        if (request.hasOwnProperty("userId")) this.setFieldBuffer("CAB_USER", request.userId);

        if (request.hasOwnProperty("pinBlock")) this.setFieldBuffer("PINBLOCK", request.pinBlock);
        if (request.hasOwnProperty("track2")) this.setFieldBuffer("TRACK2", request.track2);
        if (request.hasOwnProperty("amountCard")) this.setFieldBuffer("AMOUNT_CARD", request.amountCard);
        this.composeRequestForUpperCaseParams(request);
    },

    composeRequestForUpperCaseParams: function (request) {
        for (var key in request) {
            if (/^([A-Z][A-Z0-9_]*)$/.test(key)) {
                this.setFieldBuffer(key, request[key]);
            }
        }
    },

    observeRequestTimeout: function (args) {

        var self = this;
        var timeout = this.requestTimeout;
        var timeElapsed = 0;
        var step = 100;
        var observingInterval = null;
        var ctx = {
            triggerTimeoutEvent: function () {
                if (this.ontimeout != null) {
                    this.ontimeout();
                }
            },
            start: function () {
                observingInterval = setInterval(function () {
                    timeElapsed += step;
                    if (timeElapsed == timeout) {
                        ctx.stop();
                        ctx.triggerTimeoutEvent();
                    }
                }, step);
            },
            stop: function () { clearInterval(observingInterval) },
            ontimeout: args.timeoutHandler,
            success: function () {
                ctx.stop();
            }
        };

        if (args.immediateStart) {
            ctx.start();
        }

        return ctx;
    },

    sendAmountDiffRequest: function(request) {
        this.writeStateToLog("Отправка запроса AmountDiff...");
        var requestExt = extendObject({ type: RequestTypes.AMOUNT_DIFF }, request);

        this.composeAmountDiffRequest(requestExt);
        if (requestExt.emulate) {
            this.emulateAmountDiffRequest(requestExt);
        } else {
            this.communicator.callOperationRequest();
        }
        this.cleanUpFieldsBuffer();
    },

    sendAmountDiffRequestAsync: function (requestWithCallbackComposite)
    {
        var self = this;
        setTimeout(function ()
        {
            var request = requestWithCallbackComposite.request;
            var callback = requestWithCallbackComposite.callback;
            var timeoutObservingCtx = null;
            if (self.enableRequestTimeout)
            {
                timeoutObservingCtx =  self.observeRequestTimeout(
                {
                    timeoutHandler: function ()
                    {
                        self.removeListener(listener);
                        self.writeStateErrorToLog("При выполнении AmountDiff запроса к модулю TerminalExplorer операция прервана по ТАЙМАУТУ.");
                        var options = { targetAsyncMethod: "sendAmountDiffRequest" };
                        self.notify("requestTimeout", options);
                        self.notify("amountDiffRequestTimeout", options);
                    }
                });
            }

            var listener =
            {
                amountDiffRequestCallback: function (args)
                {
                    self.writeToLog("The AmountDiff request callback was invoked. Checking request timeout and if it is true then success that...");
                    if (timeoutObservingCtx)
                    {
                        self.writeToLog("The request timeout is enabled. Successing that...");
                        timeoutObservingCtx.success();
                    }
                    self.writeToLog("Parsing gateway result response data...");
                    var responseDataMap = self.parseGatewayResult(args.responseData);
                    self.writeToLog("The response data were parsed. Extending the result args with the parsed response map...");
                    var extendedResult = extendObject({}, args, { responseMap: responseDataMap });
                    self.writeToLog("The result args were extended. Triggering the callback with the extended result...");
                    callback(extendedResult);
                    self.writeToLog("The callback was triggerred.");
                }
            };

            self.writeToLog("Adding a listener to handle AmountDiff request callback only once...");
            self.once(listener);
            self.writeToLog("The listener was added. Sending an AmountDiff request...");
            self.sendAmountDiffRequest(request);
            self.writeToLog("The request was sent. Checking the request timeout is enabled...");
            if (timeoutObservingCtx)
            {
                self.writeToLog("The request timeout is enabled. Starting the observing interval...");
                timeoutObservingCtx.start();
            }
        },
        500);
    },

    sendOfflineRequestAsync: function (requestWithCallbackComposite)
    {
        var self = this;
        setTimeout(function ()
        {
            var request = requestWithCallbackComposite.request;
            var callback = requestWithCallbackComposite.callback;
            var timeoutObservingCtx = null;
            if (self.enableRequestTimeout)
            {
                timeoutObservingCtx = self.observeRequestTimeout(
                {
                    timeoutHandler: function ()
                    {
                        self.removeListener(listener);
                        self.writeStateErrorToLog("При выполнении OFFLINE запроса к модулю TerminalExplorer операция прервана по ТАЙМАУТУ.");
                        var options = { targetAsyncMethod: "sendOfflineRequest" };
                        self.notify("requestTimeout", options);
                        self.notify("offlineRequestTimeout", options);
                    }
                });
            }

			var listener = 
            {
                offlineRequestCallback: function (args)
                {
                    self.writeToLog("The offline request callback was invoked. Checking request timeout and if it is true then success that...");
                    if (self.enableRequestTimeout)
                    {
                        self.writeToLog("The request timeout is enabled. Successing that...");
                        if (timeoutObservingCtx)
                        {
                            timeoutObservingCtx.success();
                        }
                    }

                    self.writeToLog("Parsing gateway result response data...");
                    var responseDataMap = self.parseGatewayResult(args.responseData);
                    self.writeToLog("The response data were parsed. Extending the result args with the parsed response map...");
                    var extendedResult = extendObject({}, args, { responseMap: responseDataMap });
                    self.writeToLog("The result args were extended. Triggering the callback with the extended result...");
                    callback(extendedResult);
                    self.writeToLog("The callback was triggerred.");
                }
            };
            self.writeToLog("Adding a listener to handle offline request callback only once...");
            self.once(listener);
            self.writeToLog("The listener was added. Sending an offline request...");
            self.sendOfflineRequest(request);
            self.writeToLog("The request was sent. Checking the request timeout is enabled...");
            if (self.enableRequestTimeout)
            {
                self.writeToLog("The request timeout is enabled. Starting the observing interval...");
                if (timeoutObservingCtx)
                {
                    timeoutObservingCtx.start();
                }
            }
        },
        500);
    },

    sendOfflineRequest: function (request) {
        var isCardRecharge = request.hasOwnProperty("isCardRecharge") && request.isCardRecharge === true;

        this.writeStateToLog("Отправка запроса ОФФЛАЙН...");
        var requestExt = extendObject({ type: RequestTypes.DO_PAYMENT }, request);

        this.writeToLog("typeof `CARD_AVAILABLE`:" + typeof(CARD_AVAILABLE));
        if (typeof (CARD_AVAILABLE) != "undefined") {
            this.writeToLog("Состояние `CARD_AVAILABLE`:" + CARD_AVAILABLE);
        }

        if (typeof (CARD_AVAILABLE) != "undefined" && CARD_AVAILABLE == true) {
            this.writeToLog("Тип запроса будет изменен с " + requestExt.type + " на " + FS.Gateway.RequestTypes.PayCardRequest + " т.к. оплата производится по банковской карте номер \"" + getCardNumberToShare(CARD_NUMBER) + "\".");
            requestExt.type = FS.Gateway.RequestTypes.PayCardRequest;
            requestExt["TOTALS_COUNTER"] = "0";
            var newDate = new Date();
            var totalsDate = new Date(newDate.getFullYear(), newDate.getMonth(), newDate.getDate());
            requestExt["TOTALS_DATETIME"] = formatDate(totalsDate, FS.TerminalUI.Settings.dateLongPattern);
            requestExt["TERMINALID"] = CARD_TERMINAL_ID;
            requestExt["PINBLOCK"] = CARD_PINBLOCK;
            requestExt["PINKEYKCV"] = CARD_PINKEYKCV;
            requestExt["CARDNUMBER"] = CARD_NUMBER;
            requestExt["TRACK2"] = CARD_TRACK2;
            requestExt["STAN"] = CardManager.generateStan();
            requestExt["AMOUNT_NONCASH"] = request["amountAll"];
        }

        this.writeToLog("typeof `isCardRecharge`:" + typeof (isCardRecharge));
        this.writeToLog("Состояние `isCardRecharge`:" + isCardRecharge);

        if (isCardRecharge) {
            var requestTypeCardRecharge = TerminalUI.UISettingsMap["CARD_RECHARGE_PROPER_REQUEST_USED"] == "1" ? FS.Gateway.RequestTypes.RechargeCardRequest : RequestTypes.DO_PAYMENT;

            this.writeToLog("typeof `CARD_NUMBER`:" + typeof (CARD_NUMBER));
            this.writeToLog("Состояние `CARD_NUMBER`:" + getCardNumberToShare(CARD_NUMBER));
        
            this.writeToLog("Тип запроса будет изменен с " + requestExt.type + " на " + requestTypeCardRecharge + " т.к. производится пополнение банковской карты номер \"" + getCardNumberToShare(CARD_NUMBER) + "\".");
            requestExt.type = requestTypeCardRecharge;
            requestExt["AMOUNT_NONCASH"] = 0;
        }
        this.composeOfflineRequest(requestExt);
        if (requestExt.emulate) {
            this.emulateOfflineRequest(requestExt);
        } else {
            this.communicator.callOperationRequest();
        }
        this.cleanUpFieldsBuffer();
    },

    // Emulate an online request against the gateway using specified result, error and reponseData. Also, you can specify a delay to trigger callback
    emulateAmountDiffRequest: function (request) {
        var self = this;
        var emulate = request.emulate;
        var emulateResult = emulate.hasOwnProperty("result") ? emulate.result : 0;
        var emulateError = emulate.hasOwnProperty("error") ? emulate.error : 0;
        var defaultResponseData = "RESULT=" + emulateResult + "\nERROR=" + emulateError;
        var emulateResponseData = emulate.responseData ? emulate.responseData : defaultResponseData;
        var responseDict = SmartClientManager.parseGatewayResult(emulateResponseData);
        if (!emulate.hasOwnProperty("result")) {
            emulateResult = responseDict["RESULT"];
        }
        if (!emulate.hasOwnProperty("error")) {
            emulateError = responseDict["ERROR"];
        }
        var emulateDelay = emulate.delay ? emulate.delay : 0;
        setTimeout(function () {
            self.triggerAmountDiffRequestCallback(emulateResult, emulateResponseData);
        }, emulateDelay);
    },

    // Emulate an online request against the gateway using specified result, error and reponseData. Also, you can specify a delay to trigger callback
    emulateOfflineRequest: function (request) {
        var self = this;
        var emulate = request.emulate;
        var emulateResult = emulate.hasOwnProperty("result") ? emulate.result : 0;
        var emulateError = emulate.hasOwnProperty("error") ? emulate.error : 0;
        var defaultResponseData = "RESULT=" + emulateResult + "\nERROR=" + emulateError;
        var emulateResponseData = emulate.responseData ? emulate.responseData : defaultResponseData;
        var responseDict = SmartClientManager.parseGatewayResult(emulateResponseData);
        if (!emulate.hasOwnProperty("result")) {
            emulateResult = responseDict["RESULT"];
        }
        if (!emulate.hasOwnProperty("error")) {
            emulateError = responseDict["ERROR"];
        }
        var emulateDelay = emulate.delay ? emulate.delay : 0;
        setTimeout(function () {
            self.triggerOfflineRequestCallback(emulateResult, emulateResponseData);
        }, emulateDelay);
    },

    //Send an online request via the gateway
    sendOnlineRequest: function (request) {
        this.writeStateToLog("Отправка запроса ОНЛАЙН в шлюз: RequestType=" + request.type + "...");
        this.composeRequestForGateway(request);
        if (request.emulate) {
            this.emulateOnlineRequest(request);
        } else {
            this.communicator.callGatewayRequest();
        }
        this.cleanUpFieldsBuffer();
    },

    // Emulate an online request against the gateway using specified result, error and reponseData. Also, you can specify a delay to trigger callback
    emulateOnlineRequest: function (request) {
        var self = this;
        var emulate = request.emulate;
        var emulateResult = emulate.result ? emulate.result : 0;
        var emulateError = emulate.error ? emulate.error : 0;
        var defaultResponseData = "RESULT=" + emulateResult + "\nERROR=" + emulateError;
        var emulateResponseData = emulate.responseData ? emulate.responseData : defaultResponseData;
        var emulateDelay = emulate.delay ? emulate.delay : 0;
        setTimeout(function () {
            self.triggerOnlineRequestCallback(emulateResult, emulateError, emulateResponseData);
        }, emulateDelay);
    },

    sendOnlineRequestAsync: function (options)
    {
        var self = this;
        setTimeout(function ()
        {
            var request = options.request;
            var callback = options.callback;
            var timeoutObservingCtx = null;
            if (self.enableRequestTimeout)
            {
                timeoutObservingCtx = self.observeRequestTimeout(
                {
                    timeoutHandler: function ()
                    {
                        self.removeListener(listener);
                        self.writeStateErrorToLog("При выполнении ONLINE запроса к модулю TerminalExplorer операция прервана по ТАЙМАУТУ.");
                        options = $.extend({}, options, { targetAsyncMethod: "sendOnlineRequest" });
                        self.notify("requestTimeout", options);
                        self.notify("onlineRequestTimeout", options);
                    }
                })
            }
            
            var listener =
            {
                onlineRequestCallback: function (args)
                {
                    if (timeoutObservingCtx)
                    {
                        timeoutObservingCtx.success();
                    }

                    var responseDataMap = self.parseGatewayResult(args.responseData);
                    callback(extendObject({}, args, { responseMap: responseDataMap }));
                }
            };
            self.once(listener);
            self.sendOnlineRequest(request);
            if (timeoutObservingCtx)
            {
                timeoutObservingCtx.start();
            }
        },
        500);
    },

    parseGatewayResult: function (responseRaw) {
        var map = {};
        if (responseRaw) {
            lines = responseRaw.split(';');
            parseLine = function (line) {
                var match = line.match(/^([A-Z0-9_]+)=(.*)$/);
                if (match != null) {
                    var key = match[1];
                    var value = match[2];
                    return { key: key, value: value };
                } else {
                    return null;
                }
            };
			i = 0;
            for (; i < lines.length; i++) {
                var line = lines[i];
                if (line) {
                    var pair = parseLine(line);
                    if (pair != null) {
                        map[pair.key] = pair.value;
                    }
                }
            }
        }
        return map;
    },

    checkInputDataAsync: function (args) {
        var self = this,
			type = RequestTypes.INPUT_DATA_VALIDATION,
			operatorId = args.operatorId,
			amount = 0,
			fields = args.fields,
			callback = args.callback,
			ap = this.getAP(),
			sessionKey = this.getSessionKey();

        if (typeof (args.amount) == "number" && args.amount) {
            amount = args.amount;
        }

        var request = {
            ap: ap,
            sessionKey: sessionKey,
            type: type,
            operatorId: operatorId,
            fields: fields,
            amount: amount
        };

        if (args.emulate) {
            request.emulate = args.emulate;
        }

        if (!IS_FIELDS_CHECKING_ENABLED) {
            var callbackArgs = { result: GatewayResults.SUCCESS, responseData: "" };
            callback(callbackArgs);
            return;
        }

        this.sendOnlineRequestAsync({
            request: request,
            callback: callback
        });
    },

    _resolveLogMsg: function (msg) {
        var resolvedMsg = msg;
        if (TerminalUI && TerminalUI.UIMessageMap && TerminalUI.UIMessageMap.hasOwnProperty(msg)) {
            resolvedMsg = TerminalUI.UIMessageMap[msg];
        }
        return resolvedMsg;
    },

    writeErrorToLog: function (message) {
        message = this._resolveLogMsg(message);
        try {
            smartClientCommunicator.writeErrorToLog(message);
        } catch (e) {
            alert(e);
        }
    },

    writeToLog: function (message) {
        message = this._resolveLogMsg(message);
        try {
            smartClientCommunicator.writeToLog(message);
        } catch (e) {
            this.writeErrorToLog("An error has occurred while write a message to the log. The message is \"" + message + "\". The error is \"" + e.toString() + "\".");
        }
    },
    writeStateToLog: function (msg) {
        msg = this._resolveLogMsg(msg);
        try {
            this.communicator.writeStateToLog(msg);
        } catch (e) {
        }
    },
    writeStateErrorToLog: function (msg) {
        msg = this._resolveLogMsg(msg);
        try {
            this.communicator.writeStateErrorToLog(msg);
        } catch (e) {
        }
    }
});

function pinPadCallback(paramName, paramValue) {
	SmartClientManager.triggerPinPadCallback(paramName, paramValue);
};

function wmCopyDataCallback(paramName, paramValue) {
	SmartClientManager.triggerWMCopyDataCallback(paramName, paramValue);
};

function billValidatorCallback(paramName, paramValue) {
 	SmartClientManager.triggerBillValidatorCallback(paramName, paramValue);
};

function gatewayRequestCallback(result, error, responseData) {
	SmartClientManager.triggerOnlineRequestCallback(result, error, responseData);
};

function bufferCallback(paramName, paramValue) {
	SmartClientManager.triggerBufferCallback(paramName, paramValue);	
};

function operationRequestCallback(result, response) {
    SmartClientManager.writeToLog("The operationRequestCallback function was triggered. A result is " + result + ". A response is " + response + ".");
    SmartClientManager.writeToLog("Triggering the callback of the SmartClientManager object...");
    SmartClientManager.triggerOfflineRequestCallback(result, response);
    SmartClientManager.writeToLog("The callback of the SmartClientManager object was triggered.");
};

function printerCallback(paramName, paramValue) {
	SmartClientManager.triggerPrinterCallback(paramName, paramValue);
};

function screenPanelCallback() {
	SmartClientManager.triggerScreenPanelCallback.apply(SmartClientManager, arguments);
};

function scannerCallback(paramName, paramValue) {
	SmartClientManager.triggerBarcodeScannerCallback(paramName, paramValue);
};
function cardReaderCallback(paramName, paramValue) {
    SmartClientManager.triggerCardReaderCallback(paramName, paramValue);
};

function terminalManagerCallback(paramName, paramValue) {
    SmartClientManager.triggerTerminalManagerCallback(paramName, paramValue);
};

function comfortableRouteCallback(paramName, paramValue) {
    SmartClientManager.triggerTransportCardSuitableRoute(paramName, paramValue);
};

function changeSumCallback(sum) {
    SmartClientManager.triggerChangeSumChanged(sum);
};
