﻿NavManager = (function (Listenable) {
    function NavManager() {
        var self = this;
        this._pageLoaded = null;
        var obs = this.observable = new Listenable();

        this._blockNavigationBeforePageLoaded = true;
    };

    NavManager.prototype.addPagePreInitAsyncTask = function (asyncTaskHandler) {
        var self = this;
        self.observable.addOnceAsyncHandler("pagePreInit", asyncTaskHandler);
    };

    NavManager.prototype.addPageInitAsyncTask = function (asyncTaskHandler) {
        var self = this;
        self.observable.addOnceAsyncHandler("pageInit", asyncTaskHandler);
    };

    NavManager.prototype.addPageLoadAsyncTask = function (asyncTaskHandler) {
        var self = this;
        self.observable.addOnceAsyncHandler("pageLoad", asyncTaskHandler);
    };

    NavManager.prototype.addPreNavAsyncTask = function (taskAsyncHandler) {
        var self = this;
        self.observable.addOnceAsyncHandler("preNav", taskAsyncHandler);
    };

    NavManager.prototype.addPostNavAsyncTask = function (taskAsyncHandler) {
        var self = this;
        self.observable.addOnceAsyncHandler("postNav", taskAsyncHandler);
    };

    NavManager.prototype.navigateAsync = function (path, callback) {
        var self = this;
        if (self._navigating === true) {
            TerminalUI.loggingService.debug("Deny " + path + " navigating when page is already navigating.");
            return;
        }
        if (self._pageLoaded !== true && self._blockNavigationBeforePageLoaded === true) {
            TerminalUI.loggingService.debug("Deny " + path + " navigating before page is loaded.");
            return;
        }
        self._navigating = true;
        var navigationHandler = function () {
            commonNavigate(path);
        };
        TerminalUI.loggingService.debug("navigating path " + path);
        self.triggerNavigationHandlersAsync(navigationHandler, function () {
            self._navigating = false;
            if (callback) callback();
        });
    };

    NavManager.prototype.navigateQuiet = function (path) {
        commonNavigate(path);
    };

    NavManager.prototype.navigateStart = function (options) {
        var options = options || {};
        var callback = options.callback;
        var triggerCallback = function() {
            if (callback) callback(arguments);
        };
        var pathStart = URL_MAINMENU;
        if (options.quiet) {
            this.navigateQuiet(pathStart);
            triggerCallback();
        } else {
            this.navigateAsync(pathStart, callback);
        }
    };

    NavManager.prototype.triggerNavigationHandlersAsync = function (navigationHandler, callback) {
        var self = this;
        this.observable.notifyListeners({
            state: "preNav",
            async: true,
            callback: function () {

                navigationHandler();

                self.observable.notifyListeners({
                    state: "postNav",
                    async: true,
                    callback: function () {
                        //completed
                        if (callback) callback();
                    }
                });
            }
        });
    };

    //eventCtx = { name: "", args: {}, callback: function() {} }
    NavManager.prototype.triggerEventAsync = function (eventCtx) {
        var self = this;
        self.observable.notifyListeners({
            state: eventCtx.name,
            async: true,
            callback: function () {
                if (eventCtx.callback) eventCtx.callback();
            }
        });
    };

    return NavManager;
})(Listenable);

NavManager = makeSingleton(NavManager);