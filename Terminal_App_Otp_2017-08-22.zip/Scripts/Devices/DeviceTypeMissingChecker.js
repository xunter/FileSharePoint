﻿/// <reference path="~/Scripts/Devices/DeviceManager.js"/>

DeviceTypeMissingChecker = (function () {
    _instance = null;
    _allowedTypes = [];

    function isDeviceTypeAllowed(type) {
        for (var i = 0; i < _allowedTypes.length; i++) {
            var curr = _allowedTypes[i];
            if (curr == type) {
                return true;
            }
        }
        return false;
    };

    function DeviceTypeMissingChecker() { };

    DeviceTypeMissingChecker.getInstance = function () {
        if (_instance == null) {
            _instance = new DeviceTypeMissingChecker();
        }
        return _instance;
    };

    DeviceTypeMissingChecker.prototype = {
        checkRequiredDeviceTypes: function (requiredDeviceTypes, deviceManager) {
            var missingDeviceTypes = [];
            for (var i = 0; i < requiredDeviceTypes.length; i++) {
                var currRequiredDeviceType = requiredDeviceTypes[i];
                var deviceTypeMissing = !deviceManager.isDeviceTypeSupported(currRequiredDeviceType);
                var deviceTypeCheckingPrevented = isDeviceTypeAllowed(currRequiredDeviceType);
                if (deviceTypeMissing && !deviceTypeCheckingPrevented) {
                    missingDeviceTypes.push(currRequiredDeviceType);
                }
            }
            return missingDeviceTypes;
        },

        preventCheckDeviceType: function (deviceType) {
            _allowedTypes.push(deviceType);
        }
    };

    return DeviceTypeMissingChecker;
})();