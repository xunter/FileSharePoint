(function (window) {
    var _deviceManagerInstance = null;

    function DeviceManager() {
        this._deviceFactory = null;
        this._availableDeviceTypes = null;
        this._deviceSet = null;
    };

    DeviceManager.getInstance = function () {
        if (_deviceManagerInstance == null) {
            _deviceManagerInstance = new DeviceManager();
        }
        return _deviceManagerInstance;
    };

    DeviceManager.prototype = {
        registerDeviceFactory: function (deviceFactory) {
            this._deviceFactory = deviceFactory;
        },
        setAvailableDeviceTypes: function (availableDeviceTypes) {
            this._availableDeviceTypes = availableDeviceTypes;
        },
        setDeviceSet: function (deviceSet) {
            this._deviceSet = deviceSet;
        },
        isDeviceSupportedByCondition: function (condition) {
            var deviceSet = this._deviceSet;
            for (var i = 0; i < deviceSet.length; i++) {
                var currentDeviceInfo = deviceSet[i];
                if (condition(currentDeviceInfo) === true) {
                    return true;
                }
            }
            return false;
        },
        isDeviceTypeSupported: function (deviceTypeName) {
            return this.isDeviceSupportedByCondition(function (deviceInfo) { return deviceInfo.TypeName == deviceTypeName });
        },
        isDeviceSupported: function (deviceName) {
            return this.isDeviceSupportedByCondition(function (deviceInfo) { return deviceInfo.Name == deviceName });
        },
        getDevice: function (deviceTypeName) {
            if (this.isDeviceTypeSupported(deviceTypeName)) {
                var deviceInstance = this._deviceFactory.getDevice(deviceTypeName);
                return deviceInstance;
            } else {
                return null;
            }
        }
    };

    window.DeviceManager = DeviceManager;
    //return DeviceManager;
})(window);