﻿(function (namespace) {

    function BillValidatorEmulator() {
        this.state = "created";
    };

    namespace.BillValidatorEmulator = BillValidatorEmulator;

    BillValidatorEmulator.prototype = {
        observableSubject: null,
        state: null,
        cashValue: 0,
        init: function (settings) {
            var self = this;
            this.observableSubject = new Listenable();
            this.observableSubject.addHandler("banknotePushed", function (nominalValue) {
                self.observableSubject.notify("cashValueChanged", self.cashValue);
            });
        },
        open: function () {
            if (this.state == "closed") this.state = "opened";
        },
        close: function (callback) {
            if (this.state == "opened") this.state = "closed";
            if (callback) callback();
        },
        pushBanknote: function (nominalValue) {
            if (this.state != "opened") {
                this.cashValue += nominalValue;
                this.observableSubject.notify("banknotePushed", nominalValue);
            }
        }
    };
})(window);