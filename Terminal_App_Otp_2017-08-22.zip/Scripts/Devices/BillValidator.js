﻿function BillValidator() { };
extend(BillValidator, Device, {
    getCurrentSum: function () { },

    isOpened: function () { },
    isClosed: function () { },

    open: function () { },
    close: function (callback) { },

    onSumChanged: function (sum) { },
    onBillPushed: function (bill) { },
    onInvalidBill: function() {},

    onSumExceeded: function(exceededSum) {},
    onBillExceeded: function(exceededBill) {},

    onDisabled: function () { },
    onEnabled: function () { },
    isEnabled: function () { },
    isDisabled: function () { },
});