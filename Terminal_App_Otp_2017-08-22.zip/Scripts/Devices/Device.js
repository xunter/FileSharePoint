﻿function Device() { };

Device.prototype = {
    getCurrentState: function () { },
    onStateChanged: function (state) { },
    state: function () { }
}