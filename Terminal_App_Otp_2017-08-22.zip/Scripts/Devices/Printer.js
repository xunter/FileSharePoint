﻿function Printer() { };
extend(Printer, Device, {
    printText: function (print, amountAll, callback) { }
});