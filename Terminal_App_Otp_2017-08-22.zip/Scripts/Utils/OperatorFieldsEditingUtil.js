﻿var OperatorFieldsEditingUtil = {
    loggingService: FS.TerminalUI.loggingService,
    reKeyMultiple: /field(\d+)_(\d+)/,

    getUserMessageByErrorCode: function (errorCode, defaultUserMessage) {
        var errorCode = parseInt(errorCode);
        var userMsg = null;
        var errorCodes = FS.Gateway.ErrorCodes;
        var uiMessageKey = "Gateway_ErrorCode_" + errorCode;
        if (TerminalUI.UIMessageMap.hasOwnProperty(uiMessageKey)) {
            userMsg = TerminalUI.UIMessageMap[uiMessageKey];
        } else {
            userMsg = defaultUserMessage;
        }
        return userMsg;
    },

    processFieldsBeforePayAsync: function (settings) {
        var self = this;
        var IS_INVOICE_SEARCH_ENABLED = settings.invoiceSearchEnabled;
        var IS_FIELDS_CHECKING_ENABLED = settings.fieldsCheckingEnabled;
        var URLGetFieldsMapByAnswerData = settings.urlGetFieldsMapByAnswerData;
        var operatorInstance = settings.operatorInstance;
        var operatorId = settings.operatorId;
        var fieldsMap = settings.fieldsMap;
        var callback = settings.callback;
        var errorHandler = settings.error;
        var loggingService = this.loggingService;
        var fields = operatorInstance.Fields;

        var attemptToCheckFields = function () {
            if (!IS_FIELDS_CHECKING_ENABLED) {
                callback();
                return;
            }
            loggingService.trace("Для оператора %1 необходимо проверить введенные поля. Отправляем поля на сервер...", operatorId);

            SmartClientManager.checkInputDataAsync({
                operatorId: operatorId,
                fields: fieldsMap,
                callback: function (args) {
                    var result = args.result;
                    loggingService.trace("Пришел результат о проверке входных данных для оператора %1. Результат равен %2.", operatorId, result);
                    var responseData = args.responseData;
                    if (result == GatewayResults.SUCCESS) {
                        loggingService.trace("Поля корректны. Переход к оплате оператора %1...", operatorId);
                        callback();
                    } else {
                        loggingService.trace("Поля некорректны или при проверке произошла ошибка для оператора %1!", operatorId);
                        var userMsg = self.getUserMessageByErrorCode(args.error, "Не удалось проверить введенные данные!");
                        errorHandler(userMsg);
                    }
                }
            });
        };
        loggingService.trace("Обработка введенных полей для оператора %1...", operatorId);
        if (IS_INVOICE_SEARCH_ENABLED) {
            self.loadInvoiceFieldsAsync(operatorId, fields, fieldsMap, function (res) {
                if (res.isError) {
                    errorHandler(res.error);
                } else {
                    self.setMissingFields(fieldsMap, res.missingFieldsMap);
                    attemptToCheckFields();
                }
            });
        } else {
            attemptToCheckFields();
        }
    },

    loadInvoiceFieldsAsync: function (operatorId, fields, fieldsMap, callback, forcedUrlParseInvoice) {
        var self = this;
        var loggingService = TerminalUI.loggingService;
        loggingService.trace("Загрузка недостаующих полей с сервера для оператора %1...", operatorId);
        var invoiceSearchFieldMap = _.chain(fields)
            .filter(function (fieldInstance) { return fieldInstance.IsInvoiceSearch })
            .map(function (fieldInstance) {
                var fieldKey = "field" + fieldInstance.ID
                return { fieldKey: fieldKey, value: fieldsMap[fieldKey] }
            })
            .reduce(function (map, item) {
                var fieldKey = item.fieldKey;
                map[fieldKey] = item.value;
                return map;
            }, {})
            .value();

        var demoResultCode = 0;
        var demoResponse = "RESULT=0\nERROR=0\nANSWER_DATA=<?xml version=\"1.0\" encoding=\"Windows-1251\"?><root><session>obsolite</session><invoices><invoice id=\"849\"><fields><field id=\"102\" value=\"PAVEL NAZAROV\"/><field id=\"103\" value=\"12345678901234567890\"/></fields></invoice></invoices></root>";
        var emulateCardRecharge = false;

        var loadCardRechargeInvoiceDemoRequest = {
            operatorId: operatorId,
            type: RequestTypes.GET_MISSING_FIELDS,
            fields: invoiceSearchFieldMap
        };

        if (emulateCardRecharge) {
            loadCardRechargeInvoiceDemoRequest.emulate = {
                result: demoResultCode,
                responseData: demoResponse,
                delay: 2000
            };
        }

        SmartClientManager.sendOnlineRequestAsync({
            request: loadCardRechargeInvoiceDemoRequest,
            callback: function (responseArgs) {
                var resultCode = parseInt(responseArgs.result);

                loggingService.trace("Пришел ответ от сервера на получение недостающих полей для оператора %1. Результат %2.", operatorId, resultCode);
                loggingService.trace("Результат ответа от сервера - %1.", resultCode);
                if (resultCode == GatewayResults.SUCCESS) {
                    var responseMap = responseArgs.responseMap;
                    loggingService.trace("Разбор полученных недостающих данных от сервера...");
                    var answerData = responseMap["ANSWER_DATA"];

                    self.parseFoundInvoice(answerData, function (resultCtx) {
                        if (resultCtx.error) {
                            callback({ isError: true, error: resultCtx.error });
                        } else {
                            var missingFieldsMap = resultCtx.extendingFieldsMap;
                            callback({ missingFieldsMap: missingFieldsMap });
                        }
                    }, forcedUrlParseInvoice);
                } else {
                    var userMsg = self.getUserMessageByErrorCode(responseArgs.error, "Не удалось получить список информационных полей!");
                    callback({ isError: true, error: userMsg });
                }
            }
        });
    },

    setMissingFields: function (fieldsMap, missingFieldsMap)
    {
        var loggingService = TerminalUI.loggingService;
        for (var key in missingFieldsMap)
        {
            // Если поле отсутствует - создаем поле со значением пришедшим с хостинга
            if (fieldsMap[key] == null)
            {
                fieldsMap[key] = missingFieldsMap[key];
            }
            else
            {
                // Если поле присутствует и значение не пусто - сбрасываем ранее введенные пользователем значения
                if (missingFieldsMap[key].toString().length > 0)
                {
                    fieldsMap[key] = missingFieldsMap[key];
                }
            }
        }

        for (var key in fieldsMap)
        {
            OperatorFieldsFormManager.setFieldElement(key, fieldsMap[key]);
        }

        loggingService.trace("Недостающие поля успешно присвоены. Попытка на проверку введенных полей...");
    },

    parseFoundInvoice: function (invoiceXmlText, callback, forcedUrlParseInvoice) {
        var urlParseInvoice = "";
        if (typeof (URL_PARSE_INVOICE) != "undefined") {
            urlParseInvoice = URL_PARSE_INVOICE;
        }
        if (forcedUrlParseInvoice) {
            urlParseInvoice = forcedUrlParseInvoice;
        }
        var loggingService = FS.TerminalUI.loggingService;
        loggingService.trace("Разбор полученных недостающих данных от сервера...");
        var answerData = invoiceXmlText;
        var postingData = { answerData: answerData };
        var triggerCallback = function (ctx) {
            if (callback) callback(ctx);
        };
        FS.TerminalUI.ajaxService.postJSON(urlParseInvoice, postingData, function (missingFieldsResult) {
            loggingService.trace("Разбор недостующих полей завершен.");
            var missingFieldsResultCode = missingFieldsResult.Code;
            loggingService.trace("Разбор недостующих полей завершен. Результат равен %1.", missingFieldsResultCode);
            if (missingFieldsResultCode == -1) {
                loggingService.trace("В процессе разбора полей произошла ошибка!");
                triggerCallback({ error: "Не удалось получить список информационных полей!" });
            } else if (missingFieldsResultCode == 0) {
                loggingService.trace("В процессе разбора полей установлено, что данные не найдены!");
                triggerCallback({ error: "Данные не найдены" });
            } else if (missingFieldsResultCode == 1) {
                loggingService.trace("Недостающие поля успешно разобраны. Присваивание полей...");
                var missingFieldsMap = missingFieldsResult.FieldsMap;
                triggerCallback({ extendingFieldsMap: missingFieldsMap });
            }
        });
    }
};