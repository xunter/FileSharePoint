﻿var DlgManager = {
    dlgs: [],
    $lock: null,
    initLock: function () {
        if (this.$lock == null) this.$lock = $("#lock");
    },
    getLockShowCounter: function () {
        var $lock = this.$lock;
        var dlgCounter = parseInt($lock.attr("data-show_counter"));
        if (isNaN(dlgCounter)) dlgCounter = 0;
        return dlgCounter;
    },
    setLockShowCounter: function (num) {
        var $lock = this.$lock;
        $lock.attr("data-show_counter", num);
    },
    incLockShowCounter: function () {
        var currCounter = this.getLockShowCounter();
        this.setLockShowCounter(currCounter + 1);
    },
    decLockShowCounter: function () {
        var currCounter = this.getLockShowCounter();
        if (currCounter == 0) return;
        this.setLockShowCounter(currCounter - 1);
    },
    showLock: function () {
        //var funcTimestamp = new Date().getTime();
        //var log = FS.TerminalUI.loggingService;
        var self = this;
        //log.trace(funcTimestamp + ": show start");
        self.initLock();
        var currLockShowCounter = self.getLockShowCounter();
        //log.trace(funcTimestamp + ": show get: " + currLockShowCounter);
        if (currLockShowCounter == 0) {
            self.$lock.removeClass("hidden");
        }
        //log.trace(funcTimestamp + ": show inc: " + currLockShowCounter + " + 1");
        self.incLockShowCounter();
        //log.trace(funcTimestamp + ": show end");
    },
    hideLock: function () {
        var log = FS.TerminalUI.loggingService;
        var self = this;
        //alert("hide start");
        self.initLock();
        var currLockShowCounter = self.getLockShowCounter();
        //alert("hide get: " + currLockShowCounter);
        if (currLockShowCounter === 1) {
            self.$lock.addClass("hidden");
        }
        //alert("hide dec: " + currLockShowCounter + " - 1");
        self.decLockShowCounter();
        //alert("hide end");
    },

    hideDlgOnly: function ($dlg) {
        var self = this;
        self.hideLock();
        $dlg.addClass("hidden");
        $dlg.trigger("dlg.hidden");
    },

    showDlgOnly: function ($dlg) {
        var self = this;

        self.showLock();
        $dlg.removeClass("hidden");
        //for interoperability
        if ($dlg.hasClass("th-hidden")) {
            $dlg.removeClass("th-hidden");
        }
        $dlg.trigger("dlg.shown");
    },

    hideDlg: function ($dlg) {
        var deletedDlg = this.removeDlg($dlg);
        if (this.isShown($dlg)) {
            this.hideDlgOnly($dlg);
            var nextDlg = this.popDlg();

            if (nextDlg != null) {
                this.showDlgOnly(nextDlg);
                this.pushDlg(nextDlg);
            }
        }
    },

    showDlg: function ($dlg) {

        var prevDlg = this.peekDlg();
        if (prevDlg != null) {
            this.hideDlgOnly(prevDlg);
        }

        this.showDlgOnly($dlg);

        this.pushDlg($dlg);

    },

    findDlgIndex: function (dlg) {
        var dlgs = this.dlgs;
        for (var i = 0; i < dlgs.length; i++) {
            var currDlg = dlgs[i];
            if (currDlg == dlg) return i;
        }
        return -1;
    },

    isDlgExists: function (dlg) { return this.findDlgIndex(dlg) != -1 },

    peekDlg: function () {
        if (this.dlgs.length == 0) return null;
        return this.dlgs[this.dlgs.length - 1];
    },

    popDlg: function () {
        var dlg = this.dlgs.pop();
        return dlg;
    },

    removeDlg: function ($dlg) {
        var dlgIndex = this.findDlgIndex($dlg);
        if (dlgIndex != -1) {
            var deletedArr = this.dlgs.splice(dlgIndex, 1);
            if (deletedArr != null && deletedArr.length > 0) {
                return deletedArr[0];
            }
        }
        return null;
    },

    pushDlg: function ($dlg) {
        if (!this.isDlgExists($dlg)) {
            this.dlgs.push($dlg);
        }
    },
    
    isHidden: function ($dlg) { return $dlg.hasClass("hidden") || $dlg.hasClass("th-hidden"); },
    isShown: function ($dlg) { return !$dlg.hasClass("hidden") && !$dlg.hasClass("th-hidden"); },

    showDlgInvalidBill: function ($dlgInvalidBill) {
        if (TerminalUI.UISettingsMap["SHOW_DLG_BILL_INVALID"] == "1") {
            if (DlgManager.isHidden($dlgInvalidBill)) {
                var loggingService = TerminalUI.loggingService;
                loggingService.info("Showing the dlg invalid bill...");

                DlgManager.showDlg($dlgInvalidBill);

                setTimeout(function () {
                    loggingService.info("Hidding the dlg invalid bill due to %1 timeout", UISettingsMap["DLG_INVALID_BILL_TIMEOUT"]);
                    DlgManager.hideDlgInvalidBill($dlgInvalidBill);
                }, UISettingsMap["DLG_INVALID_BILL_TIMEOUT"]);
            }
        }
    },

    hideDlgInvalidBill: function ($dlgInvalidBill) {
        if (DlgManager.isShown($dlgInvalidBill)) {
            var loggingService = TerminalUI.loggingService;
            loggingService.info("Hidding the dlg invalid bill...");
            DlgManager.hideDlg($dlgInvalidBill);
        }
        DlgManager.hideDlg($dlgInvalidBill);
    },

    showDlgMaxSumExceeded: function ($dlgMaxSumExceeded) {
        if (DlgManager.isHidden($dlgMaxSumExceeded)) {

            var loggingService = TerminalUI.loggingService;
            loggingService.info("Showing the dlg max sum exceeded...");
            DlgManager.showDlg($dlgMaxSumExceeded);

            setTimeout(function () {
                loggingService.info("Hidding the dlg max sum exceeded due to %1 timeout", UISettingsMap["DLG_MAX_SUM_EXCEEDED_TIMEOUT"]);
                DlgManager.hideDlgMaxSumExceeded($dlgMaxSumExceeded);
            }, UISettingsMap["DLG_MAX_SUM_EXCEEDED_TIMEOUT"]);
        }
    },

    hideDlgMaxSumExceeded: function ($dlgMaxSumExceeded) {
        var loggingService = TerminalUI.loggingService;
        if (DlgManager.isShown($dlgMaxSumExceeded)) {
            loggingService.info("Hidding the dlg max sum exceeded...");
            DlgManager.hideDlg($dlgMaxSumExceeded);
        }
    }
};