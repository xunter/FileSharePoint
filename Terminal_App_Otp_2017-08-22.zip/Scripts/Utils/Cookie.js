﻿//JavaScript for Cookies

(function (window) {
    var document = window.document;

    var KeyValuePair = function (key, value) {
        if (key && value) {
            this.key = key;
            this.value = value;
        } else {
            throw new Error("Bad arguments!");
        }
    }

    var getAllCookies = function () {
        var arr = [];
        var add = function (pair) {
            try {
                var result = /(\w+)=(.+)/.exec(pair),
					cookieName = result[1],
					cookieValue = result[2];

                arr.push(new KeyValuePair(cookieName, unescape(cookieValue)));
            } catch (e) { }
        };
        if (typeof (document.cookie) == "undefined") {
            throw new Error("Cookie is undefined!");
        }
        if (document.cookie !== null && document.cookie.length > 0) {
            if (document.cookie.indexOf(";") !== -1) {
                var pairs = document.cookie.split(";");
                for (var i = 0; i < pairs.length; i++) {
                    add(pairs[i]);
                }
            } else {
                add(document.cookie);
            }
        }
        return arr;
    };

    Cookie = {
        set: function (args) {

            var strBuffer = args.name + "=" + escape(args.value) + "; ";
            strBuffer += args.path ? "path=" + args.path + "; " : "";
            strBuffer += args.domain ? "domain=" + args.domain + "; " : "";
            strBuffer += args.expires ? "expires=" + args.expires.toGMTString() + "; " : "";
            strBuffer += args.secure ? "secure" : "";
            strBuffer = strBuffer.replace(/^(.*)(;\s*)$/, "$1");
            document.cookie = strBuffer;
        },
        get: function (name) {
            var all = getAllCookies();
            for (var i = 0; i < all.length; i++) {
                if (all[i].key === name) {
                    return all[i].value;
                }
            }
            return null;
        },
        getAll: function () {
            return getAllCookies();
        },
        "remove": function (name, path) {
            var path = path || "/";
            this.set({
                "name": name,
                "path": path,
                "value": "",
                "expires": new Date(0)
            });
        }
    };
})(window);